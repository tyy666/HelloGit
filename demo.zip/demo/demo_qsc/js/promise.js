// Promise的核心就是有状态：准备状态、解决状态、拒绝状态，最终根据状态改变里面的值
// 所以核心是：状态、值
class HD{
    static PENDING = 'pengding'
    static FUFILLED = 'fulfilled'
    static REJECTED = 'rejected'
    constructor(executor){
        this.status = HD.PENDING    //起初默认为准备状态
        this.value = null
        this.callbacks = []         //定义一个数组，把以后要执行的函数放在里面，等状态改变以后，从数组里面拿出来函数执行
        try {
            executor(this.resolve.bind(this),this.reject.bind(this))
        } catch (error) {
            this.reject(error)
        }
    }
    resolve(value){
        if(this.status===HD.PENDING){
            this.status = HD.FUFILLED
            this.value = value
            this.callbacks.map(callback=>{
                callback.onFulfilled(this.value)
            })
        }
    }
    reject(reason){
        if(this.status===HD.PENDING){
            this.status = HD.REJECTED
            this.value = reason
        }
    }
    then(onFulfilled,onRejected){
        if(typeof onFulfilled !== 'function'){
            onFulfilled = ()=>{}
        }
        if(typeof onRejected !== 'function'){
            onRejected = ()=>{}
        }
        if(this.status===HD.PENDING){
            this.callbacks.push({
                onFulfilled,
                onRejected
            })
        }
        if(this.status===HD.FUFILLED){
            // 使用setTimeout将这一步放在任务队列中，不会立即执行，做成异步
            setTimeout(()=>{
                try {
                    onFulfilled(this.value)
                } catch (error) {
                    onRejected(error)
                }
            },0)
        }
        if(this.status===HD.REJECTED){
            // 使用setTimeout将这一步放在任务队列中，不会立即执行，做成异步
            setTimeout(()=>{
                try {
                    onRejected(this.value)
                } catch (error) {
                    onRejected(this.value)
                }
            },0)
        }
    }
}
// Promise的用法：
// new Promise((resolve,reject)=>{
//     resolve('解决')
//     reject('拒绝')
// })