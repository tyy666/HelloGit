**[markdown 用法大全](https://www.jianshu.com/p/ebe52d2d468f)**

## 新建 dart 文件及各种 flutter 笔记

1. 快捷输入 stful
2. controller 声明以后还要再 init 里初始化 例如下面

```dart
TextEditingController patientTellController;
initData(){
    patientTellController = new TextEditingController();
}
```

3. dart 字符串转化成数字方法有两个

```dart
double.parse(string);//都行
int.parse(string);//只可以转化整数，小数会报错
```

4. 滑动解决越界

```dart
Container(
    height: double.infinity,//高度撑满
    child: SingleChildScrollView(//滚动
      child:
    ),
  ),
```

5. 解决 ListView 高度无法自适应

```dart
ListView.builder(
  shrinkWrap: true,
  //ListView禁用滑动
  physics: NeverScrollableScrollPhysics(),
)
```

6. 避免 eventbus 多次执行，销毁的办法

```dart
  StreamSubscription eventPass;
  eventPass.on<>.listen((){})
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    eventPass.cancel();
  }
```

7. tabBar 禁用滑动

- TabBar 参数
- isScrollable: false,
- TabBarView 参数
- physics: new NeverScrollableScrollPhysics(),

8. button 添加圆角

```dart
  shape: RoundedRectangleBorder(
      side: BorderSide(
        color: Color(ClinicColors.ClinicBlue),
        width: FormatSize.getSize('width', 1),
      ),
      borderRadius: BorderRadius.all(Radius.circular(4))),
```

9. 三目运算符 某个值等于“”那就等于 null 否则等于自身

```dart
  value = (value == "")? null : value;
```

10. 焦点方法

```dart
  FocusNode tellFocusNode = new FocusNode();
  tellFocusNode.addListener(() {
      if (tellFocusNode.hasFocus) {
        //逻辑代码
      }
    });
  FocusScope.of(context).requestFocus(this.tellFocusNode)//获取焦点方法
```

11. eventBus 清除方法

```dart
  StreamSubscription eventPpe;
  eventPpe = eventBus.on<PrescriptionPassEvent>().listen((data) {})
  eventPpe.cancel();
```

12. 延时方法
    - 两者的区别：有时候 Future.delayed 在这个任务未执行前我们就关掉了页面，
      这时候就会报错。怎么办？答案是用 timer 代替。

```dart
  //延时方法1
  Timer t;
  if (t != null) {
    t.cancel();
  }
  t = Timer(Duration(milliseconds: 200), () {
    //逻辑代码
  })
  //延时方法2
  Future.delayed(Duration(milliseconds: 2000), () {
    //逻辑代码
  });

```

13. 点击空白处隐藏键盘

- 给 Container 添加一个点击隐藏子 widget TextField 隐藏键盘的操作，加上去后发现没有用，点击空白处并不能收起键盘。给 container 添加一个背景后才起作用。
- 是因为默认清除下透明区域不响应事件，给 GestureDetector 加上 behavior: HitTestBehavior.translucent,这个参数就可以正常接受了。

```dart
GestureDetector(
  behavior: HitTestBehavior.translucent,
  onTap: () {
      // 触摸收起键盘
      FocusScope.of(context).requestFocus(FocusNode());
  },
  child: *******
}
```

14. 注释插件

- koroFileHeader 插件 可以快速为文件头部添加注释
  快捷键：window：ctrl+alt+i,mac：ctrl+cmd+i

15. Row 和 Column 高度自适应

```dart
Column(
  mainAxisSize: MainAxisSize.min,
)
```

16. Column 提示高度溢出 如果子 list 非 Expanded 或 Flexible，就可能会提示 解决方案：**最后一个子组件用 Expanded 包一下** 例如:

```dart
Column(
  children: <Widget>[
    SizedBox(...),
    SizedBox(...),
    Expanded(//这里包一下就好
      child:Column(
        ...//这里的最后一个也要包一下
      )
    )
  ]
)
```

17.左右布局 Row

```dart
Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,//左右布局
  children: <Widget>[
    Container(
      alignment: Alignment.centerLeft,
      child: Text('账号')
    ),
    Container(
      alignment: Alignment.centerRight,
      child: Text('158')
    ),
  ],
)
```

18. 遍历 Map-报错

```dart
var map=[
  {'name': "北京北京1"},
];
map.forEach((item) {
  //这里是关键，如果写成item.name会报错
  item['name'];//北京北京1
})
```

19. 获取元素宽高尺寸

```dart
GlobalKey popTopKey; //定义key
popTopKey = GlobalKey(); //initData 里初始化
Container(
  key: popTopKey,        //元素绑定key
}
//根据key获取元素
RenderBox renderBox = popTopKey.currentContext.findRenderObject();
//获取元素尺寸
Size size = renderBox.size; //targetWidget的size
//拿到width
print('size.width${size.width}');
```

20. TextField 禁用

```dart
TextField(
  enabled: false,//只读不可编辑、也无法响应点击事件
  enableInteractiveSelection: false, //只读不可编辑
)
```

21. 对象拷贝

```dart
//对象拷贝1：
Map m={};
Map _map = DeepCopy().copy(JSON_DATA);
m.add(_map);
//对象拷贝2：
jsonDecode(jsonEncode({
  'a':1
}))
//数组拷贝：
list.toList();//可创建一个数组副本
```

### 不懂的问题知识点

- home_charge_model.dart model 类型到底是什么？1.==一个对象==

### 同步异步

- javascript 是单线程。 单线程就意味着，所有任务需要排队，前一个任务结束，才会执行后一个任务。如果前一个任务耗时很长，后一个任务就不得不一直等着。
  于是就有一个概念——任务队列：
  同步是主队列 异步是任务队列 异步任务队列可以一边执行着不耽误主队列的执行 当主队列执行完了之后 发现主队列空了然后再去执行任务队列的回调（回调函数就是异步）然后接着循环执行；所谓"回调函数"（callback），就是那些会被主线程挂起来的代码；异步任务必须指定回调函数，当主线程开始执行异步任务，就是执行对应的回调函数。

```javascript
//  async await 这样的场景，调用promise1，使用promise1返回的结果去调用promise2，然后使用两者的结果去调用promise3
const makeRequest = async () => {
  const value1 = await promise1();
  const value2 = await promise2(value1);
  return promise3(value1, value2);
};
```

### flutter 报错

- type 'int' is not a subtype of type 'String' flutter 项目报错 意思是 本该是 string 但真实值却是 int

### 暂时记一下工作内容，非长期笔记

- wiki 鲮鲤研发中心-大前端-业务开发-find it
- 192.168.164.180:8003 开发 ip 192.168.164.180:8002 测试 ip
  新的 ip ：192.168.162.149
- 命令行运行 flutter 项目 指定执行路径
  test：flutter run --target=./lib/main_test.dart
  dev：flutter run --target=./lib/main_dev.dart

### 疫情远程办公 flutter 账号

我这提供的 192.168.122.210 账号：15239322891 密码:322891 账号 测试环境 这个需要 vpn

### 改线上代码流程

1. 先拉新分支，修改了往 dev3 上合并（合并找相关了解业务、代码的同学一起看下改动）
2. 找测试测试下，没问题了再往 master 上合

### flutter 错题本

1. flutter 在 tab 切换的时候，怎么让他不执行 initState
   在 LoadImgByNetPage，LoadImgByLocPage 中添加 AutomaticKeepAliveClientMixin，
   并设置为 true,这样就能一直保持当前不被 initState 了。

```dart
class _LoadImgByLocAppPageState extends State<LoadImgByLocAppPage> with AutomaticKeepAliveClientMixin{//关键点
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print('_LoadImgByLocAppPageState initState');
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      body: new ListView(
        children: <Widget>[
          new Image.asset('images/ic_assignment_ind_36pt.png'),
          new Divider(),
          new Image(
            image: new AssetImage('images/ic_assignment_ind_36pt.png'),
          ),
          new Divider(),
        ],
      ),
    );
  }

  // TODO: implement wantKeepAlive
  @override
  bool get wantKeepAlive => true;//关键点
}
```

2. 输入框 onchanged 事件下 setState(() {})的用法
   - 注释掉的部分
     在 flutter 开发中，加载某一段文字后需要对该文字进行更改的时候，使用 controller 设置默认值，这个时候光标会在文字的最前面，设置 selection 改变光标位置到最后，但是在编辑的时候删除以前的文字中的某个位置的字符光标会返回到文段末尾。
     解决方案：onchanged 中如果改变的自身的值，就不用 setState；如果改变的是其他的值可以用。

```dart
TextField(
  maxLines: 4,
  style: TextStyle(
      color: Color(ClinicColors.ClinicText),
      fontSize: TextSize.fontSize_16), // 设置字体样式
  controller: TextEditingController.fromValue(
    TextEditingValue(
      // 设置内容
      text: form['diagnosis'],
      // 保持光标在最后
      selection: TextSelection.fromPosition(
        TextPosition(
            affinity: TextAffinity.downstream,
            offset: form['diagnosis'].length),
      ),
    ),
  ),
  decoration: InputDecoration(
    hintText: '请从右侧常见主诉列表中选择常用主诉或在本输入框内直接输入',
    contentPadding: const EdgeInsets.all(0),
    border: OutlineInputBorder(
      borderSide: BorderSide.none,
    ),
  ),
  // 当 value 改变的时候，触发
  onChanged: (val) {
    if (val.length > 300) {
      Toast(msg: '最多输入300字');
      //setState(() {
        form['diagnosis'] = val.substring(0, 300);
      //});
      return;
    }
    //setState(() {
      form['diagnosis'] = val;
    //});
  })

```

### 进一步阅读链接

- [Flutter 中文网](https://book.flutterchina.club "Flutter 中文网")
- [Flutter Dart 语法(1):extends 、 implements 、 with 的用法与区别](https://www.jianshu.com/p/dd11429ba80e)
- [flutter Future 的用法](https://www.jianshu.com/p/c0e30769ea7e)
  - 结论：首先执行顺序和创建 Future 的先后顺序有关，如果遇到多个 then 嵌套，先执行外面的 then，然后再执行里面的 then，如果 then 里面还有创建 Future，要等到 then 执行完毕，之后执行 Future。
