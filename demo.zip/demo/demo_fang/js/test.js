const tree =[
  {
    id: -1,
    children: []
  }
]
const treeObj = {}

treeObj[-1] = tree[0]//关键
//改变tree，同时treeObj跟着改变
//改变treeObj，tree也跟着改变
const child = {
  id: 0,
  pid: -1,
  children: []
}
treeObj[0] = child
treeObj[-1].children.push(treeObj[0])
console.dir(tree)
console.dir(treeObj)