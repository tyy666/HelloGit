const tree =[{
  id: -1,
  children: []
}]

const treeObj = {}
treeObj[-1] = tree[0]//关键

let child0 = {
  id: 0,
  name: 'child0'
}

treeObj[0] = child0
treeObj[-1].children.push(treeObj[0])

tree[0].children[0].children = []
let child1 = {
  id: 1,
  name: 'child1'
}
treeObj[1] = child1
treeObj[0].children.push(treeObj[1])

console.log(JSON.stringify(tree, null, 2))
console.log('---------')
console.log(JSON.stringify(treeObj, null, 2))
