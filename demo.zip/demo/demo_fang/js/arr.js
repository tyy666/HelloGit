var arr1=[1,2,3,4,5]
var arr2=arr1.push(6)
console.dir(arr1)
console.dir(arr2)
arr1.splice(0,0,8)
console.dir(arr1)
var x=911+7+"ppp"
console.log(x)
var y="ppp"+911+7
console.log(y)

console.log("--------------")
var array=[1,2,3]
var newArr1=array.splice(0,2)
var newArr2=array.splice(0,0,4,5)
console.dir(newArr1)
console.dir(newArr2)
console.dir(array)
