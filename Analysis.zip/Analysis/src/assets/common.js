function webpath() {
    return "http://172.20.10.149:9969";
}
export default{
    "webpath":webpath
}