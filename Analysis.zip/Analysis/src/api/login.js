import request from '@/utils/request'

export function loginByUsername(username, password) {
  const data = {
    username,
    password
  }
  return request({
    url: '/authc/login',
    method: 'post',
    data
  })
}

export function logout(adoptToken) {
  return request({
    url: '/logout',
    method: 'post',
    params: { adoptToken }
  })
}

export function getUserInfo(adoptToken) {
  return request({
    url: '/getTokenUser',
    method: 'post',
    params: { adoptToken }
  })
}

