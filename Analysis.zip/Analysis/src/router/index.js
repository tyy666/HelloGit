import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/views/layout/Layout'
import store from '../store'

/* Router Modules */
// import componentsRouter from './modules/components'
// import chartsRouter from './modules/charts'
// import tableRouter from './modules/table'
// import nestedRouter from './modules/nested'

/** note: submenu only apppear when children.length>=1
 *  detail see  https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 **/

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    roles: ['admin','editor']     will control the page roles (you can set multiple roles)
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
    noCache: true                if true ,the page will no be cached(default is false)
  }
**/

if (localStorage.adoptToken) {
  store.state.adoptToken = localStorage.adoptToken
  store.state.hasLoggedOn = true
  store.state.userInfo = localStorage.getItem('userInfo')
}

export const constantRouterMap = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    // 和信贷日报
    path: '/dayReportHexinDai',
    component: () => import('@/views2/operate/operateView/operateDay'),
    hidden: true
  },
  {
    path: '/authredirect',
    component: () => import('@/views/login/authredirect'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/errorPage/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/errorPage/401'),
    hidden: true
  },
  {
    path: '/profile',
    component: Layout,
    redirect: '/profile/index',
    hidden: true,
    children: [
      {
        path: 'index',
        component: () => import('@/views2/profile/index'),
        name: 'Profile',
        meta: { title: '个人中心', icon: 'user', noCache: true }
      }
    ]
  }

]

export default new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

export const asyncRouterMap = [
  {
    path: '',
    component: Layout,
    redirect: 'survey',
    meta: { title: '概况', icon: 'dashboard', noCache: true, roles: [1] },
    children: [
      {
        path: 'survey',
        component: () => import('@/views2/survey/index'),
        name: 'survey',
        meta: { title: '概况', icon: 'dashboard', noCache: true, roles: [1] }
      }
    ]
  },
  {
    path: '/system',
    component: Layout,
    name: 'system',
    meta: { title: '系统管理', icon: 'system-manage', noCache: true, roles: [2] },
    children: [
      {
        path: '/system/user',
        component: () => import('@/views2/system/user'),
        name: 'user',
        meta: { title: '用户管理', icon: 'user-manage', noCache: true, roles: [5] }
      },
      {
        path: '/system/role',
        component: () => import('@/views2/system/role'),
        name: 'role',
        meta: { title: '角色管理', icon: 'role-manage', noCache: true, roles: [6] }
      },
      {
        path: '/system/resources',
        component: () => import('@/views2/system/resources'),
        name: 'resources',
        meta: { title: '资源管理', icon: 'resources-manage', noCache: true, roles: [7] }
      },
      {
        path: '/system/monitor',
        component: () => import('@/views2/system/monitor'),
        name: 'monitor',
        meta: { title: '系统监控', icon: 'monitor', noCache: true, roles: [8] }
      }
    ]
  },
  {
    path: '/dataConfig',
    component: Layout,
    name: 'dataConfig',
    meta: { title: '数据配置', icon: 'dataconfig', noCache: true, roles: [3] },
    children: [
      {
        path: '/dataConfig/param',
        component: () => import('@/views2/dataConfig/param'),
        name: 'param',
        meta: { title: '参数配置', icon: 'param-configure', noCache: true, roles: [9] }
      },
      {
        path: '/dataConfig/server',
        component: () => import('@/views2/dataConfig/server'),
        name: 'server',
        meta: { title: '集群配置', icon: 'server-configure', noCache: true, roles: [16] }
      }

    ]
  },
  {
    path: '/record',
    component: Layout,
    name: 'record',
    meta: { title: '日志审计', icon: 'audit', noCache: true, roles: [4] },
    children: [
      {
        path: '/record/login',
        component: () => import('@/views2/record/login'),
        name: 'login',
        meta: { title: '登录日志', icon: 'loginlog', noCache: true, roles: [10] }
      },
      {
        path: '/record/operate',
        component: () => import('@/views2/record/operate'),
        name: 'operate',
        meta: { title: '操作日志', icon: 'operatelog', noCache: true, roles: [11] }
      },
      {
        path: '/record/push',
        component: () => import('@/views2/record/push'),
        name: 'push',
        meta: { title: '推送日志', icon: 'pushlog', noCache: true, roles: [12] }
      }
    ]
  },
  {
    path: '/liquidity',
    component: Layout,
    name: 'liquidity',
    meta: { title: '流动性预测', icon: 'liquidity', noCache: true, roles: [13] },
    children: [
      {
        path: '/liquidity/fundsMonitor',
        component: () => import('@/views2/liquidity/fundsMonitor'),
        name: 'fundsMonitor',
        meta: { title: '资金盈余/缺口监测', icon: 'fundsmonitor', noCache: true, roles: [14] }
      },
      {
        path: '/liquidity/matchingMonitor',
        component: () => import('@/views2/liquidity/matchingMonitor'),
        name: 'matchingMonitor',
        meta: { title: '期限匹配度监测', icon: 'matchingmonitor', noCache: true, roles: [15] }
      },
      {
        path: '/liquidity/renewal',
        component: () => import('@/views2/liquidity/renewal'),
        name: 'renewal',
        meta: { title: '续期效果监测', icon: 'reports', noCache: true, roles: [34] },
        children: [
          {
            path: '/liquidity/renewal/applyRenewal',
            component: () => import('@/views2/liquidity/renewal/applyRenewal'),
            name: 'applyRenewal',
            meta: { title: '申请续期监测', icon: 'datareport', roles: [35] }
          },
          {
            path: '/liquidity/renewal/paymentRenewal',
            component: () => import('@/views2/liquidity/renewal/paymentRenewal'),
            name: 'paymentRenewal',
            meta: { title: '兑付日影响监测', icon: 'datareport', roles: [36] }
          },
          {
            path: '/liquidity/renewal/normalRenewal',
            component: () => import('@/views2/liquidity/renewal/normalRenewal'),
            name: 'normalRenewal',
            meta: { title: '普通智选兑付监测', icon: 'datareport', roles: [37] }
          }
        ]
      }
    ]
  },
  {
    path: 'reportMarket',
    component: Layout,
    name: 'reportMarket',
    meta: { title: '报表超市', icon: 'chart', noCache: true, roles: [17] },
    children: [
      {
        path: '/reportMarket/statisticReport',
        component: () => import('@/views2/reportMarket/statisticReport'),
        name: 'statisticReport',
        meta: { title: 'HXJK统计报表', icon: 'reports', noCache: true, roles: [18] },
        children: [
          {
            path: '/reportMarket/statisticReport/consumptionDay',
            component: () => import('@/views2/reportMarket/statisticReport/consumptionDay'),
            name: 'consumptionDay',
            meta: { title: '业务发展整体日报', icon: 'datareport', roles: [19] }
          },
          {
            path: '/reportMarket/statisticReport/consumptionWeek',
            component: () => import('@/views2/reportMarket/statisticReport/consumptionWeek'),
            name: 'consumptionWeek',
            meta: { title: '业务发展整体周报', icon: 'datareport', roles: [20] }
          },
          {
            path: '/reportMarket/statisticReport/consumptionMonth',
            component: () => import('@/views2/reportMarket/statisticReport/consumptionMonth'),
            name: 'consumptionMonth',
            meta: { title: '业务发展整体月报', icon: 'datareport', noCache: true, roles: [21] }
          }
        ]
      },
      {
        path: '/reportMarket/jYTReport',
        component: () => import('@/views2/reportMarket/jYTReport'),
        name: 'jYTReport',
        meta: { title: 'JYT统计报表', icon: 'reports', noCache: true, roles: [24] },
        children: [
          {
            path: '/reportMarket/jYTReport/jYTDay',
            component: () => import('@/views2/reportMarket/jYTReport/jYTDay'),
            name: 'jYTDay',
            meta: { title: '业务发展整体日报', icon: 'datareport', roles: [25] }
          },
          {
            path: '/reportMarket/jYTReport/jYTWeek',
            component: () => import('@/views2/reportMarket/jYTReport/jYTWeek'),
            name: 'jYTWeek',
            meta: { title: '业务发展整体周报', icon: 'datareport', roles: [26] }
          },
          {
            path: '/reportMarket/jYTReport/jYTMonth',
            component: () => import('@/views2/reportMarket/jYTReport/jYTMonth'),
            name: 'jYTMonth',
            meta: { title: '业务发展整体月报', icon: 'datareport', noCache: true, roles: [27] }
          }
        ]
      }
    ]
  },
  {
    path: 'thematic',
    component: Layout,
    name: 'thematic',
    meta: { title: '专题分析', icon: 'thematic', noCache: true, roles: [22] },
    alwaysShow: true,
    children: [
      {
        path: '/thematic/friendCycle',
        component: () => import('@/views2/thematic/friendCycle'),
        name: 'friendCycle',
        meta: { title: '朋友圈', icon: 'datareport', noCache: true, roles: [23] }
      },
      {
        path: '/thematic/keep',
        component: () => import('@/views2/thematic/keep'),
        name: 'keep',
        meta: { title: '留存分析', icon: 'datareport', noCache: true, roles: [37] }
      }
    ]
  },
  {
    path: 'industry ',
    component: Layout,
    name: 'industry',
    meta: { title: '行业监控', icon: 'industry', noCache: true, roles: [28] },
    alwaysShow: true,
    children: [
      {
        path: '/industry/competitorTotalInvest',
        component: () => import('@/views2/industry/competitorTotalInvest'),
        name: 'competitorTotalInvest',
        meta: { title: '平台出借额监控', icon: 'datareport', noCache: true, roles: [29] }
      },
      {
        path: '/industry/topLendingMonitor',
        component: () => import('@/views2/industry/topLendingMonitor'),
        name: 'topLendingMonitor',
        meta: { title: '头部平台出借监控', icon: 'datareport', noCache: true, roles: [30] }
      }
    ]
  },
  {
    path: 'operate',
    component: Layout,
    name: 'operate',
    meta: { title: '运营监测', icon: 'operate', noCache: true, roles: [31] },
    alwaysShow: true,
    children: [
      {
        path: '/operate/operateView',
        component: () => import('@/views2/operate/operateView'),
        name: 'operateView',
        meta: { title: '运营看板', icon: 'operateView', noCache: true, roles: [32] },
        alwaysShow: true,
        children: [
          {
            path: '/operate/operateView/operateDay',
            component: () => import('@/views2/operate/operateView/operateDay'),
            name: 'operateDay',
            meta: { title: '运营日报', icon: 'datareport', roles: [33] }
          }
        ]
      },
      {
        path: '/operate/lossUser',
        name: 'lossUser',
        component: () => import('@/views2/operate/lossUser'),
        meta: { title: '流失用户', icon: 'operateView', noCache: true, roles: [34] },
        alwaysShow: true,
        children: [
          {
            path: '/operate/lossUser/daily',
            component: () => import('@/views2/operate/lossUser/daily'),
            name: 'lossUserDaily',
            meta: { title: '流失用户召回日报', icon: 'datareport', roles: [35] }
          },
          {
            path: '/operate/lossUser/target',
            component: () => import('@/views2/operate/lossUser/target'),
            name: 'lossUserTarget',
            meta: { title: '流失用户召回目标', icon: 'datareport', roles: [36] }
          }
        ]
      }
    ]
  }
]
