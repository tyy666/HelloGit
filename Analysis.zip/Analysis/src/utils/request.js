import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import { getToken } from '@/utils/auth'
import qs from 'qs'
// create an axios instance
const service = axios.create({
  baseURL: process.env.BASE_API, // api的base_url
  timeout: 60000 // request timeout
})

let timestamp = new Date().getTime()

// request interceptor
service.interceptors.request.use(
  config => {
    config.headers['Content-type'] = 'application/x-www-form-urlencoded'
    config.data = qs.stringify(config.data)
    // Do something before request is sent
    console.log()
    if (!config.methods || config.methods === 'get') {
      config.params = Object.assign({}, config.params, {
        '_': timestamp++
      })
    }
    if (store.getters.token) {
      // 让每个请求携带token-- ['X-Token']为自定义key 请根据实际情况自行修改
      config.headers['adoptToken'] = getToken()
    }
    return config
  },
  error => {
    // Do something with request error
    console.log(error) // for debug
    Promise.reject(error)
  }
)

// respone interceptor
service.interceptors.response.use(

  response => {
    const res = response.data
    if (res.status !== 0) {
      if (/^TOKEN/.test(res.message)) {
        MessageBox.confirm('TOKEN已失效，可以取消继续留在该页面，或者重新登录', '确定登出', {
          confirmButtonText: '重新登录',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          store.dispatch('FedLogOut').then(() => {
            location.reload() // 为了重新实例化vue-router对象 避免bug
          })
        })
      } else {
        Message({
          message: res.message || '未知错误',
          type: 'error',
          duration: 3 * 1000
        })
      }
      // return Promise.reject('error')
      return response
    } else {
      return response
    }
  },
  error => {
    console.error(error) // for debug
    let errorMsg = error.message
    if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
      errorMsg = `用时${error.config.timeout / 1000}秒，请求超时！`
    }
    Message({
      message: errorMsg,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(error)
  }
)

export default service
