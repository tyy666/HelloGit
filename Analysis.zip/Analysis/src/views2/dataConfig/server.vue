<template>
  <div class="app-container">
    <el-container>
      <el-main v-loading="contentLoading">
        <el-card class="box-card" style="min-height:600px">
          <div slot="header" class="clearfix">
            <span>集群管理</span>
          </div>
          <el-form :inline="true" v-model="userSearch" class="demo-form-inline">
            <el-form-item label="服务器地址">
              <el-input v-model.trim="userSearch.serverIp" clearable />
            </el-form-item>
            <el-form-item label="host名称">
              <el-input v-model.trim="userSearch.host" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="getConfInfoBeatPage(1)">查询</el-button>
            </el-form-item>
          </el-form>
          <el-table :key="key" :data="confInfoBeat.records" border fit highlight-current-row style="width: 100%;margin-bottom: 20px">
            <el-table-column v-for="fruit in formThead" :show-overflow-tooltip="true" :key="fruit.en" :prop="fruit.en" :label="fruit.cn" :width="(fruit.en==='serverIp' || fruit.en==='host'|| fruit.en==='cpu' || fruit.en==='os'|| fruit.en==='memory' || fruit.en==='disk' || fruit.en==='network') ? '350' : (( fruit.en==='beatTime') ? '155':'100')">
              <template slot-scope="scope">
                <span v-if="fruit.en==='createTime'||fruit.en==='modifyTime' || fruit.en==='beatTime'">
                  {{ getNowFormatDate(scope.row[fruit.en]) }}
                </span>
                <span v-else-if="fruit.en==='instruction'">
                  {{ getInstructionName(scope.row[fruit.en]) }}
                </span>
                <span v-else-if="fruit.en==='serverStatus'">
                  {{ getServerStatus(scope.row) }}
                </span>
                <span v-else-if="fruit.en==='memory'">
                  <span :title="getMemoryProgressTitle(scope.row[fruit.en])">
                    <el-progress :text-inside="true" :stroke-width="20" :percentage="getMemoryProgress(scope.row[fruit.en])"/>
                  </span>
                </span>
                <span v-else-if="fruit.en==='cpu'">
                  <span>
                    <el-progress :text-inside="true" :stroke-width="20" :percentage="Math.ceil(100*(scope.row[fruit.en]))"/>
                  </span>
                </span>
                <span v-else-if="fruit.en==='disk'">
                  <span :title="getDiskProgressTitle(scope.row[fruit.en])">
                    <el-progress :text-inside="true" :stroke-width="20" :percentage="getDiskProgress(scope.row[fruit.en])"/>
                  </span>
                </span>
                <span v-else>
                  {{ scope.row[fruit.en] }}
                </span>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              align="center"
              width="50px">
              <template slot-scope="scope">
                <el-popover
                  :ref="`record-${scope.$index}`"
                  v-model="scope.deleteVisible"
                  trigger="click"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click.stop="deleteConfInfoBeat(scope.row,scope);">确定</el-button>
                    <el-button type="primary" size="mini" @click.stop="scope._self.$refs[`record-${scope.$index}`].doClose()">取消</el-button>
                  </div>
                  <el-button slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete" @click="scope.deleteVisible = !scope.deleteVisible" />
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="confInfoBeat.records&&confInfoBeat.records.length"
            :total="confInfoBeat.total"
            :current-page.sync="confInfoBeat.currentPage"
            :page-size.sync="confInfoBeat.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="getConfInfoBeatPage"/>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
const defaultFormThead = [
  { en: 'serverIp', cn: '服务端地址' },
  { en: 'beatTime', cn: '服务器最近心跳时间' },
  { en: 'beatCycle', cn: '服务器心跳间隔' },
  { en: 'serverStatus', cn: '服务器状态' },
  { en: 'host', cn: 'host名称' },
  { en: 'os', cn: '操作系统' },
  { en: 'cpu', cn: 'CPU' },
  { en: 'memory', cn: '内存' },
  { en: 'disk', cn: '磁盘' },
  { en: 'network', cn: '网络' }
]
export default{
  name: 'UserManage',
  data() {
    return {
      contentLoading: false,
      userSearch: {
        host: '',
        serverIp: ''
      },
      confInfoBeat: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      key: 1, // table key
      formThead: defaultFormThead
    }
  },
  watch: {
  },
  created() {
    const vm = this
    vm.getConfInfoBeatPage(1)
  },
  methods: {
    getConfInfoBeatPage(currentPage) {
      const vm = this
      const params = {
        currentPage: currentPage,
        pageSize: vm.confInfoBeat.pageSize,
        serverIp: vm.userSearch.serverIp,
        host: vm.userSearch.host
      }
      request.post('/configure/confInfoBeat/getConfInfoBeatPage', params)
        .then((res) => {
          if (res.data.status === 0) {
            vm.confInfoBeat.records = res.data.result.result
            vm.confInfoBeat.total = res.data.result.totalCount
            vm.confInfoBeat.currentPage = currentPage
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 切换当前页条数
    sizeChange(pageSize) {
      const vm = this
      vm.confInfoBeat.pageSize = pageSize
      vm.getConfInfoBeatPage(1)
    },
    // 时间格式化
    getNowFormatDate(date) {
      if (!date) { return '' }
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    // 格式化指令
    getInstructionName(instruction) {
      if (instruction === 0) {
        return '无指令'
      } else if (instruction === 1) {
        return 'Ehcache指令'
      }
    },
    // 格式化内存
    getMemoryProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4))
    },
    // 格式化内存title
    getMemoryProgressTitle(memory) {
      memory = JSON.parse(memory)
      return memory.used + '/' + memory.total + '  ' + Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4)) + '%  used'
    },
    // 格式化磁盘
    getDiskProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used / memory.total)
    },
    // 格式化磁盘title
    getDiskProgressTitle(memory) {
      memory = JSON.parse(memory)
      return Math.round(memory.used / (1024 * 1024 * 1024)) + 'GiB/' + Math.round(memory.total / (1024 * 1024 * 1024)) + 'GiB  ' + Math.round(100 * memory.used / memory.total) + '%  used'
    },
    // 判断服务是否存活
    getServerStatus(row) {
      const nowDate = new Date()
      const beatTime = new Date(row.beatTime)
      const diff = (nowDate.getTime() - beatTime.getTime()) / 1000
      if (diff > 3 * row.beatCycle) {
        return 'DEAD'
      } else {
        return 'LIVE'
      }
    },
    deleteConfInfoBeat(row, scope) {
      const vm = this
      // 校验是否存活
      const status = vm.getServerStatus(row)
      if (status === 'LIVE') {
        vm.$message({
          showClose: true,
          message: '当前服务存活，禁止删除！',
          type: 'error'
        })
        scope._self.$refs[`record-${scope.$index}`].doClose()
      } else if (status === 'DEAD') {
        request.post('/configure/confInfoBeat/deleteConfInfoBeat', row)
          .then((res) => {
            if (res.data.status === 0) {
              vm.getConfInfoBeatPage(1)
              scope._self.$refs[`record-${scope.$index}`].doClose()
            }
          })
          .catch((err) => {
            console.log(err)
          })
      }
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
.filter-container{
  position: absolute;
  width:300px;
  z-index:100;
  background-color: #fff;
  border:1px solid #dcdfe6;
  right:0;
  padding-left:10px;
  padding-top:3px;
  border-radius:4px;
}
.filter-container .el-checkbox{
  margin:0;
  width:50%;
}
/deep/ .el-dialog__headerbtn{
  z-index:1000;
}
.el-tabs--top{
  position: relative;
  top:-45px;
}
.avatar{
  width: 200px;
  height: 200px;
  border-radius: 50%;
}
.btnTwo{
  text-align:right;
  padding-right:122px;
}
.changeAvatar{
  padding-left:38px;
  margin-bottom:20px;
}
.changeAvatar>img{
  max-width:100px;
  max-height:100px;
  position:relative;
  top:13px;
  left:10px;
}
.el-button+.el-button{
  margin-left:0;
}
/deep/ .el-transfer-panel{
  width:410px;
}
.sumitRow{
  float:right;
  margin-top:20px;
}
.libraryType1{
  width:180px;
}
.powerBool .el-input{
  width:180px;
}
.modifyPassword{
  margin-top:30px;
  width:50%;
}
</style>
