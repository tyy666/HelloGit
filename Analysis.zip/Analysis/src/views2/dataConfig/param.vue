<template>
  <div class="app-container">
    <el-container>
      <!-- 参数配置 左侧树 -->
      <el-aside width="300px">
        <el-card>
          <tree
            ref="dataTree"
            :data="treeData"
            :check-on-click-node="false"
            :expand-on-click-node="false"
            :highlight-current="true"
            node-key="id"
            default-expand-all
            @node-click="clickTreeNode"
          >
            <span slot-scope="{node, data}" class="custom-tree-node">
              <span>{{ node.label }}</span>
              <span>
                <i class="fa fa-folder" title="添加配置节点" @click.stop="() => appendParamConfig(node)" />
                <i v-if="node.data.level !=null && node.data.level > 1" class="fa fa-edit" title="编辑" @click.stop="() => editParamConfig(node)" />
                <el-popover
                  v-if="(node.data.level !=null && node.data.level > 1 )&&(!node.data.children || node.data.children.length === 0)"
                  v-model="node.visible_del"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click.stop="() => removeParamConfig(node)">确定</el-button>
                    <el-button size="mini" type="primary" @click.stop="node.visible_del = false">取消</el-button>
                  </div>
                  <i slot="reference" class="fa fa-times-circle" title="删除" @click.stop="node.visible_del = !node.visible_del" />
                </el-popover>
              </span>
            </span>
          </tree>
        </el-card>
      </el-aside>
      <!-- 配置节点下的配置项 -->
      <el-main v-loading="contentLoading" v-show="showConfInfo">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>配置项清单</span>
          </div>
          <el-form :inline="true" v-model="paramConfInfoSearch" class="demo-form-inline">
            <el-form-item label="配置项编号">
              <el-input v-model.trim="paramConfInfoSearch.itemKey" placeholder="模糊查询"/>
            </el-form-item>
            <el-form-item label="配置项值">
              <el-input v-model.trim="paramConfInfoSearch.itemValue" placeholder="模糊查询"/>
            </el-form-item>
            <el-form-item label="配置项名称">
              <el-input v-model.trim="paramConfInfoSearch.itemName" placeholder="模糊查询"/>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="paramConfInfoSearchSubmit(1)">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="success" @click="addParamConfInfo">添加</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="success" @click="refreshCache">刷新缓存</el-button>
            </el-form-item>
          </el-form>
          <el-table
            ref="multipleTable"
            :data="paramConfInfoResult.records"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              fixed
              prop="id"
              label="ID"
              width="50"/>
            <el-table-column
              prop="itemKey"
              label="配置项编号"/>
            <el-table-column
              prop="itemValue"
              label="配置项值"/>
            <el-table-column
              prop="itemName"
              label="配置项名称"/>
            <el-table-column
              prop="createTime"
              label="创建时间">
              <template slot-scope="scope">
                <span style="margin-left: 5px">{{ getNowFormatDate(scope.row.createTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="createUser"
              label="创建人"/>
            <el-table-column
              prop="modifyTime"
              label="最新修改时间">
              <template slot-scope="scope">
                <span style="margin-left: 5px">{{ getNowFormatDate(scope.row.modifyTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="modifyUser"
              label="最新修改人"/>
            <el-table-column
              fixed="right"
              label="操作"
              align="center"
              width="130">
              <template slot-scope="scope">
                <el-tooltip class="item" effect="dark" content="修改" placement="top">
                  <el-button type="primary" icon="el-icon-edit" circle size="mini" @click="editParamConfInfo(scope.row)"/>
                </el-tooltip>
                <el-popover
                  :ref="`record-${scope.$index}`"
                  :v-model="deleteVisible"
                  trigger="click"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click="deleteParamConfInfo({visible:deleteVisible},scope)">确定</el-button>
                    <el-button type="primary" size="mini" @click="scope._self.$refs[`record-${scope.$index}`].doClose()">取消</el-button>
                  </div>
                  <el-button slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete"/>
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="paramConfInfoResult.total"
            :current-page="paramConfInfoResult.currentPage"
            :page-size="paramConfInfoResult.pageSize"
            :total="paramConfInfoResult.total"
            :page-sizes="[5,10,15,20]"
            layout="jumper, prev, pager, next,total, sizes "
            style="text-align: center"
            @size-change="handleSizeChange"
            @current-change="paramConfInfoSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>

    <!-- 添加/修改参数配置树 -->
    <el-dialog :title="(formParamConfig.id ? '修改' : '添加') + '参数节点'" :visible.sync="showInsertParamConfig">
      <el-form :model="formParamConfig" label-width="100px" label-position="left">
        <el-form-item label="参数节点名称">
          <el-input v-model.trim="formParamConfig.codeName" auto-complete="off" maxlength="512"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitParamConfig">确定</el-button>
        <el-button @click="cancelParamConfig">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加/修改参数配置项-->
    <el-dialog :title="(formParamConfInfo.id ? '修改' : '添加') + '配置项'" :visible.sync="showInsertParamConfInfo">
      <el-form :model="formParamConfInfo" label-width="90px" label-position="left">
        <el-form-item label="配置项编号">
          <el-input v-model.trim="formParamConfInfo.itemKey" auto-complete="off"/>
        </el-form-item>
        <el-form-item label="配置项值">
          <el-input v-model.trim="formParamConfInfo.itemValue" auto-complete="off"/>
        </el-form-item>
        <el-form-item label="配置项名称">
          <el-input v-model.trim="formParamConfInfo.itemName" auto-complete="off"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitInsertParamConfInfo">确定</el-button>
        <el-button type="primary" @click="cancelInsertParamConfInfo">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import tree from '../../components/tree'
import request from '@/utils/request'
// 复用组件时 export default {}
export default {
  // 指定name允许组件自身递归调用
  name: 'DataSource',
  // 自定义组件
  components: {
    tree
  },
  // 定义对象初始化值
  data() {
    return {
      // 定义table对象初始化值
      tableInfo: {},
      // 点击选中的节点类型 目录or数据库
      dbOrDirtype: '',
      // 控制删除数据源弹出框是否显示
      deleteVisible: false,
      // 定义数据源查询表单初始化值
      paramConfInfoSearch: {
        itemKey: '',
        itemValue: '',
        itemName: ''
      },
      // 定义查询数据源返回初始化值
      paramConfInfoResult: {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        records: []
      },
      // 初始化定义点击树节点Pid值
      editingPid: -1,
      // 初始化定义点击树节点id值
      editingId: null,
      // 初始化是否显示loading效果
      contentLoading: false,

      // 增加或者修改参数配置树的对象
      formParamConfig: {
        id: null,
        codePid: null,
        codeName: ''
      },
      // visible.sync 控制 dialog显示。是否显示I-M目录页面
      showInsertParamConfig: false,
      // 初始化赋值tree树值
      treeData: [{
        label: '参数管理',
        id: -1,
        type: 'folder',
        children: []
      }],
      // 设置是否初始化库类型
      requestedDic: false,
      // 定义库类型初始化值
      dicTypeList: [],

      // visible.sync 控制 dialog显示。是否显示I-M数据源页面
      showInsertParamConfInfo: false,

      // 定义数据源表单初始化值
      formParamConfInfo: {
        sourceInfo: null
        // hint: null
      },
      // 标记JSON编辑第几行值
      showSourceKey: -1,
      // 定义库JSON配置缓存
      sourceInfoCache: {},

      // visible.sync 控制 dialog显示。是否显示I-M数据表页面
      showInsertTable: false,

      // 定义RDBMS schema集合
      schemaList: [],
      // 定义RDBMS table集合
      tableList: [],
      // 定义table表单初始化
      formTable: {
        tables: []
      },
      // 定义column表单初始化
      tableColumns: {
        records: []
      },
      // 页面查询参数
      pageParams: {},
      // 右侧配置项清单
      showConfInfo: false
    }
  },
  // 计算属性关键词: computed。 可以使用 methods 来替代 computed，效果上两个都是一样的，但是 computed 是基于它的依赖缓存，只有相关依赖发生改变时才会重新取值。而使用 methods ，在重新渲染的时候，函数总会重新调用执行。
  computed: {

  },
  // 初始化创建
  mounted() {
    const vm = this
    // 初始化树形
    vm.getParamConfigTree()
  },
  // 自定义methods方法
  methods: {
    // 查询左侧参数配置树
    getParamConfigTree() {
      const vm = this
      request.post('/configure/getParamConfCodeTree', { adoptToken: localStorage.adoptToken })
        .then(function(res) {
          if (res) {
            vm.treeData = [res.data.result]
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    // 打开添加参数节点页面
    appendParamConfig(node) {
      const vm = this
      vm.formParamConfig = {}
      vm.formParamConfig.codePid = node.data.id
      vm.$nextTick(function() {
        vm.showInsertParamConfig = true
      })
    },
    // 打开编辑参数节点页面
    editParamConfig(node) {
      const vm = this
      vm.formParamConfig = {}
      vm.formParamConfig.codePid = node.data.pid
      vm.formParamConfig.id = node.data.id
      vm.formParamConfig.codeName = node.data.label
      vm.$nextTick(function() {
        vm.showInsertParamConfig = true
      })
    },
    // 提交添加或者修改参数节点
    submitParamConfig() {
      const vm = this
      let url = ''
      if (vm.formParamConfig.id) {
        // 修改
        url = '/configure/modifyParamConfCode'
      } else {
        // 添加
        url = '/configure/createParamConfCode'
      }
      request.post(url, vm.formParamConfig)
        .then(function(res) {
          if (res.data.status !== 0) {
            vm.$message({
              showClose: true,
              message: res.data.message,
              type: 'success'
            })
          } else {
            vm.$message({
              showClose: true,
              message: '保存成功！',
              type: 'success'
            })
            vm.showInsertParamConfig = false
            vm.formParamConfig = {}
            vm.getParamConfigTree()
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    // 关闭添加或者修改参数节点页面
    cancelParamConfig() {
      const vm = this
      vm.showInsertParamConfig = false
      vm.formParamConfig = {}
    },
    // 删除参数配置树节点以及参数配置项
    removeParamConfig(node) {
      const vm = this
      const deleteParamConfCodeParams = {
        codeId: node.data.id
      }
      const url = '/configure/deleteParamConfCodeAndInfo'
      request.post(url, deleteParamConfCodeParams)
        .then(function(res) {
          vm.$message({
            showClose: true,
            message: '删除成功！',
            type: 'success'
          })
          vm.getParamConfigTree()
          vm.paramConfInfoSearchSubmit(1)
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    // 点击树节点查询配置项清单
    clickTreeNode(data, node, e) {
      const vm = this
      vm.pageParams.codeId = data.id
      vm.paramConfInfoSearchSubmit(1)
    },
    // 查询分页数据
    paramConfInfoSearchSubmit(currentPage) {
      const vm = this
      vm.pageParams.currentPage = currentPage
      vm.pageParams.pageSize = vm.paramConfInfoResult.pageSize
      vm.pageParams.itemKey = vm.paramConfInfoSearch.itemKey
      vm.pageParams.itemValue = vm.paramConfInfoSearch.itemValue
      vm.pageParams.itemName = vm.paramConfInfoSearch.itemName
      request.post('/configure/getParamConfInfoPage', vm.pageParams)
        .then((res) => {
          if (res) {
            vm.showConfInfo = true
            vm.paramConfInfoResult.total = res.data.result.totalCount
            vm.paramConfInfoResult.records = res.data.result.result
            vm.paramConfInfoResult.currentPage = currentPage
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    // 切换条数
    handleSizeChange(pageSize) {
      const vm = this
      vm.paramConfInfoResult.pageSize = pageSize
      vm.paramConfInfoSearchSubmit(1)
    },
    // 添加参数配置树配置项
    addParamConfInfo() {
      const vm = this
      vm.formParamConfInfo = {}
      vm.formParamConfInfo.codeId = vm.pageParams.codeId
      vm.showInsertParamConfInfo = true
    },
    // 提交或修改参数配置项
    submitInsertParamConfInfo() {
      const vm = this
      let url
      if (vm.formParamConfInfo.id) {
        // 修改
        url = '/configure/modifyParamConfInfo'
      } else {
        // 添加
        url = '/configure/createParamConfInfo'
      }
      request.post(url, vm.formParamConfInfo)
        .then(function(res) {
          if (res.data.status !== 0) {
            vm.$message({
              showClose: true,
              message: res.data.message,
              type: 'error'
            })
          } else {
            vm.$message({
              showClose: true,
              message: '保存成功！',
              type: 'success'
            })
            vm.showInsertParamConfInfo = false
            if (vm.formParamConfInfo.id) {
              // 修改
              vm.paramConfInfoSearchSubmit(vm.pageParams.currentPage)
            } else {
              // 添加
              vm.paramConfInfoSearchSubmit(1)
            }
            vm.formParamConfInfo = {}
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    // 取消添加或修改参数配置项
    cancelInsertParamConfInfo() {
      const vm = this
      vm.showInsertParamConfInfo = false
      vm.formParamConfInfo = {}
    },
    // 编辑当前行信息
    editParamConfInfo(row) {
      const vm = this
      vm.formParamConfInfo = {}
      vm.formParamConfInfo.id = row.id
      vm.formParamConfInfo.itemKey = row.itemKey
      vm.formParamConfInfo.itemValue = row.itemValue
      vm.formParamConfInfo.itemName = row.itemName
      vm.showInsertParamConfInfo = true
    },
    // 删除参数配置项
    async deleteParamConfInfo(visible, data) {
      visible.deleteVisible = false
      const vm = this
      await request.post('/configure/deleteParamConfInfoById', {
        id: data.row.id
      })
        .then(function(res) {
          if (res.data.status !== 0) {
            vm.$message({
              showClose: true,
              message: res.data.message,
              type: 'success'
            })
          } else {
            vm.$message({
              showClose: true,
              message: '删除成功！',
              type: 'success'
            })
            vm.paramConfInfoSearchSubmit(1)
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    refreshCache() {
      const vm = this
      request.post('/configure/refreshParamCache')
        .then(function(res) {
          vm.$message({
            showClose: true,
            message: '缓存刷新成功！',
            type: 'success'
          })
        })
        .catch(function(err) {
          console.log(err)
        })
    },
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    }
  }
}
</script>
<style scoped>
/deep/ .el-dialog__body{
  padding:30px 30px;
}
.el-main{
  padding: 0 0 0 20px;
}
.lq_json_editor dt{
  line-height: 1.5;
  font-size: 12px;
  overflow: hidden;
}
.lq_json_editor:before{
  content: '{';
  display: block;
}
.lq_json_editor:after{
  content: '}';
  display: block;
}
.lq_json_editor .del_line{
  color: lightgray;
  text-decoration: line-through;
}
.lq_json_editor dt{
  display: inline-block;
  float: left;
  padding: 1px 0 1px 18px;
}
.lq_json_editor dd:before{
  display: inline-block;
  overflow: hidden;
  content: ': ';
  color: gray;
  float: left;
  margin-right: 5px;
  padding: 1px 0;
  margin-bottom: 9px;
  position: relative;
  top:-9px;
}
.lq_json_editor dd{
  display: block;
  overflow: hidden;
  margin: 0;
  color: #1A1A1A;
}
.lq_json_editor dd:after{
  clear: both;
}
.lq_json_editor .input_val{
  display: inline-block;
  line-height: 1.5;
  font-size: 12px;
  padding: 0;
  margin: 0;
  vertical-align: top;
  border: 1px solid transparent;
  min-width: 36px;
  word-wrap: break-word;
  outline: none;
  padding: 0 3px;
  position:relative;
  color: transparent;
}
.lq_json_editor .input_val input{
  padding: 0;
  margin: 0;
  border: 0;
  background: transparent;
  outline: none;
  line-height: 1.5;
  font-size: 12px;
  display: inline-flex;
  position:absolute;
  width: 100%;
  left: 3px;
  top: 0px;
  font-weight: normal;
  vertical-align: top;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Arial, sans-serif;
}
.lq_json_editor .input_val:hover, .lq_json_editor .input_val:focus{
  background-color: #FFFFAB;
  border: 1px solid #ff0;
  border-radius: 2px;
}
.lq_json_editor .input_val.number input{
  color: #ee422e;
}
.lq_json_editor .input_val.noval{
  width: 300px;
  border-color: #d3d3d3;
  border-style: dashed;
  border-radius: 2px;
}
.lq_json_editor .input_key.noval{
  width:auto;
}
.lq_json_editor .input_val.noval:after{
  color:#d3d3d3;
  content: 'value';
}
.lq_json_editor .input_key.noval:after{
  color:#d3d3d3;
  content: 'key';
}
.lq_json_editor .input_val.number.noval:after{
  color:#d3d3d3;
  content: 'number';
}
.lq_json_editor .el-button{
  float: right;
}
.el-button--mini.is-circle{
  padding:3px;
}

.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
.custom-tree-node>span:first-child{
  max-width:140px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap
}
</style>
