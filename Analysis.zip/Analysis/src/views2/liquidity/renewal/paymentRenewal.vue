<template>
  <div class="dashboard-editor-container">
    <el-card class="box-card">
      <el-form :inline="true" v-model="searchForm" class="demo-form-inline funds">
        <el-row>
          <el-col :span="20">
            <el-form-item label="申请续期时间:">
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="searchForm.startTime"
                placeholder="开始日期"
              />
              -
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="searchForm.endTime"
                placeholder="结束日期"
              />
            </el-form-item>
            <el-form-item label="影响兑付时间:">
              <el-date-picker
                v-if="searchForm.timeLevel === '1'"
                :editable="false"
                :clearable="false"
                v-model="searchForm.startPaymentTime"
                placeholder="开始日期"
              />
              <el-date-picker
                v-else
                :editable="false"
                :clearable="false"
                v-model="searchForm.startPaymentTime"
                placeholder="开始日期"
                type="month"
              />
              -
              <el-date-picker
                v-if="searchForm.timeLevel === '1'"
                :editable="false"
                :clearable="false"
                v-model="searchForm.endPaymentTime"
                placeholder="结束日期"
              />
              <el-date-picker
                v-else
                :editable="false"
                :clearable="false"
                v-model="searchForm.endPaymentTime"
                placeholder="结束日期"
                type="month"
              />
            </el-form-item>
            <el-form-item label="显示维度:">
              <el-radio v-model="searchForm.timeLevel" label="1">按日</el-radio>
              <el-radio v-model="searchForm.timeLevel" label="2">按月</el-radio>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-button type="primary" @click="searchSubmit()">查询</el-button>
            <el-button type="primary" @click="exportSubmit()">导出</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <chart ref="getChart" :chart-data="competitorData"/>
      <div style="margin-left: 2%;">
        <span style="font-weight: bold;">累计已续期金额：{{ totalMoney }}万</span>
        <span style="margin-left: 50px;font-weight: bold;">累计已续期用户数：{{ totalUser }}</span>
      </div>
    </el-row>
  </div>
</template>
<script>
import request from '@/utils/request'
import chart from '../../eCharts/chart'
import fileDownload from 'js-file-download'
import { getToken } from '@/utils/auth'
import axios from 'axios'
export default{
  components: {
    chart
  },
  data() {
    return {
      contentLoading: false,
      totalMoney: 0,
      totalUser: 0,
      searchForm: {
        startTime: '',
        endTime: '',
        startPaymentTime: '',
        endPaymentTime: '',
        timeLevel: '1'
      },
      competitorData: {
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          top: 20,
          itemGap: 13,
          data: ['已续期金额(万元)', '已续期用户数']
        },
        grid: {
          top: 100,
          left: '2%',
          right: '6%',
          bottom: '2%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          name: '日期(天)',
          boundaryGap: true,
          data: []
        }],
        yAxis: [{
          type: 'value',
          name: '额度(万)',
          position: 'left'
        }, {
          type: 'value',
          name: '人数',
          position: 'right'
        }],
        series: [{
          data: [],
          type: 'line',
          name: '已续期金额(万元)',
          yAxisIndex: 0,
          barWidth: 30
        }, {
          data: [],
          type: 'line',
          name: '已续期用户数',
          yAxisIndex: 1,
          barWidth: 30
        }]
      }
    }
  },
  async created() {
    const vm = this
    // 初始化查询时间
    vm.searchForm.startTime = new Date(new Date().getTime() - 30 * 24 * 60 * 60 * 1000)
    vm.searchForm.endTime = new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
    vm.searchForm.startPaymentTime = new Date(new Date().getTime() + 1 * 24 * 60 * 60 * 1000)
    vm.searchForm.endPaymentTime = new Date(new Date().getTime() + 180 * 24 * 60 * 60 * 1000)
    // 获取续期监测数据
    vm.getPaymentRenewal()
  },
  methods: {
    // 获取续期监测数据
    getPaymentRenewal() {
      const vm = this
      var params = {
        startTime: vm.getNowFormatDate(vm.searchForm.startTime),
        endTime: vm.getNowFormatDate(vm.searchForm.endTime),
        startPaymentTime: vm.getNowFormatDate(vm.searchForm.startPaymentTime),
        endPaymentTime: vm.getNowFormatDate(vm.searchForm.endPaymentTime),
        timeLevel: vm.searchForm.timeLevel
      }
      request.post('/report/liquidity/renewal/getPaymentRenewal', params)
        .then(res => {
          if (res.data.status === 0) {
            vm.competitorData.xAxis[0].data = []
            vm.competitorData.series[0].data = []
            vm.competitorData.series[1].data = []
            vm.totalMoney = 0
            vm.totalUser = 0
            res.data.result.forEach(ele => {
              vm.competitorData.xAxis[0].data.push(ele.paymentTime)
              vm.competitorData.series[0].data.push((ele.moneyNum / 10000).toFixed(2))
              vm.totalMoney += (ele.moneyNum - 0)
              vm.competitorData.series[1].data.push(ele.userNum)
              vm.totalUser += ele.userNum
            })
            vm.totalMoney = (vm.totalMoney / 10000).toFixed(2)
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 查询
    searchSubmit() {
      const vm = this
      vm.getPaymentRenewal()
    },
    // 导出
    exportSubmit() {
      const vm = this
      const param = new URLSearchParams()
      param.append('startTime', vm.getNowFormatDate(vm.searchForm.startTime))
      param.append('endTime', vm.getNowFormatDate(vm.searchForm.endTime))
      param.append('startPaymentTime', vm.getNowFormatDate(vm.searchForm.startPaymentTime))
      param.append('endPaymentTime', vm.getNowFormatDate(vm.searchForm.endPaymentTime))
      param.append('timeLevel', vm.searchForm.timeLevel)
      let url = process.env.BASE_API
      url += '/report/liquidity/renewal/downLoadPaymentRenewalCSV'
      axios({
        method: 'post',
        url: url,
        data: param,
        headers: {
          'adoptToken': getToken()
        },
        responseType: 'blob'
      }).then((res) => {
        fileDownload(res.data, vm.getFormatDate(vm.searchForm.startPaymentTime) + '-' + vm.getFormatDate(vm.searchForm.endPaymentTime) + '兑付日影响监测.csv')
      }).catch(function(error) {
        console.log(error)
      })
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    getFormatDate(date) {
      const vm = this
      const seperator1 = '-'
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      let currentdate = ''
      if (vm.searchForm.timeLevel === '1') {
        currentdate = year + seperator1 + month + seperator1 + strDate
      } else {
        currentdate = year + seperator1 + month
      }
      return currentdate
    }
  }
}
</script>
<style scoped lang="scss">
.el-main{
  padding:0;
}
/deep/ .funds .el-form-item__label{
  width:110px;
}
/deep/ .el-dialog__body{
  padding-top:10px;
  padding-bottom: 0;
}
/deep/ .el-select--medium{
  width:350px;
}
/deep/ .el-date-editor{
  width:168px;
}
.btnTwo{
  float: right;
}
/deep/ .el-table .cell{
  height:auto;
}
.times{
  overflow: hidden;
  padding-bottom:10px;
}
.times>span{
  float: left;
  width:25%;
  text-align: center;
  height:24px;
}
.funds .el-icon-setting{
  font-size:18px;
  position: relative;
  top:2px;
  cursor: pointer;
}
/deep/ .amtBalance span{
  padding-right:5px;
}
/deep/ .amtBalance i{
  cursor: pointer;
}
.earlyWarning{
  margin-bottom: 15px;
}
.earlyWarning i{
  font-style: normal;
  color:#f11b1b;
}
.earlyWarning>b{
  display: inline-block;
  width:110px;
  font-size:14px;
  color:#606266;
  text-align: right;
  font-weight:700;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
</style>
