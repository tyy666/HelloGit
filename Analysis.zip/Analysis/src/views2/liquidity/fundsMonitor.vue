<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <div slot="header" class="clearfix">
            <span>资金盈余/缺口监测</span>
          </div>
          <el-form :inline="true" v-model="fundsSearch" class="demo-form-inline funds">
            <el-row>
              <el-col :span="12">
                <el-form-item label="查询时间">
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="fundsSearch.startTime"
                    placeholder="开始日期"
                    @change="changeTime1"/>
                  -
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="fundsSearch.endTime"
                    placeholder="结束日期"
                    @change="changeTime2"/>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="显示维度">
                  <el-radio-group v-model="fundsSearch.reportType" @change="changeWD">
                    <el-radio label="M">按月</el-radio>
                    <el-radio label="D">按日</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="新成交量设置">
                  <el-select v-model="fundsSearch.newTurnover" placeholder="请选择" @change="newCSet">
                    <el-option v-for="item in latelyTradAvg" :label="item.typeName" :value="item.typeId" :key="item.typeId" />
                  </el-select>
                  <!-- <i v-show="set1" class="el-icon-setting" @click="setClick1"/> -->
                  <span v-show="set1" style="font-size:13px;color:#409EFF;cursor:pointer" @click="setClick1"><i class="el-icon-setting"/>额度设置</span>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="新放款量设置">
                  <el-select v-model="fundsSearch.newLending" placeholder="请选择" @change="newLoanSet">
                    <el-option v-for="item in latelyLoanAvg" :label="item.typeName" :value="item.typeId" :key="item.typeId" />
                  </el-select>
                  <!-- <i v-show="set2" class="el-icon-setting" @click="setClick2"/> -->
                  <span v-show="set2" style="font-size:13px;color:#409EFF;cursor:pointer" @click="setClick2"><i class="el-icon-setting"/>额度设置</span>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="还款量预估" class="prediction">
                  <el-input
                    v-enter-number2
                    v-model.trim="fundsSearch.repayment"
                    placeholder="请输入0-100的整数"
                    @keyup.native="storeCookie" />
                  <span>%</span>
                  <el-tooltip class="item" effect="dark" content="预估每天还款量占实际应还款量的比例" placement="right">
                    <i class="el-icon-question"/>
                  </el-tooltip>
                </el-form-item>
              </el-col>
              <el-col :span="12" style="padding-left:110px">
                <el-button type="primary" @click="fundSearchSubmit(1)">查询</el-button>
              </el-col>
            </el-row>
            <div v-show="earlyWarning" class="earlyWarning">
              <b>预警信息：</b>
              <span v-show="fundsSearch.reportType==='M'?false:true" class="daytime">
                平台会在<i>{{ earlyTime }}</i>日首次出现资金缺口<i>{{ earlyMount }}</i>万元；影响到正常业务，请关注！！！
              </span>
              <span v-show="fundsSearch.reportType==='M'?true:false" class="month">
                平台会在<i>{{ earlyTime }}</i>月累计出现资金缺口<i>{{ earlyMount }}</i>万元；请提前做好资金规划！！！
              </span>
            </div>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="fundsInfo.records"
            :row-class-name="tableRowClassName"
            border
            style="width: 100%">
            <el-table-column
              show-overflow-tooltip
              prop="businessDate"
              width="100px"
              label="日期"
              align="center">
              <template slot-scope="scope">
                <span>{{ fundsSearch.reportType==='M'?getMonth(scope.row.businessDate) : getNowFormatDate(scope.row.businessDate) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :render-header="renderHeader"
              :formatter="formatComma"
              show-overflow-tooltip
              prop="amtBalance"
              label-class-name="amtBalance"
              align="right"
              header-align="center"/>
            <el-table-column
              :formatter="formatComma"
              show-overflow-tooltip
              prop="repayAmt"
              label="借款人还款资金（万）"
              align="right"
              header-align="center"/>
            <el-table-column
              :formatter="formatComma"
              show-overflow-tooltip
              prop="dealAmt"
              label="新出借成交资金（万）"
              align="right"
              header-align="center"/>
            <el-table-column
              :formatter="formatComma"
              show-overflow-tooltip
              prop="waitCashAmt"
              label="智选待兑付本息和（万）"
              align="right"
              header-align="center"/>
            <el-table-column
              :formatter="formatComma"
              show-overflow-tooltip
              prop="packCashAmt"
              label="踏实赚到期兑付本息和（万）"
              align="right"
              header-align="center"/>
            <el-table-column
              :formatter="formatComma"
              show-overflow-tooltip
              prop="loanAmt"
              label="新放款资金（万）"
              align="right"
              header-align="center"/>
            <el-table-column
              :label="'前一'+(fundsSearch.reportType==='D'?'日':'月')+'盈余资金（万）'"
              :formatter="formatComma"
              show-overflow-tooltip
              prop="previousAmtBalance"
              align="right"
              header-align="center"/>
          </el-table>
          <el-pagination
            v-if="fundsInfo.records&&fundsInfo.records.length"
            :total="fundsInfo.total"
            :current-page.sync="fundsInfo.currentPage"
            :page-size.sync="fundsInfo.pageSize"
            :page-sizes="[5,10,15,20,50,100,200,300,500]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center;margin-top:10px"
            @size-change="sizeChange"
            @current-change="fundSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>

    <!-- 新成交量设置-自定义每日额度-弹窗 -->
    <el-dialog :visible.sync="newTradingShow" :title="configureType+'设置-自定义每日额度'" width="720px" class="newTrading" @close="closeNewTrading">
      <el-row style="padding-bottom:10px"><el-button type="success" @click="addRecords">添加记录</el-button></el-row>
      <el-table
        :data="configureType==='新成交量'?tradingTableData:loanTableData"
        border
        height="500px"
        style="width: 100%">
        <el-table-column
          prop="startDate"
          align="center"
          label="开始日期">
          <template slot-scope="scope">
            <el-date-picker :editable="false" :clearable="false" v-model="scope.row.startDate" type="date" placeholder="选择开始日期" />
          </template>
        </el-table-column>
        <el-table-column
          prop="endDate"
          align="center"
          label="结束日期">
          <template slot-scope="scope">
            <el-date-picker :editable="false" :clearable="false" v-model="scope.row.endDate" type="date" placeholder="选择结束日期" />
          </template>
        </el-table-column>
        <el-table-column
          prop="money"
          align="center"
          label="金额（万）">
          <template slot-scope="scope">
            <el-input v-enter-number2 v-model.trim="scope.row.money" class="amount" placeholder="请输入" clearable />
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="操作" align="center" width="60px">
          <template slot-scope="scope">
            <el-button slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete" @click="deleteT(scope)" />
          </template>
        </el-table-column>
      </el-table>
      <el-row style="height:60px;padding-top:10px;">
        <el-row class="btnTwo">
          <el-button @click="closeNewTrading">取消</el-button>
        <el-button type="primary" @click="tradingSubmit">提交</el-button></el-row>
      </el-row>
    </el-dialog>

    <el-dialog :visible.sync="centerDialogVisible" title="提示" width="520px" center>
      <el-container>
        <el-main style="max-height: 400px">
          <div class="times"><span v-for="item in timesArr" :key="item.index">{{ item }}</span></div>
        </el-main>
      </el-container>
      <div style="height:28px;padding-top:10px">以上时间段未设置新成交量,将会按照0来进行预测，是否确认提交?</div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="tipsCancel">取 消</el-button>
        <el-button type="primary" @click="tipsConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import request from '@/utils/request'
export default{
  data() {
    return {
      contentLoading: false,
      fundsSearch: {
        startTime: '',
        endTime: '',
        reportType: 'D',
        newTurnover: 2,
        newLending: 2,
        repayment: localStorage.getItem('repayment') ? localStorage.getItem('repayment') : 90,

        t1: '', // 新成交量设置
        t2: '' // 新放款量设置
      },
      fundsInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },

      // 新成交量设置
      latelyTradAvg: [],
      newTradingShow: false,
      tradingTableData: [],
      centerDialogVisible: false,
      timesArr: [],
      newConfigure1: '',
      configureType: '',
      set1: false,

      // 新放款量设置
      latelyLoanAvg: [],
      loanTableData: [],
      newConfigure2: '',
      set2: false,

      // 预警信息
      earlyWarning: true,
      earlyTime: '',
      earlyMount: ''

    }
  },
  beforeCreate() {

  },
  async created() {
    const vm = this
    const startDay = vm.getNowFormatDate(new Date())
    const startOne = startDay + ' ' + '00:00:00'
    const e1 = new Date(startOne).getTime() + 3600 * 1000 * 24 * 30
    const endDay = vm.getNowFormatDate(e1)
    vm.fundsSearch.startTime = startDay
    vm.fundsSearch.endTime = endDay

    const res = await request.post('/report/liquidity/getInitValueBean', {})
    if (res.data.status === 0) {
      vm.latelyTradAvg = res.data.result.latelyTradAvg
      vm.latelyLoanAvg = res.data.result.latelyLoanAvg

      if (res.data.result.latelyTradAvg.length > 0) {
        const t1 = res.data.result.latelyTradAvg.filter(item => item.typeId === 2)
        vm.fundsSearch.t1 = 2 + ':' + t1[0].tradAvg
      }
      if (res.data.result.latelyLoanAvg.length > 0) {
        const t2 = res.data.result.latelyLoanAvg.filter(item => item.typeId === 2)
        vm.fundsSearch.t2 = 2 + ':' + t2[0].loanAvg
      }
    }

    // 默认查询条件
    const params = {
      currentPage: 1,
      pageSize: 10,
      startTime: vm.fundsSearch.startTime,
      endTime: vm.fundsSearch.endTime,
      reportType: vm.fundsSearch.reportType,
      newTurnover: vm.fundsSearch.t1,
      newLending: vm.fundsSearch.t2,
      repayment: vm.fundsSearch.repayment
    }
    vm.contentLoading = true
    const ret = await request.post('/report/liquidity/getFundsMonitor', params)
    if (ret.data.status === 0) {
      vm.fundsInfo.records = ret.data.result.result
      vm.fundsInfo.total = ret.data.result.totalCount
      vm.fundsInfo.currentPage = ret.data.result.currentPage
    }
    vm.contentLoading = false

    const params22 = Object.assign({}, params)
    params22.currentPage = 1
    params22.pageSize = 99999
    const ret22 = await request.post('/report/liquidity/getFundsMonitor', params22)
    if (ret22.data.status === 0) {
      const amtBalanceArr = ret22.data.result.result.filter(item => item.amtBalance < 0)
      if (amtBalanceArr.length > 0) {
        vm.earlyWarning = true
        vm.earlyMount = amtBalanceArr[0].amtBalance
        vm.earlyTime = (vm.fundsSearch.reportType === 'M' ? vm.getMonth(amtBalanceArr[0].businessDate) : vm.getNowFormatDate(amtBalanceArr[0].businessDate))
      } else {
        vm.earlyWarning = false
      }
    }
  },
  methods: {
    renderHeader() {
      return (
        <div><span>资金盈余/缺口</span>
          <el-tooltip class='item' effect='dark' content='资金盈余/缺口=(新出借成交资金+借款人还款资金+前一日盈余资金)-(智选待兑付本息和+到期兑付踏实赚本息和+新放款资金)' placement='top'>
            <i class='el-icon-info'></i>
          </el-tooltip>
        </div>
      )
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    getMonth(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        if (month >= 1 && month <= 9) { month = '0' + month }
        const currentdate = year + seperator1 + month
        return currentdate
      }
    },
    storeCookie(event) {
      if (!/^\d+$/.test(event.target.value)) {
        event.target.value = (event.target.value + '').substring(0, event.target.value.length - 1)
      }
      localStorage.setItem('repayment', event.target.value)
    },
    async fundSearchSubmit(page) {
      const vm = this
      // if (vm.fundsSearch.newTurnover === 5) {
      //   const res1 = await request.post('/report/liquidity/getCustomizeFailValue',
      //     { newConfigure: vm.newConfigure1, maxQueryTime: vm.fundsSearch.endTime, configureType: '新成交量' })
      //   if (res1.data.status === 0) {
      //     if (!res1.data.result || res1.data.result.length === 0) {
      //       vm.fundsSearch.t1 = vm.newConfigure1
      //       vm.newTradingShow = false
      //     } else {
      //       vm.centerDialogVisible = true
      //       vm.timesArr = res1.data.result
      //     }
      //   }
      // }
      // if (vm.fundsSearch.newLending === 5) {
      //   const res2 = await request.post('/report/liquidity/getCustomizeFailValue',
      //     { newConfigure: vm.newConfigure2, maxQueryTime: vm.fundsSearch.endTime, configureType: '新放款量' })
      //   if (res2.data.status === 0) {
      //     if (!res2.data.result || res2.data.result.length === 0) {
      //       vm.fundsSearch.t2 = vm.newConfigure2
      //       vm.newTradingShow = false
      //     } else {
      //       vm.centerDialogVisible = true
      //       vm.timesArr = res2.data.result
      //     }
      //   }
      // }

      if (!vm.fundsSearch.t1) {
        vm.$message({
          showClose: true,
          message: '新成交量设置-自定义每日额度，未设置成功！',
          type: 'warning'
        })
      } else if (!vm.fundsSearch.t2) {
        vm.$message({
          showClose: true,
          message: '新放款量设置-自定义每日额度，未设置成功！',
          type: 'warning'
        })
      } else {
        vm.contentLoading = true
        vm.fundsInfo.currentPage = page
        const params = {
          currentPage: page,
          pageSize: vm.fundsInfo.pageSize,
          startTime: vm.fundsSearch.startTime,
          endTime: vm.fundsSearch.endTime,
          reportType: vm.fundsSearch.reportType,
          newTurnover: vm.fundsSearch.t1,
          newLending: vm.fundsSearch.t2,
          repayment: vm.fundsSearch.repayment
        }
        const ret = await request.post('/report/liquidity/getFundsMonitor', params)
        if (ret.data.status === 0) {
          vm.fundsInfo.records = ret.data.result.result
          vm.fundsInfo.total = ret.data.result.totalCount
          vm.fundsInfo.currentPage = ret.data.result.currentPage
        }
        vm.contentLoading = false

        const params22 = Object.assign({}, params)
        params22.currentPage = 1
        params22.pageSize = 99999
        const ret22 = await request.post('/report/liquidity/getFundsMonitor', params22)
        if (ret22.data.status === 0) {
          const amtBalanceArr = ret22.data.result.result.filter(item => item.amtBalance < 0)
          if (amtBalanceArr.length > 0) {
            vm.earlyWarning = true
            vm.earlyMount = amtBalanceArr[0].amtBalance
            vm.earlyTime = (vm.fundsSearch.reportType === 'M' ? vm.getMonth(amtBalanceArr[0].businessDate) : vm.getNowFormatDate(amtBalanceArr[0].businessDate))
          } else {
            vm.earlyWarning = false
          }
        }
      }
    },
    changeWD(val) {
      this.fundSearchSubmit(1)
    },
    changeTime1() {
      const startTime = this.getNowFormatDate(this.fundsSearch.startTime)
      this.fundsSearch.startTime = startTime
    },
    changeTime2() {
      const endTime = this.getNowFormatDate(this.fundsSearch.endTime)
      this.fundsSearch.endTime = endTime
    },

    // 新成交量设置
    newCSet(val) {
      if (val === 5) {
        this.set1 = true
        this.fundsSearch.t1 = ''
      } else {
        this.set1 = false
        const t1 = this.latelyTradAvg.filter(item => item.typeId === val)
        this.fundsSearch.t1 = val + ':' + t1[0].tradAvg
      }
    },
    setClick1() {
      this.configureType = '新成交量'
      this.newTradingShow = true
    },
    closeNewTrading() {
      const vm = this
      vm.newTradingShow = false

      // vm.tradingTableData = []
    },
    addRecords() {
      const vm = this
      const obj = { startDate: '', endDate: '', money: '' }
      if (vm.configureType === '新成交量') {
        vm.tradingTableData.push(obj)
      } else {
        vm.loanTableData.push(obj)
      }
    },
    deleteT(data) {
      if (this.configureType === '新成交量') {
        this.tradingTableData.splice(data.$index, 1)
      } else {
        this.loanTableData.splice(data.$index, 1)
      }
    },
    async tradingSubmit() {
      const vm = this
      let tableData = []
      if (vm.configureType === '新成交量') {
        tableData = Object.assign([], vm.tradingTableData)
      } else {
        tableData = Object.assign([], vm.loanTableData)
      }
      const startDateArr = tableData.map(function(item) {
        const time = vm.getNowFormatDate(item.startDate)
        return time
      })
      const endDateArr = tableData.map(function(item) {
        const time = vm.getNowFormatDate(item.endDate)
        return time
      })
      const moneyArr = tableData.map(item => item.money)
      if (tableData.length === 0) {
        vm.$message({
          showClose: true,
          message: '请添加至少一条记录！',
          type: 'warning'
        })
      } else if (startDateArr.indexOf('') > -1 || endDateArr.indexOf('') > -1) {
        vm.$message({
          showClose: true,
          message: '日期不能为空！',
          type: 'warning'
        })
      } else if (moneyArr.indexOf('') > -1) {
        vm.$message({
          showClose: true,
          message: '金额不能为空！',
          type: 'warning'
        })
      } else {
        const submitArr = []
        for (let i = 0; i < startDateArr.length; i++) {
          submitArr.push(startDateArr[i] + '|' + endDateArr[i] + '$' + moneyArr[i])
        }
        const newConfigure = submitArr.join(',')
        if (vm.configureType === '新成交量') {
          vm.newConfigure1 = newConfigure
        } else {
          vm.newConfigure2 = newConfigure
        }
        const res = await request.post('/report/liquidity/getCustomizeFailValue',
          { newConfigure: newConfigure, maxQueryTime: vm.fundsSearch.endTime, configureType: vm.configureType })
        if (res.data.status === 0) {
          if (!res.data.result || res.data.result.length === 0) {
            vm.$message({
              showClose: true,
              message: '设置成功！',
              type: 'success'
            })
            if (vm.configureType === '新成交量') {
              vm.fundsSearch.t1 = newConfigure
            } else {
              vm.fundsSearch.t2 = newConfigure
            }
            vm.newTradingShow = false
          } else {
            vm.centerDialogVisible = true
            vm.timesArr = res.data.result
          }
        }
      }
    },

    // 点击提示弹出框的确定
    tipsConfirm() {
      if (this.configureType === '新成交量') {
        this.fundsSearch.newTurnover = 5
        this.fundsSearch.t1 = this.newConfigure1
        // this.fundsSearch.newTurnover = this.newConfigure1
      }
      if (this.configureType === '新放款量') {
        this.fundsSearch.newLending = 5
        this.fundsSearch.t2 = this.newConfigure2
        // this.fundsSearch.newLending = this.newConfigure2
      }
      this.centerDialogVisible = false
      this.newTradingShow = false
    },

    // 提示弹出框-取消
    tipsCancel() {
      this.centerDialogVisible = false
    },

    // 新放款量设置
    newLoanSet(val) {
      if (val === 5) {
        this.set2 = true
        this.fundsSearch.t2 = ''
      } else {
        this.set2 = false
        const t2 = this.latelyLoanAvg.filter(item => item.typeId === val)
        this.fundsSearch.t2 = val + ':' + t2[0].loanAvg
      }
    },
    setClick2() {
      this.configureType = '新放款量'
      this.newTradingShow = true
    },
    async sizeChange(pageSize) {
      const vm = this
      // if (vm.fundsSearch.newTurnover === 5) {
      //   const res1 = await request.post('/report/liquidity/getCustomizeFailValue',
      //     { newConfigure: vm.newConfigure1, maxQueryTime: vm.fundsSearch.endTime, configureType: '新成交量' })
      //   if (res1.data.status === 0) {
      //     if (!res1.data.result || res1.data.result.length === 0) {
      //       vm.fundsSearch.t1 = vm.newConfigure1
      //       vm.newTradingShow = false
      //     } else {
      //       vm.centerDialogVisible = true
      //       vm.timesArr = res1.data.result
      //     }
      //   }
      // }
      // if (vm.fundsSearch.newLending === 5) {
      //   const res2 = await request.post('/report/liquidity/getCustomizeFailValue',
      //     { newConfigure: vm.newConfigure2, maxQueryTime: vm.fundsSearch.endTime, configureType: '新放款量' })
      //   if (res2.data.status === 0) {
      //     if (!res2.data.result || res2.data.result.length === 0) {
      //       vm.fundsSearch.t2 = vm.newConfigure2
      //       vm.newTradingShow = false
      //     } else {
      //       vm.centerDialogVisible = true
      //       vm.timesArr = res2.data.result
      //     }
      //   }
      // }

      if (!vm.fundsSearch.t1) {
        vm.$message({
          showClose: true,
          message: '新成交量设置-自定义每日额度，未设置成功！',
          type: 'warning'
        })
      } else if (!vm.fundsSearch.t2) {
        vm.$message({
          showClose: true,
          message: '新放款量设置-自定义每日额度，未设置成功！',
          type: 'warning'
        })
      } else {
        vm.contentLoading = true
        vm.fundsInfo.currentPage = 1
        vm.fundsInfo.pageSize = pageSize
        const params = {
          currentPage: 1,
          pageSize: pageSize,
          startTime: vm.fundsSearch.startTime,
          endTime: vm.fundsSearch.endTime,
          reportType: vm.fundsSearch.reportType,
          newTurnover: vm.fundsSearch.t1,
          newLending: vm.fundsSearch.t2,
          repayment: vm.fundsSearch.repayment
        }
        const ret = await request.post('/report/liquidity/getFundsMonitor', params)
        if (ret.data.status === 0) { // 执行成功
          vm.fundsInfo.records = ret.data.result.result
          vm.fundsInfo.total = ret.data.result.totalCount
          vm.fundsInfo.currentPage = ret.data.result.currentPage
        }
        vm.contentLoading = false

        const params22 = Object.assign({}, params)
        params22.currentPage = 1
        params22.pageSize = 99999
        const ret22 = await request.post('/report/liquidity/getFundsMonitor', params22)
        if (ret22.data.status === 0) {
          const amtBalanceArr = ret22.data.result.result.filter(item => item.amtBalance < 0)
          if (amtBalanceArr.length > 0) {
            vm.earlyWarning = true
            vm.earlyMount = amtBalanceArr[0].amtBalance
            vm.earlyTime = (vm.fundsSearch.reportType === 'M' ? vm.getMonth(amtBalanceArr[0].businessDate) : vm.getNowFormatDate(amtBalanceArr[0].businessDate))
          } else {
            vm.earlyWarning = false
          }
        }
      }
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.amtBalance < 0) {
        return 'warning-row'
      }
      return ''
    },
    formatNumber(s, n) {
      return (s + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
    },
    formatComma(row, column, cellValue, index) {
      const vm = this
      return vm.formatNumber(cellValue)
    }
  }
}
</script>
<style lang="scss" scoped>
.el-main{
  padding:0;
}
/deep/ .funds .el-form-item__label{
  width:110px;
}
/deep/ .el-dialog__body{
  padding-top:10px;
  padding-bottom: 0;
}
/deep/ .el-select--medium{
  width:350px;
}
/deep/ .el-date-editor{
  width:168px;
}
.btnTwo{
  float: right;
}
/deep/ .el-table .cell{
  height:auto;
}
.times{
  overflow: hidden;
  padding-bottom:10px;
}
.times>span{
  float: left;
  width:25%;
  text-align: center;
  height:24px;
}
.funds .el-icon-setting{
  font-size:18px;
  position: relative;
  top:2px;
  cursor: pointer;
}
/deep/ .amtBalance span{
  padding-right:5px;
}
/deep/ .amtBalance i{
  cursor: pointer;
}
.earlyWarning{
  margin-bottom: 15px;
}
.earlyWarning i{
  font-style: normal;
  color:#f11b1b;
}
.earlyWarning>b{
  display: inline-block;
  width:110px;
  font-size:14px;
  color:#606266;
  text-align: right;
  font-weight:700;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
.prediction{
  /deep/ .el-form-item__content{
    width:400px;
    .el-input{
      width:300px;
    }
    .el-icon-question{
      cursor: pointer;
    }
  }
}
input::-webkit-inner-spin-button {
    -webkit-appearance: none !important;
    margin: 0;
}
</style>
