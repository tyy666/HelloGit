<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <el-form v-model="fundsSearch" class="demo-form-inline funds" label-width="110px" label-position="right">
            <el-form-item label="数据维度：">
              <el-radio-group v-model="fundsSearch.dimension" @change="changeDimension">
                <el-radio label="date">按天汇总</el-radio>
                <el-radio label="product">按产品汇总</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="显示方式：">
              <template v-if="fundsSearch.dimension==='date'">
                <el-radio-group v-model="fundsSearch.display1" @change="changeWay">
                  <el-radio label="line">折线图</el-radio>
                  <el-radio label="list">列表</el-radio>
                </el-radio-group>
              </template>
              <template v-else>
                <el-radio-group v-model="fundsSearch.display2">
                  <el-radio label="list">列表</el-radio>
                </el-radio-group>
              </template>

            </el-form-item>
            <el-form-item v-show="fundsSearch.dimension==='date'?true:false" label="查询时间：">
              <template v-if="fundsSearch.display1==='line'">
                <el-date-picker
                  :editable="false"
                  :clearable="false"
                  v-model="fundsSearch.startTime"
                  type="date"
                  placeholder="开始日期"
                  @change="changeTimeA"/>
                -
                <el-date-picker
                  :editable="false"
                  :clearable="false"
                  v-model="fundsSearch.endTime"
                  type="date"
                  placeholder="结束日期"
                  @change="changeTimeB"/>
                <el-button type="primary" style="margin-left:40px" @click="fundSearchSubmit">查询</el-button>
                <el-button type="success" style="margin-left:10px" @click="exportMatchByDayLine()">导出</el-button>
              </template>
              <template v-else>
                <el-date-picker
                  :editable="false"
                  :clearable="false"
                  v-model="day_list_Info.startTime"
                  type="date"
                  placeholder="开始日期"
                  @change="changeTimeC"/>
                -
                <el-date-picker
                  :editable="false"
                  :clearable="false"
                  v-model="day_list_Info.endTime"
                  type="date"
                  placeholder="结束日期"
                  @change="changeTimeD"/>
                <el-button type="primary" style="margin-left:40px" @click="day_list_submit(1)">查询</el-button>
                <el-button type="success" style="margin-left:10px" @click="exportMatchByDayTable()">导出</el-button>
              </template>
            </el-form-item>
          </el-form>
          <el-form v-show="fundsSearch.dimension==='date'?false:true" :inline="true" v-model="listSearch" class="demo-form-inline list">
            <el-row>
              <el-col :span="11">
                <el-form-item label="预警阈值设置：">
                  <el-input v-enter-number2 v-model.trim="listSearch.threshold" @keyup.native="storeCookie" />
                </el-form-item>
                <el-tooltip class="item" effect="dark" content="设置【期限不匹配额度占比】预警阈值，超过设置阈值，则该条记录标记为红色" placement="top">
                  <i class="el-icon-info"/>
                </el-tooltip>
              </el-col>
              <el-col :span="13">
                <el-form-item label="产品名称：">
                  <el-input v-model.trim="listSearch.productName" clearable />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="11">
                <el-form-item label="锁定到期日：">
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="listSearch.lockStart"
                    type="date"
                    placeholder="开始日期"
                    @change="changeTime1"/>
                  -
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="listSearch.lockEnd"
                    type="date"
                    placeholder="结束日期"
                    @change="changeTime2"/>
                </el-form-item>
              </el-col>
              <el-col :span="13">
                <el-form-item label="更新时间：">
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="listSearch.statisticStart"
                    type="date"
                    placeholder="开始日期"
                    @change="changeTime3"/>
                  -
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="listSearch.statisticEnd"
                    type="date"
                    placeholder="结束日期"
                    @change="changeTime4"/>
                </el-form-item>
                <el-button type="primary" @click="listSearchSubmit(1)">查询</el-button>
                <el-button type="success" @click="exportMatchByProduct()">导出</el-button>
              </el-col>
            </el-row>
          </el-form>

          <!-- 按天汇总-列表 -->
          <div
            v-loading="contentLoading3"
            v-show="fundsSearch.dimension==='date'&&fundsSearch.display1==='list'">
            <el-table
              ref="multipleTable"
              :data="day_list_Info.records"
              highlight-current-row
              border
              style="width: 100%;margin-bottom: 20px">
              <el-table-column
                prop="productCompleteDate"
                show-overflow-tooltip
                label="日期"
                align="center">
                <template slot-scope="scope">
                  <span>{{ getNowFormatDate(scope.row.productCompleteDate) }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="shouldIncomeAmt"
                show-overflow-tooltip
                label="产品到期日待兑付本息和（万）"
                align="right"
                header-align="center">
                <template slot-scope="scope">
                  <span>{{ scope.row.shouldIncomeAmt?(scope.row.shouldIncomeAmt/10000).toFixed(2):0 }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="lockUnmatchAmt"
                show-overflow-tooltip
                label="产品到期日债转待还本息和（万）"
                align="right"
                header-align="center">
                <template slot-scope="scope">
                  <span>{{ scope.row.lockUnmatchAmt?(scope.row.lockUnmatchAmt/10000).toFixed(2):0 }}</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                label="期限不匹配额度占比（%）"
                align="right"
                header-align="center">
                <template slot-scope="scope">
                  <span>
                    {{
                      scope.row.lockUnmatchAmt&&scope.row.shouldIncomeAmt ?
                        Number((scope.row.lockUnmatchAmt / scope.row.shouldIncomeAmt)*100).toFixed(2) :
                        '0'
                    }}
                  </span>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              v-if="day_list_Info.records&&day_list_Info.records.length"
              :total="day_list_Info.total"
              :current-page.sync="day_list_Info.currentPage"
              :page-size.sync="day_list_Info.pageSize"
              :page-sizes="[5,10,15,20]"
              background
              layout="jumper,prev, pager, next,total,sizes"
              style="text-align: center"
              @size-change="day_list_sizeChange"
              @current-change="day_list_submit"/>
          </div>

          <!-- 按天汇总-折线图 -->
          <div
            v-loading="contentLoading"
            v-show="fundsSearch.dimension==='date'&&fundsSearch.display1==='line'"
            :class="className"
            :id="id"
            :style="{height:height,width:width}"/>

          <!-- 按产品汇总-列表 -->
          <div v-loading="contentLoading2" v-show="fundsSearch.dimension==='product'&&fundsSearch.display2==='list'">
            <el-table
              ref="multipleTable"
              :data="listInfo.records"
              :row-class-name="tableRowClassName"
              highlight-current-row
              border
              style="width: 100%;margin-bottom: 20px">
              <el-table-column
                prop="statisticsDate"
                width="100px"
                label="更新时间"
                align="center">
                <template slot-scope="scope">
                  <span>{{ getNowFormatDate(scope.row.statisticsDate) }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="productTypeName"
                width="80px"
                label="产品类型"
                align="center"/>
              <el-table-column
                prop="productName"
                show-overflow-tooltip
                label="产品名称"
                align="center"/>
              <el-table-column
                prop="productCompleteDate"
                width="120px"
                label="锁定到期日"
                align="center">
                <template slot-scope="scope">
                  <span>{{ getNowFormatDate(scope.row.productCompleteDate) }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="remainLockDay"
                show-overflow-tooltip
                label="剩余锁定期(天)"
                width="150px"
                align="center"/>
              <el-table-column
                :formatter="formatComma"
                prop="shouldIncomeAmt"
                show-overflow-tooltip
                label="产品到期日待兑付本息（元）"
                align="right"
                header-align="center"/>
              <el-table-column
                :formatter="formatComma"
                prop="lockUnmatchAmt"
                show-overflow-tooltip
                label="期限不匹配额度(到期日债转待还本息和)（元）"
                width="320px"
                align="right"
                header-align="center"/>
              <el-table-column
                show-overflow-tooltip
                prop="lockUnmatchAmtRatio"
                label="期限不匹配额度占比"
                align="center"/>
            </el-table>
            <el-pagination
              v-if="listInfo.records&&listInfo.records.length"
              :total="listInfo.total"
              :current-page.sync="listInfo.currentPage"
              :page-size.sync="listInfo.pageSize"
              :page-sizes="[5,10,15,20]"
              background
              layout="jumper,prev, pager, next,total,sizes"
              style="text-align: center"
              @size-change="sizeChange"
              @current-change="listSearchSubmit"/>
          </div>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import request from '@/utils/request'
import echarts from 'echarts'
import resize from '../../components/Charts/mixins/resize'
import fileDownload from 'js-file-download'
import { getToken } from '@/utils/auth'
import axios from 'axios'
export default{
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '500px'
    }
  },
  data() {
    return {
      chart: null,
      contentLoading: false,
      contentLoading2: false,
      activeName: 'first',
      fundsSearch: {
        startTime: '',
        endTime: '',

        dimension: 'date',
        display1: 'line',
        display2: 'list'
      },
      chartData: {
        days: [],
        series1: [],
        series2: []
      },
      // 列表查询条件
      listSearch: {
        threshold: localStorage.getItem('threshold') ? localStorage.getItem('threshold') : 0.6,
        productName: '',
        lockStart: '',
        lockEnd: '',
        statisticStart: '',
        statisticEnd: ''
      },
      listInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },

      // 按天汇总-列表
      contentLoading3: false,
      day_list_Info: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10,
        startTime: '',
        endTime: ''
      },
      day_list_clickTimes: 0,

      // 按产品汇总-列表
      product_list_clickTimes: 0
    }
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  async created() {
    const vm = this
    const startDay = vm.getNowFormatDate(new Date())
    const startOne = startDay + ' ' + '00:00:00'
    const e1 = new Date(startOne).getTime() + 3600 * 1000 * 24 * 30
    const endDay = vm.getNowFormatDate(e1)
    vm.fundsSearch.startTime = startDay
    vm.fundsSearch.endTime = endDay

    vm.day_list_Info.startTime = startDay
    vm.day_list_Info.endTime = endDay

    vm.contentLoading = true
    const res = await request.post(
      '/report/liquidity/getMatchMonitorChart',
      { startTime: vm.fundsSearch.startTime, endTime: vm.fundsSearch.endTime }
    )
    vm.chart = echarts.init(document.getElementById(this.id))
    vm.chart.setOption({
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#ccc'
          }
        }
      },
      legend: {
        top: 20,
        icon: 'rect',
        itemWidth: 14,
        itemHeight: 5,
        itemGap: 13,
        data: ['产品计划到期待兑付本息', '计划到期退出债转待还本息和'],
        right: '4%',
        textStyle: {
          fontSize: 12,
          color: '#333'
        }
      },
      grid: {
        top: 100,
        left: '2%',
        right: '6%',
        bottom: '2%',
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        name: '时间(天)',
        boundaryGap: false,
        axisLine: {
          lineStyle: {
            color: '#666666'
          }
        },
        data: []
      }],
      yAxis: [{
        type: 'value',
        name: '额度(万)',
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: '#666666'
          }
        },
        axisLabel: {
          margin: 10,
          textStyle: {
            fontSize: 14
          }
        },
        splitLine: {
          lineStyle: {
            color: '#ccc'
          }
        }
      }],
      series: [
        {
          name: '产品计划到期待兑付本息',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 1
            }
          },
          areaStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(137, 189, 27, 0.3)'
              }, {
                offset: 0.8,
                color: 'rgba(137, 189, 27, 0)'
              }], false),
              shadowColor: 'rgba(0, 0, 0, 0.1)',
              shadowBlur: 10
            }
          },
          itemStyle: {
            normal: {
              color: 'rgb(137,189,27)',
              borderColor: 'rgba(137,189,2,0.27)',
              borderWidth: 12

            }
          },
          data: []
        },
        {
          name: '计划到期退出债转待还本息和',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 1
            }
          },
          areaStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(0, 136, 212, 0.3)'
              }, {
                offset: 0.8,
                color: 'rgba(0, 136, 212, 0)'
              }], false),
              shadowColor: 'rgba(0, 0, 0, 0.1)',
              shadowBlur: 10
            }
          },
          itemStyle: {
            normal: {
              color: 'rgb(0,136,212)',
              borderColor: 'rgba(0,136,212,0.2)',
              borderWidth: 12

            }
          },
          data: []
        }
      ]
    })

    if (res.data.status === 0 && res.data.result) {
      vm.chartData.days = res.data.result.days
      vm.chartData.series1 = res.data.result.series1
      vm.chartData.series2 = res.data.result.series2
      vm.chart.setOption({
        xAxis: [{
          data: res.data.result.days
        }],
        series: [
          { data: res.data.result.series1 },
          { data: res.data.result.series2 }
        ]
      })
    } else {
      vm.chartData.days = []
      vm.chartData.series1 = []
      vm.chartData.series2 = []
      vm.chart.setOption({
        xAxis: [{
          data: []
        }],
        series: [
          { data: [] },
          { data: [] }
        ]
      })
    }
    vm.contentLoading = false

    // 锁定到期日、更新时间
    vm.listSearch.lockStart = startDay
    vm.listSearch.lockEnd = startDay
    const e2 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 1
    const endDay2 = vm.getNowFormatDate(e2)
    vm.listSearch.statisticStart = endDay2
    vm.listSearch.statisticEnd = endDay2
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    async handleClick(tab, event) {
      const vm = this
      if (tab.name === 'second' && vm.listInfo.records.length === 0) {
        vm.contentLoading2 = true
        const res = await request.post('/report/liquidity/getMatchMonitorList',
          {
            currentPage: 1,
            pageSize: 10,
            productName: vm.listSearch.productName,
            lockStart: vm.listSearch.lockStart,
            lockEnd: vm.listSearch.lockEnd,
            statisticStart: vm.listSearch.statisticStart,
            statisticEnd: vm.listSearch.statisticEnd
          })
        if (res.data.status === 0) {
          vm.listInfo.records = res.data.result.result
          vm.listInfo.total = res.data.result.totalCount
          vm.listInfo.currentPage = res.data.result.currentPage
        }
        vm.contentLoading2 = false
      }
    },
    changeTimeA() {
      const startTime = this.getNowFormatDate(this.fundsSearch.startTime)
      this.fundsSearch.startTime = startTime
    },
    changeTimeB() {
      const endTime = this.getNowFormatDate(this.fundsSearch.endTime)
      this.fundsSearch.endTime = endTime
    },
    changeTimeC() {
      const startTime = this.getNowFormatDate(this.day_list_Info.startTime)
      this.day_list_Info.startTime = startTime
    },
    changeTimeD() {
      const endTime = this.getNowFormatDate(this.day_list_Info.endTime)
      this.day_list_Info.endTime = endTime
    },
    async fundSearchSubmit() {
      const vm = this
      vm.contentLoading = true
      const res = await request.post('/report/liquidity/getMatchMonitorChart',
        { startTime: vm.fundsSearch.startTime, endTime: vm.fundsSearch.endTime })
      if (res.data.status === 0 && res.data.result) {
        vm.chartData.days = res.data.result.days
        vm.chartData.series1 = res.data.result.series1
        vm.chartData.series2 = res.data.result.series2
        vm.chart.setOption({
          xAxis: [{
            data: res.data.result.days
          }],
          series: [
            { data: res.data.result.series1 },
            { data: res.data.result.series2 }
          ]
        })
      } else {
        vm.chart.setOption({
          xAxis: [{
            data: []
          }],
          series: [
            { data: [] },
            { data: [] }
          ]
        })
      }
      vm.contentLoading = false
    },
    changeTime1() {
      const startTime = this.getNowFormatDate(this.listSearch.lockStart)
      this.listSearch.lockStart = startTime
    },
    changeTime2() {
      const endTime = this.getNowFormatDate(this.listSearch.lockEnd)
      this.listSearch.lockEnd = endTime
    },
    changeTime3() {
      const startTime = this.getNowFormatDate(this.listSearch.statisticStart)
      this.listSearch.statisticStart = startTime
    },
    changeTime4() {
      const endTime = this.getNowFormatDate(this.listSearch.statisticEnd)
      this.listSearch.statisticEnd = endTime
    },
    async listSearchSubmit(page) {
      const vm = this
      vm.listInfo.currentPage = page
      vm.contentLoading2 = true
      const params = {
        currentPage: page,
        pageSize: vm.listInfo.pageSize,
        productName: vm.listSearch.productName,
        lockStart: vm.listSearch.lockStart,
        lockEnd: vm.listSearch.lockEnd,
        statisticStart: vm.listSearch.statisticStart,
        statisticEnd: vm.listSearch.statisticEnd
      }
      const ret = await request.post('/report/liquidity/getMatchMonitorList', params)
      if (ret.data.status === 0) { // 执行成功
        vm.listInfo.records = ret.data.result.result
        vm.listInfo.total = ret.data.result.totalCount
        vm.listInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading2 = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.listInfo.currentPage = 1
      vm.listInfo.pageSize = pageSize
      vm.contentLoading2 = true
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        productName: vm.listSearch.productName,
        lockStart: vm.listSearch.lockStart,
        lockEnd: vm.listSearch.lockEnd,
        statisticStart: vm.listSearch.statisticStart,
        statisticEnd: vm.listSearch.statisticEnd
      }
      const ret = await request.post('/report/liquidity/getMatchMonitorList', params)
      if (ret.data.status === 0) { // 执行成功
        vm.listInfo.records = ret.data.result.result
        vm.listInfo.total = ret.data.result.totalCount
        vm.listInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading2 = false
    },
    tableRowClassName({ row, rowIndex }) {
      if (this.listSearch.threshold !== '' && row.lockUnmatchAmtRatio > this.listSearch.threshold) {
        return 'warning-row'
      }
      return ''
    },
    storeCookie(event) {
      localStorage.setItem('threshold', event.target.value)
    },
    formatNumber(s, n) {
      return (s + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
    },
    formatComma(row, column, cellValue, index) {
      const vm = this
      return vm.formatNumber(cellValue)
    },

    // 第2期改版新需求

    // 改变：数据维度
    changeDimension(val) {
      if (val === 'product') {
        if (this.product_list_clickTimes === 0) {
          this.listSearchSubmit(1)
        }
        this.product_list_clickTimes++
      }
    },

    // 改变：显示方式
    changeWay(val) {
      const vm = this
      if (val === 'list' && vm.day_list_clickTimes === 0) {
        vm.day_list_clickTimes++
        vm.day_list_submit(1)
        console.log(99)
      }
    },

    // 按天汇总-列表
    async day_list_submit(page) {
      const vm = this
      vm.contentLoading3 = true
      vm.day_list_Info.currentPage = page
      const params = {
        currentPage: page,
        pageSize: vm.day_list_Info.pageSize,
        startTime: vm.day_list_Info.startTime,
        endTime: vm.day_list_Info.endTime
      }
      const ret = await request.post('/report/liquidity/getMatchMonitorPage', params)
      if (ret.data.status === 0) { // 执行成功
        vm.day_list_Info.records = ret.data.result.result
        vm.day_list_Info.total = ret.data.result.totalCount
        vm.day_list_Info.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading3 = false
    },
    async day_list_sizeChange(pageSize) {
      const vm = this
      vm.contentLoading3 = true
      vm.day_list_Info.currentPage = 1
      vm.day_list_Info.pageSize = pageSize
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        startTime: vm.day_list_Info.startTime,
        endTime: vm.day_list_Info.endTime
      }
      const ret = await request.post('/report/liquidity/getMatchMonitorPage', params)
      if (ret.data.status === 0) { // 执行成功
        vm.day_list_Info.records = ret.data.result.result
        vm.day_list_Info.total = ret.data.result.totalCount
        vm.day_list_Info.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading3 = false
    },
    exportMatchByDayLine() {
      const vm = this
      vm.exportMatchByDay(1)
    },
    exportMatchByDayTable() {
      const vm = this
      vm.exportMatchByDay(2)
    },
    exportMatchByDay(type) {
      const vm = this
      const param = new URLSearchParams()
      const url = process.env.BASE_API + '/report/liquidity/exportMatchByDay'
      if (type === 1) {
        // 折线导出
        param.append('startTime', vm.fundsSearch.startTime)
        param.append('endTime', vm.fundsSearch.endTime)
      } else if (type === 2) {
        param.append('startTime', vm.day_list_Info.startTime)
        param.append('endTime', vm.day_list_Info.endTime)
        // 表格导出
      }
      axios({
        method: 'post',
        url: url,
        data: param,
        headers: {
          'adoptToken': getToken()
        },
        responseType: 'blob'
      }).then((res) => {
        if (type === 1) {
          // 折线导出
          fileDownload(res.data, vm.fundsSearch.startTime + '-' + vm.fundsSearch.endTime + '期限匹配度监测按天.xlsx')
        } else if (type === 2) {
          // 表格导出
          fileDownload(res.data, vm.day_list_Info.startTime + '-' + vm.day_list_Info.endTime + '期限匹配度监测按天.xlsx')
        }
      }).catch(function(error) {
        console.log(error)
      })
    },
    exportMatchByProduct() {
      const vm = this
      const param = new URLSearchParams()
      const url = process.env.BASE_API + '/report/liquidity/exportMatchByProduct'
      param.append('productName', vm.listSearch.productName)
      param.append('lockStart', vm.listSearch.lockStart)
      param.append('lockEnd', vm.listSearch.lockEnd)
      param.append('statisticStart', vm.listSearch.statisticStart)
      param.append('statisticEnd', vm.listSearch.statisticEnd)
      axios({
        method: 'post',
        url: url,
        data: param,
        headers: {
          'adoptToken': getToken()
        },
        responseType: 'blob'
      }).then((res) => {
        fileDownload(res.data, vm.listSearch.statisticStart + '-' + vm.listSearch.statisticEnd + '期限匹配度监测按产品.xlsx')
      }).catch(function(error) {
        console.log(error)
      })
    }

  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.chart-container{
  position: relative;
  padding:20px;
  width: 100%;
  height:85vh;
}
.list .el-icon-info{
  position: relative;
  color:#999;
  top:8px;
  cursor: pointer;
}
/deep/ .list .el-form-item__label{
  width:110px;
}
/deep/ .list .el-input--medium{
  width:304px;
}
/deep/ .list .el-date-editor{
  width:145px;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
</style>
