<template>
  <div class="dashboard-editor-container">
    <el-row :gutter="40" class="panel-group">
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-people">
            <svg-icon icon-class="peoples" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">
              用户数
            </div >
            <div class="card-panel-text">
              {{ userNum }}
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-message">
            <svg-icon icon-class="monitor" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description" style="margin-left:20px">
            <div class="card-panel-text">
              服务节点数
            </div>
            <div class="card-panel-text">
              {{ allConfInfoBeats.length }}
            </div>
          </div>
          <div class="card-panel-description-server">
            <div class="card-panel-text-live">
              LIVE:{{ allLiveConfInfoBeats }}
            </div>
            <div class="card-panel-text-dead">
              DEAD:{{ allDeadConfInfoBeats }}
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-money">
            <svg-icon icon-class="table" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">
              任务数
            </div>
            <div class="card-panel-text">
              100
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-money">
            <svg-icon icon-class="server-configure" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">
              配置
            </div>
            <div class="card-panel-text">
              100
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <!--日志折线图-->
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <div style="width:160px">
      <el-switch
        v-model="operateTimeDayLevel"
        style="display: block"
        active-color="#13ce66"
        inactive-color="#409EFF"
        active-text="天粒度"
        inactive-text="小时粒度"
        @change="changeOperateTimeLevel(operateTimeDayLevel)"/>
      </div>
      <br>
      <line-chart :chart-data="operateLineChartData"/>
    </el-row>

    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
        <div style="width:160px">
          <el-switch
            v-model="loginTimeDayLevel"
            style="display: block"
            active-color="#13ce66"
            inactive-color="#409EFF"
            active-text="天粒度"
            inactive-text="小时粒度"
            @change="changeLoginTimeLevel(loginTimeDayLevel)"/>
        </div>
      <br>
      <line-chart :chart-data="loginLineChartData"/>
    </el-row>
    
    <!--服务信息-->
    <el-card class="box-card" style="min-height:230px">
      <el-table :key="key" :data="confInfoBeat.records" border fit highlight-current-row style="width: 100%;height:100%">
        <el-table-column v-for="fruit in formThead" :show-overflow-tooltip="true" :key="fruit.en" :prop="fruit.en" :label="fruit.cn" :width="(fruit.en==='serverIp' || fruit.en==='os' || fruit.en==='network') ? '343' : ((fruit.en==='serverStatus')?'100':'200')">
          <template slot-scope="scope">
            <span v-if="fruit.en==='serverStatus'">
              {{ getServerStatus(scope.row) }}
            </span>
            <span v-else-if="fruit.en==='memory'">
              <span :title="getMemoryProgressTitle(scope.row[fruit.en])">
                <el-progress :text-inside="true" :stroke-width="20" :percentage="getMemoryProgress(scope.row[fruit.en])"/>
              </span>
            </span>
            <span v-else-if="fruit.en==='cpu'">
              <span>
                <el-progress :text-inside="true" :stroke-width="20" :percentage="Math.ceil(100*(scope.row[fruit.en]))"/>
              </span>
            </span>
            <span v-else-if="fruit.en==='disk'">
              <span :title="getDiskProgressTitle(scope.row[fruit.en])">
                <el-progress :text-inside="true" :stroke-width="20" :percentage="getDiskProgress(scope.row[fruit.en])"/>
              </span>
            </span>
            <span v-else>
              {{ scope.row[fruit.en] }}
            </span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="confInfoBeat.records&&confInfoBeat.records.length"
        :total="confInfoBeat.total"
        :current-page.sync="confInfoBeat.currentPage"
        :page-size.sync="confInfoBeat.pageSize"
        :page-sizes="[5,10,15,20]"
        background
        layout="jumper,prev, pager, next,total,sizes"
        style="text-align: center"
        @size-change="sizeChange"
        @current-change="getConfInfoBeatPage"/>
    </el-card>
  </div>
</template>

<script>
import LineChart from './LineChart'
import request from '@/utils/request'
const defaultFormThead = [
  { en: 'serverIp', cn: '服务端地址' },
  { en: 'serverStatus', cn: '服务器状态' },
  { en: 'host', cn: 'host名称' },
  { en: 'os', cn: '操作系统' },
  { en: 'cpu', cn: 'CPU' },
  { en: 'memory', cn: '内存' },
  { en: 'disk', cn: '磁盘' }
]
export default {
  name: 'DashboardAdmin',
  components: {
    LineChart
  },
  data() {
    return {
      confInfoBeat: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      key: 1, // table key
      formThead: defaultFormThead,
      userNum: 0, // 用户数
      allConfInfoBeats: 0, // 所有的集群服务数
      allLiveConfInfoBeats: 0, // 所有存活的集群服务数
      allDeadConfInfoBeats: 0, // 所有死亡的集群服务数
      loginLineChartData: {
        title: {
          text: '登录日志'
        },
        xAxis: {
          data: [],
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: [],
        legend: '',
        series: []
      }, // 登录折线图
      operateLineChartData: {
        title: {
          text: '操作日志'
        },
        xAxis: {
          data: [],
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        yAxis: [],
        legend: '',
        series: []
      }, // 操作折线图
      operateTimeDayLevel: false, // 操作天粒度标识
      loginTimeDayLevel: false // 登录天粒度标识
    }
  },
  created() {
    const vm = this
    vm.getUserNum()
    vm.getAllConfInfoBeat()
    vm.getConfInfoBeatPage(1)
    vm.getLineChartData('/monitor/getLoginReportWithHour', { reportDay: new Date() }, 'login')
    vm.getLineChartData('/monitor/getOperateReportWithHour', { reportDay: new Date() }, 'operate')
  },
  methods: {
    // 查询用户数
    getUserNum() {
      const vm = this
      const userNumParams = {
        currentPage: 1,
        pageSize: 1
      }
      request.post('/privilege/user/selectUsers', userNumParams)
        .then((res) => {
          if (res.data.status === 0) {
            vm.userNum = res.data.result.totalCount
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 查询所有集群服务
    getAllConfInfoBeat() {
      const vm = this
      request.post('/configure/confInfoBeat/getAllConfInfoBeat')
        .then((res) => {
          if (res.data.status === 0) {
            vm.allConfInfoBeats = res.data.result
            if (res.data.result.length > 0) {
              for (let i = 0; i < res.data.result.length; i++) {
                const element = res.data.result[i]
                const statu = vm.getServerStatus(element)
                if (statu === 'LIVE') {
                  vm.allLiveConfInfoBeats += 1
                } else if (statu === 'DEAD') {
                  vm.allDeadConfInfoBeats += 1
                }
              }
            }
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 查询服务详细信息
    getConfInfoBeatPage(currentPage) {
      const vm = this
      const params = {
        currentPage: currentPage,
        pageSize: vm.confInfoBeat.pageSize
      }
      request.post('/configure/confInfoBeat/getConfInfoBeatPage', params)
        .then((res) => {
          if (res.data.status === 0) {
            vm.confInfoBeat.records = res.data.result.result
            vm.confInfoBeat.total = res.data.result.totalCount
            vm.confInfoBeat.currentPage = currentPage
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 切换当前页条数
    sizeChange(pageSize) {
      const vm = this
      vm.confInfoBeat.pageSize = pageSize
      vm.getConfInfoBeatPage(1)
    },
    // 获取服务状态（服务器时钟不同步会导致状态监测异常）
    getServerStatus(row) {
      const nowDate = new Date()
      const beatTime = new Date(row.beatTime)
      const diff = (nowDate.getTime() - beatTime.getTime()) / 1000
      if (diff > 6 * row.beatCycle) {
        return 'DEAD'
      } else {
        return 'LIVE'
      }
    },
    // 格式化内存
    getMemoryProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4))
    },
    // 格式化内存title
    getMemoryProgressTitle(memory) {
      memory = JSON.parse(memory)
      return memory.used + '/' + memory.total + '  ' + Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4)) + '%  used'
    },
    // 格式化磁盘
    getDiskProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used / memory.total)
    },
    // 格式化磁盘title
    getDiskProgressTitle(memory) {
      memory = JSON.parse(memory)
      return Math.round(memory.used / (1024 * 1024 * 1024)) + 'GiB/' + Math.round(memory.total / (1024 * 1024 * 1024)) + 'GiB  ' + Math.round(100 * memory.used / memory.total) + '%  used'
    },
    getLineChartData(url, chartParams, flag) {
      const vm = this
      request.post(url, chartParams)
        .then((res) => {
          if (res.data.status === 0) {
            if (flag === 'login') {
              vm.loginLineChartData = res.data.result
            } else if (flag === 'operate') {
              vm.operateLineChartData = res.data.result
            }
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    changeOperateTimeLevel(newValue) {
      const vm = this
      const nowTime = new Date()
      const monday = new Date(nowTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      if (newValue) {
        vm.getLineChartData('/monitor/getOperateReportWithDay', { startDay: monday, endDay: new Date() }, 'operate')
      } else {
        vm.getLineChartData('/monitor/getOperateReportWithHour', { reportDay: new Date() }, 'operate')
      }
    },
    changeLoginTimeLevel(newValue) {
      const vm = this
      const nowTime = new Date()
      // nowTime.setTime(nowTime.getTime()-24*60*60*1000);
      const monday = new Date(nowTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      if (newValue) {
        vm.getLineChartData('/monitor/getLoginReportWithDay', { startDay: monday, endDay: new Date() }, 'login')
      } else {
        vm.getLineChartData('/monitor/getLoginReportWithHour', { reportDay: new Date() }, 'login')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }
  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}
@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}

.panel-group {
  margin-top: 18px;
  .card-panel-col {
    margin-bottom: 32px;
  }
  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    border-color: rgba(0, 0, 0, .05);
    .icon-people {
      color: #40c9c6;
    }
    .icon-message {
      color: #36a3f7;
    }
    .icon-money {
      color: #f4516c;
    }
    .icon-shopping {
      color: #34bfa3
    }
    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }
    .card-panel-icon {
      float: left;
      font-size: 48px;
    }
    .card-panel-description {
      float: left;
      font-weight: bold;
      margin: 26px;
      margin-left:90px;
      .card-panel-text {
        line-height: 18px;
        color: rgba(0, 0, 0, 0.45);
        font-size: 18px;
        margin-bottom: 12px;
      }
      .card-panel-num {
        font-size: 20px;
      }
    }
    .card-panel-description-server {
      float: left;
      font-weight: bold;
      margin: 26px;
      margin-left: 0px;
      .card-panel-text-live {
        line-height: 18px;
        color: rgba(19, 138, 49, 0.45);
        font-size: 18px;
        margin-bottom: 12px;
      }
      .card-panel-text-dead {
        line-height: 18px;
        color: rgba(248, 10, 10, 0.45);
        font-size: 18px;
        margin-bottom: 12px;
      }
      .card-panel-num {
        font-size: 20px;
      }
    }
  }
}
@media (max-width:550px) {
  .card-panel-description {
    display: none;
  }
  .card-panel-icon-wrapper {
    float: none !important;
    width: 100%;
    height: 100%;
    margin: 0 !important;
    .svg-icon {
      display: block;
      margin: 14px auto !important;
      float: none !important;
    }
  }
}
</style>

