<template>
  <div class="app-container" style="padding: 0;">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <div slot="header" class="clearfix">
            <span>业务发展整体周报</span>
          </div>
          <el-form :inline="true" v-model="weekSearch" class="demo-form-inline funds">
            <el-row>
              <el-col :span="8">
                <el-form-item label="查询日期">
                  <el-date-picker
                    v-model="weekSearch.startTime"
                    :editable="false"
                    :clearable="false"
                    :picker-options="pickerOptions0"
                    type="week"
                    format="yyyy 第 WW 周"
                    placeholder="开始日期"
                  />
                  -
                  <el-date-picker
                    v-model="weekSearch.endTime"
                    :editable="false"
                    :clearable="false"
                    :picker-options="pickerOptions1"
                    type="week"
                    format="yyyy 第 WW 周"
                    placeholder="结束日期"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="8" style="padding-left:110px">
                <el-button type="primary" @click="weekSearchSubmit(1)">查询</el-button>
                <el-button type="primary" @click="downLoadCSV()">导出</el-button>
              </el-col>
            </el-row>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="weekInfo.records"
            border
            style="width: 100%">
            <el-table-column show-overflow-tooltip prop="statisticsWeek" width="120px" label="日期" align="center"/>
            <el-table-column show-overflow-tooltip prop="weekStartDate" width="100px" label="周一日期" align="center"/>
            <el-table-column show-overflow-tooltip prop="weekEndDate" width="100px" label="周日日期" align="center"/>
            <el-table-column label="用户规模" align="center">
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="registerMcnt" width="100px" label="注册人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="applyMcnt" width="100px" label="申请人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="auditingMcnt" width="100px" label="进件人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="approvalPassMcnt" width="110px" label="审批通过人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="waitSignMcnt" width="100px" label="待签人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="signMcnt" width="100px" label="签约人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="signFailMcnt" width="110px" label="签约失败人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="loanMcnt" width="100px" label="放款人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="waitLoanMcnt" width="100px" label="待放款人数" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="withdrawMcnt" width="100px" label="提现人数" align="right" header-align="center"/>
            </el-table-column>
            <el-table-column label="业务量" align="center">
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="applyQty" width="100px" label="申请量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="auditingQty" width="100px" label="进件量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="approvalPassQty" width="100px" label="审批通过量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="waitSignQty" width="100px" label="待签量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="signQty" width="100px" label="签约量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="signFailQty" width="100px" label="签约失败量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="loanQty" width="100px" label="放款量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="waitLoanQty" width="100px" label="待放款量" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="withdrawQty" width="100px" label="提现量" align="right" header-align="center"/>
            </el-table-column>
            <el-table-column label="资金收支" align="center">
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="applyAmt" width="120px" label="申请金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="approvalAmt" width="100px" label="审批金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="signAmt" width="120px" label="签约金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="loanAmt" width="100px" label="放款金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="contractAmt" width="100px" label="合同金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="withdrawAmt" width="100px" label="提现金额" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="waitLoanAmt" width="100px" label="待放款金额" align="right" header-align="center"/>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="weekInfo.records&&weekInfo.records.length"
            :total="weekInfo.total"
            :current-page.sync="weekInfo.currentPage"
            :page-size.sync="weekInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center;margin-top:10px"
            @size-change="sizeChange"
            @current-change="weekSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import request from '@/utils/request'
import fileDownload from 'js-file-download'
import { getToken } from '@/utils/auth'
import axios from 'axios'
export default{
  data() {
    return {
      contentLoading: false,
      weekSearch: {
        startTime: '',
        endTime: ''
      },
      weekInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      pickerOptions0: {
        disabledDate: (time) => {
          if (this.weekSearch.endTime !== '') {
            return time.getTime() > Date.now() || time.getTime() > this.weekSearch.endTime
          } else {
            return time.getTime() > Date.now()
          }
        }
      },
      pickerOptions1: {
        disabledDate: (time) => {
          return time.getTime() < this.weekSearch.startTime || time.getTime() > Date.now()
        }
      }
    }
  },
  beforeCreate() {

  },
  async created() {
    const vm = this
    // 初始化查询时间
    const endWeek = vm.getNowFormatDate(new Date(vm.getFirstDayOfWeek(new Date())).getTime() - 3600 * 1000 * 24 * 7)
    const endOne = endWeek + ' ' + '00:00:00'
    const e1 = new Date(endOne).getTime() - 3600 * 1000 * 24 * 28
    const startWeek = vm.getNowFormatDate(e1)
    vm.weekSearch.startTime = new Date(startWeek)
    vm.weekSearch.endTime = new Date(endWeek)
    // 获取消费分期天数据
    vm.getConsumptionWeek(1)
  },
  methods: {
    getConsumptionWeek(currentPage) {
      const vm = this
      vm.contentLoading = true
      const params = {
        currentPage: currentPage,
        pageSize: vm.weekInfo.pageSize,
        startTime: vm.getNowFormatDate(vm.weekSearch.startTime),
        endTime: vm.getNowFormatDate(vm.weekSearch.endTime)
      }
      const url = '/report/stages/hxdjk/consumptionWeek/getConsumptionWeekPage'
      request.post(url, params)
        .then((res) => {
          if (res.data.status === 0) {
            vm.weekInfo.records = res.data.result.result
            vm.weekInfo.total = res.data.result.totalCount
          }
        })
        .catch((err) => {
          console.log(err)
        })
      vm.contentLoading = false
    },
    // 点击查询按钮
    weekSearchSubmit(currentPage) {
      const vm = this
      vm.getConsumptionWeek(currentPage)
    },
    // 切换页码
    sizeChange(pageSize) {
      const vm = this
      debugger
      vm.weekInfo.pageSize = pageSize
      vm.getConsumptionWeek(1)
    },
    // 获取本周周一
    getFirstDayOfWeek(date) {
      var day = date.getDay() || 7
      return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1 - day)
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    // 导出
    downLoadCSV() {
      const vm = this
      const param = new URLSearchParams()
      param.append('startTime', vm.getNowFormatDate(vm.weekSearch.startTime))
      param.append('endTime', vm.getNowFormatDate(vm.weekSearch.endTime))
      const url = process.env.BASE_API + '/report/stages/hxdjk/consumptionWeek/downLoadConsumptionWeekCSV'
      axios({
        method: 'post',
        url: url,
        data: param,
        headers: {
          'adoptToken': getToken()
        },
        responseType: 'blob'
      }).then((res) => {
        fileDownload(res.data, vm.getNowFormatDate(vm.weekSearch.startTime) + '-' + vm.getNowFormatDate(vm.weekSearch.endTime) + '业务发展整体周报.csv')
      }).catch(function(error) {
        console.log(error)
      })
    },
    formatNumber(s, n) {
      return (s + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
    },
    formatComma(row, column, cellValue, index) {
      const vm = this
      return vm.formatNumber(cellValue)
    }
  }
}
</script>
<style scoped lang="scss">
.el-main{
  padding:0;
}
/deep/ .funds .el-form-item__label{
  width:110px;
}
/deep/ .el-dialog__body{
  padding-top:10px;
  padding-bottom: 0;
}
/deep/ .el-select--medium{
  width:350px;
}
/deep/ .el-date-editor{
  width:168px;
}
.btnTwo{
  float: right;
}
/deep/ .el-table .cell{
  height:auto;
}
.times{
  overflow: hidden;
  padding-bottom:10px;
}
.times>span{
  float: left;
  width:25%;
  text-align: center;
  height:24px;
}
.funds .el-icon-setting{
  font-size:18px;
  position: relative;
  top:2px;
  cursor: pointer;
}
/deep/ .amtBalance span{
  padding-right:5px;
}
/deep/ .amtBalance i{
  cursor: pointer;
}
.earlyWarning{
  margin-bottom: 15px;
}
.earlyWarning i{
  font-style: normal;
  color:#f11b1b;
}
.earlyWarning>b{
  display: inline-block;
  width:110px;
  font-size:14px;
  color:#606266;
  text-align: right;
  font-weight:700;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
</style>
