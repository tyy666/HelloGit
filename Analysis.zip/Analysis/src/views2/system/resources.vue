<template>
  <div class="app-container">
    <el-container>
      <el-aside width="300px">
        <el-card>
          <tree
            ref="dataTree"
            :data="treeData"
            :check-on-click-node="false"
            :expand-on-click-node="false"
            :highlight-current="true"
            node-key="id"
            default-expand-all
            @node-click="onClick">
            <span slot-scope="{ node, data }" class="custom-tree-node">
              <span>{{ node.label }}</span>
              <span>
                <i v-if="node.data.type === 'folder'" class="fa fa-plus" title="新建菜单" @click.stop="() => append(data)" />
                <i v-if="node.data.type === 'folder'&&node.data.id !== -1" class="fa fa-edit" title="编辑" @click.stop="() => edit(data)"/>
                <el-popover
                  v-if="node.data.id !== -1&&(!node.data.children || node.data.children.length === 0)"
                  v-model="node.visible_del"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click.stop="remove(data);node.visible_del = false">确定</el-button>
                    <el-button size="mini" type="primary" @click.stop="node.visible_del = false">取消</el-button>
                  </div>
                  <i slot="reference" class="fa fa-times-circle" title="删除" @click.stop="node.visible_del = !node.visible_del" />
                </el-popover>
              </span>
            </span>
          </tree>
        </el-card>
      </el-aside>
      <el-main v-loading="contentLoading" v-show="showMenu">
        <el-card v-show="folderShow" class="box-card" style="min-height:600px;margin-bottom: 20px">
          <div slot="header" class="clearfix">
            <span>菜单列表</span>
          </div>
          <el-table
            ref="multipleTable"
            :data="menuTableData"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              :show-overflow-tooltip="true"
              prop="id"
              width="70px"
              label="菜单ID"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="menuPid"
              width="80px"
              label="菜单父ID"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="menuName"
              label="菜单名称"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="remark"
              label="备注"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="menuType"
              width="50px"
              label="类型">
              <template slot-scope="scope">
                {{ scope.row.menuType===1?'目录':'菜单' }}
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="menuLevel"
              label="菜单层级"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="sortIndex"
              label="排序索引"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="isShare"
              width="80px"
              label="是否共享">
              <template slot-scope="scope">
                {{ scope.row.isShare===1?'是':'否' }}
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="createUser"
              label="创建人"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="createTime"
              label="创建时间">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="modifyUser"
              label="修改人"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="modifyTime"
              label="修改时间">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.modifyTime) }}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
        <el-card v-show="!folderShow" class="box-card" style="min-height:600px;margin-bottom: 20px">
          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="菜单配置" name="first">
              <el-form ref="menuConfig" :inline="true" :model="menuConfig" :rules="menuRules" class="demo-form-inline menuConfig" label-width="90px">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="菜单名称" prop="menuName">
                      <el-input v-model="menuConfig.menuName" clearable/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="菜单类型" prop="menuType">
                      <el-select v-model="menuConfig.menuType" placeholder="请选择">
                        <el-option :value="1" label="目录" />
                        <el-option :value="2" label="菜单" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="排序索引" prop="sortIndex">
                      <el-input v-enter-number v-model.number="menuConfig.sortIndex" type="text" clearable/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="是否共享" prop="isShare">
                      <el-select v-model="menuConfig.isShare" placeholder="请选择">
                        <el-option :value="1" label="是" />
                        <el-option :value="-1" label="否" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    <el-form-item label="备注" prop="remark" class="remark1">
                      <el-input v-model="menuConfig.remark" type="textarea" style="width: 100%;"/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row class="btnTwo">
                  <el-button type="primary" @click="onSubmit('menuConfig')">保存</el-button>
                  <el-button @click="refresh">刷新缓存</el-button>
                </el-row>
              </el-form>
            </el-tab-pane>
            <el-tab-pane label="URL配置" name="second">
              <el-form :inline="true" v-model="urlSearch" class="demo-form-inline" style="margin-left:20px">
                <el-form-item label="URL地址">
                  <el-input v-model.trim="urlSearch.urlPath" clearable />
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="urlSearchSubmit">查询</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button type="success" @click="addNew">新增</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button type="info" @click="deleteBtn">删除</el-button>
                </el-form-item>
              </el-form>
              <el-table v-loading="tableLoading" :data="urlTableData" border height="600px" style="width:100%" @selection-change="handleSelectionChange">
                <el-table-column type="selection" width="55" />
                <el-table-column prop="id" width="60px" label="id"/>
                <el-table-column prop="urlPath" label="URL地址"/>
                <el-table-column prop="method" width="80px" label="方法类型"/>
                <el-table-column prop="createUser" width="100px" label="创建人"/>
                <el-table-column prop="createTime" width="170px" label="创建时间">
                  <template slot-scope="scope">
                    <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-main>
    </el-container>

    <!-- 新建菜单的弹窗 -->
    <el-dialog :visible.sync="menuShow" :title="(addOrEdit==='add'?'新建':'编辑')+'菜单'" width="900px" class="newMenu" @close="closeNewMenu">
      <el-form ref="newMenu" :inline="true" :model="newMenu" :rules="menuRules" class="demo-form-inline" label-width="130px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="newMenu.menuName" clearable/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="菜单类型" prop="menuType">
              <el-select v-model="newMenu.menuType" placeholder="请选择">
                <el-option :value="1" label="目录" />
                <el-option :value="2" label="菜单" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="排序索引" prop="sortIndex">
              <el-input v-enter-number v-model.number="newMenu.sortIndex" type="text" clearable/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="是否共享" prop="isShare">
              <el-select v-model="newMenu.isShare" placeholder="请选择">
                <el-option :value="1" label="是" />
                <el-option :value="-1" label="否" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="备注" prop="remark" class="remark1">
              <el-input v-model="newMenu.remark" type="textarea" style="width: 100%;"/>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row class="btnTwo">
          <el-button type="primary" @click="onSubmit('newMenu')">保存</el-button>
        </el-row>
      </el-form>
    </el-dialog>

    <!-- URL配置，新增弹窗 -->
    <el-dialog :visible.sync="urlShow" title="URL查询" width="900px" class="newUrlConfig" @close="closeURL">
      <el-form :inline="true" v-model="newUrlSearch" class="demo-form-inline" style="margin-left:20px">
        <el-form-item label="URL地址">
          <el-input v-model.trim="newUrlSearch.urlPath" clearable />
        </el-form-item>
        <el-form-item label="方法类型">
          <el-select v-model="newUrlSearch.method" placeholder="请选择">
            <el-option label="全部" value="" />
            <el-option label="GET" value="GET" />
            <el-option label="POST" value="POST" />
            <el-option label="HEAD" value="HEAD" />
            <el-option label="PUT" value="PUT" />
            <el-option label="PATCH" value="PATCH" />
            <el-option label="DELETE" value="DELETE" />
            <el-option label="OPTIONS" value="OPTIONS" />
            <el-option label="TRACE" value="TRACE" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="newUrlSearchSubmit(1)">查询</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="addNewUrl">保存</el-button>
        </el-form-item>
      </el-form>
      <el-table v-loading="urlTableLoading" :data="urlConfigData.records" border height="495px" style="width:100%" @selection-change="urlSelectChange">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" width="60px" label="id"/>
        <el-table-column prop="urlPath" label="URL地址"/>
        <el-table-column prop="method" width="80px" label="方法类型"/>
        <el-table-column prop="createUser" width="100px" label="创建人"/>
        <el-table-column prop="createTime" width="170px" label="创建时间">
          <template slot-scope="scope">
            <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="urlConfigData.records&&urlConfigData.records.length"
        :total="urlConfigData.total"
        :current-page.sync="urlConfigData.currentPage"
        :page-size.sync="urlConfigData.pageSize"
        :page-sizes="[5,10,15,20]"
        background
        layout="jumper,prev, pager, next,total,sizes"
        style="text-align: center;margin-top:20px"
        @size-change="sizeChange"
        @current-change="newUrlSearchSubmit"/>
    </el-dialog>

    <!-- 是否确定删除弹窗 -->
    <el-dialog
      :visible.sync="centerDialogVisible"
      title="提示"
      width="30%"
      center>
      <span>确定删除吗？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="centerDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="deletes">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import tree from '../../components/tree'
import request from '@/utils/request'
export default{
  name: 'Resources',
  components: { tree },
  data() {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      contentLoading: false,
      tableLoading: false,
      showMenu: false,
      treeData: [{
        label: '菜单资源',
        id: -1,
        pid: 0,
        type: 'folder',
        level: 1,
        children: []
      }],
      menuTableData: [],
      folderShow: false,
      activeName: 'first',

      // 菜单配置
      menuConfig: {
        menuName: '',
        menuType: '',
        sortIndex: '',
        isShare: '',
        remark: '',
        menuId: '',
        menuPid: ''
      },

      // 新建菜单
      newMenu: {
        menuName: '',
        menuType: '',
        sortIndex: '',
        isShare: '',
        remark: '',
        menuPid: '',
        menuId: ''
      },

      menuRules: {
        menuName: [{ required: true, message: '请输入菜单名称', trigger: 'blur' }],
        menuType: [{ required: true, message: '请选择', trigger: 'change' }],
        sortIndex: [{ type: 'number', required: true, message: '排序索引必须是非负整数', trigger: 'blur' }],
        isShare: [{ required: true, message: '请选择', trigger: 'change' }]
      },

      // URL配置
      urlSearch: {
        urlPath: ''
      },
      urlTableData: [],
      multipleSelection: [],

      // 新建菜单的弹窗
      menuShow: false,
      menuPid: '',
      addOrEdit: '',

      // 是否确定删除弹窗
      centerDialogVisible: false,

      // URL配置，新增弹窗
      urlShow: false,
      newUrlSearch: {
        urlPath: '',
        method: ''
      },
      urlConfigData: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      urlTableLoading: false,
      urlSelection: []
    }
  },
  created() {
    const vm = this
    request.post('/privilege/menu/getMenuTree', {})
      .then(function(res) {
        if (res.data.status === 0) {
          vm.treeData[0].children = Object.assign([], res.data.result.children)
        }
      })
      .catch(function(err) {
        console.log(err)
      })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      if (!date) { return '' }
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },

    // 新建菜单
    append(data) {
      this.addOrEdit = 'add'
      this.menuShow = true
      this.menuPid = data.id
    },
    closeNewMenu() {
      this.newMenu.menuName = ''
      this.newMenu.menuType = ''
      this.newMenu.sortIndex = ''
      this.newMenu.isShare = ''
      this.newMenu.remark = ''
      this.menuPid = ''
    },

    // 编辑
    async edit(data) {
      const vm = this
      vm.addOrEdit = 'editTree'
      vm.menuShow = true
      const res = await request.post('/privilege/menu/getMenuItem', { menuId: data.id })
      if (res.data.status === 0) {
        vm.newMenu.menuName = res.data.result.menuName
        vm.newMenu.menuType = res.data.result.menuType
        vm.newMenu.sortIndex = res.data.result.sortIndex
        vm.newMenu.isShare = res.data.result.isShare
        vm.newMenu.remark = res.data.result.remark
        vm.newMenu.menuPid = res.data.result.menuPid
        vm.newMenu.menuId = res.data.result.id
      }
    },
    async remove(data) {
      const vm = this
      const res = await request.post('/privilege/menu/deleteMenu', { menuId: data.id })
      if (res.data.status === 0) {
        vm.$message({
          showClose: true,
          message: '删除成功！',
          type: 'success'
        })
        request.post('/privilege/menu/getMenuTree', {}).then(function(ret) {
          if (ret.data.status === 0) {
            const newTree = [{ label: '菜单资源', id: -1, pid: 0, type: 'folder', level: 1, children: [] }]
            newTree[0].children = ret.data.result.children
            vm.treeData = newTree
          }
        })
      }
    },
    // 点击树节点
    async onClick(data, node, e) {
      const vm = this
      vm.showMenu = true
      vm.contentLoading = true
      vm.addOrEdit = 'edit'
      const params = { menuId: data.id }
      let api
      switch (data.type) {
        case 'menu': {
          vm.folderShow = false
          vm.urlSearch.urlPath = ''
          vm.urlTableData = []
          api = '/privilege/menu/getMenuItem'
          const res = await request.post(api, params)
          if (res.data.status === 0) {
            vm.menuConfig.menuName = res.data.result.menuName
            vm.menuConfig.menuType = res.data.result.menuType
            vm.menuConfig.sortIndex = res.data.result.sortIndex
            vm.menuConfig.isShare = res.data.result.isShare
            vm.menuConfig.remark = res.data.result.remark
            vm.menuConfig.menuId = res.data.result.id
            vm.menuConfig.menuPid = res.data.result.menuPid
          }
          vm.contentLoading = false

          // URL配置
          const urlRes = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: res.data.result.id, url: '' })
          if (urlRes.data.status === 0) {
            vm.urlTableData = Object.assign([], urlRes.data.result)
          } else {
            vm.urlTableData = []
          }
          break
        }
        case 'folder': {
          vm.folderShow = true
          api = '/privilege/menu/getMenuFolder'
          const res = await request.post(api, params)
          if (res.data.status === 0) {
            vm.menuTableData = res.data.result
          }
          vm.contentLoading = false
          break
        }
      }
    },
    handleClick(tab, event) {
      // console.log(tab, event)
    },
    onSubmit(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) { // 必填项全部填完
          let api = ''
          let params = {}
          if (vm.addOrEdit === 'edit') { // 编辑菜单
            api = '/privilege/menu/modifyMenu'
            params = {
              menuName: vm.menuConfig.menuName,
              menuType: vm.menuConfig.menuType,
              sortIndex: vm.menuConfig.sortIndex,
              isShare: vm.menuConfig.isShare,
              remark: vm.menuConfig.remark,
              menuId: vm.menuConfig.menuId,
              menuPid: vm.menuConfig.menuPid
            }
          } else if (vm.addOrEdit === 'editTree') { // 点击树结构上的编辑图标进行编辑
            api = '/privilege/menu/modifyMenu'
            params = {
              menuName: vm.newMenu.menuName,
              menuType: vm.newMenu.menuType,
              sortIndex: vm.newMenu.sortIndex,
              isShare: vm.newMenu.isShare,
              remark: vm.newMenu.remark,
              menuId: vm.newMenu.menuId,
              menuPid: vm.newMenu.menuPid
            }
          } else { // 点击树结构上的新建图标，新建菜单
            api = '/privilege/menu/createMenu'
            params = {
              menuName: vm.newMenu.menuName,
              menuType: vm.newMenu.menuType,
              sortIndex: vm.newMenu.sortIndex,
              isShare: vm.newMenu.isShare,
              remark: vm.newMenu.remark,
              menuPid: vm.menuPid
            }
          }
          request.post(api, params).then(function(res) {
            if (res.data.status === 0) {
              vm.$message({
                showClose: true,
                message: '保存成功！',
                type: 'success'
              })
              request.post('/privilege/menu/getMenuTree', {})
                .then(function(ret) {
                  if (ret.data.status === 0) {
                    const newTree = [{ label: '菜单资源', id: -1, pid: 0, type: 'folder', level: 1, children: [] }]
                    newTree[0].children = ret.data.result.children
                    vm.treeData = newTree
                  }
                })
              vm.menuShow = false
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },

    // URL配置查询
    async urlSearchSubmit() {
      const vm = this
      vm.tableLoading = true
      const urlRes = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: vm.menuConfig.menuId, url: vm.urlSearch.urlPath })
      if (urlRes.data.status === 0) {
        vm.urlTableData = Object.assign([], urlRes.data.result)
      }
      vm.tableLoading = false
    },
    async addNew() {
      const vm = this
      vm.urlShow = true
      vm.urlConfigData.currentPage = 1
      vm.urlConfigData.pageSize = 10
      const res = await request.post('/privilege/menu/getVisitUrlList', { currentPage: 1, pageSize: 10 })
      if (res.data.status === 0) {
        vm.urlConfigData.records = res.data.result.result
        vm.urlConfigData.total = res.data.result.totalCount
      } else {
        vm.urlConfigData.records = []
        vm.urlConfigData.total = 0
      }
    },
    closeURL() {
      this.urlConfigData.currentPage = 1
      this.urlConfigData.pageSize = 10
      this.urlConfigData.records = []
      this.urlConfigData.total = 0
      this.newUrlSearch.urlPath = ''
      this.newUrlSearch.method = ''
    },
    deleteBtn() {
      if (this.multipleSelection.length === 0) {
        this.$message({
          showClose: true,
          message: '您未选择需要删除的项！',
          type: 'warning'
        })
      } else {
        this.centerDialogVisible = true
      }
    },
    async deletes() {
      const vm = this
      let urlIds = vm.multipleSelection.map(item => item.id)
      urlIds = urlIds.join(',')
      const ret = await request.post('/privilege/menu/deleteMapVisitUrl', { menuId: vm.menuConfig.menuId, urlIds: urlIds })
      if (ret.data.status === 0) {
        vm.urlSearchSubmit()
        vm.$message({
          showClose: true,
          message: '删除成功！',
          type: 'success'
        })
        vm.centerDialogVisible = false
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },

    // URL配置，新增弹窗
    async newUrlSearchSubmit(page) {
      const vm = this
      vm.urlTableLoading = true
      vm.urlConfigData.currentPage = page
      const params = {
        currentPage: page,
        pageSize: vm.urlConfigData.pageSize,
        url: vm.newUrlSearch.urlPath,
        method: vm.newUrlSearch.method
      }
      const ret = await request.post('/privilege/menu/getVisitUrlList', params)
      if (ret.data.status === 0) { // 执行成功
        vm.urlConfigData.records = ret.data.result.result
        vm.urlConfigData.total = ret.data.result.totalCount
      }
      vm.urlTableLoading = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.urlTableLoading = true
      vm.urlConfigData.currentPage = 1
      vm.urlConfigData.pageSize = pageSize
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        url: vm.newUrlSearch.urlPath,
        method: vm.newUrlSearch.method
      }
      const ret = await request.post('/privilege/menu/getVisitUrlList', params)
      if (ret.data.status === 0) { // 执行成功
        vm.urlConfigData.records = ret.data.result.result
        vm.urlConfigData.total = ret.data.result.totalCount
      }
      vm.urlTableLoading = false
    },
    async addNewUrl() {
      const vm = this
      let urlId = vm.urlSelection.map(item => item.id)
      urlId = urlId.join(',')
      const ret = await request.post('/privilege/menu/createMapVisitUrl', { menuId: vm.menuConfig.menuId, urlIds: urlId })
      if (ret.data.status === 0) {
        vm.$message({
          showClose: true,
          message: '保存成功！',
          type: 'success'
        })
        vm.urlShow = false
        vm.urlSearchSubmit()
      }
    },
    urlSelectChange(val) {
      this.urlSelection = val
    },
    refresh() {
      const vm = this
      request.post('/privilege/refreshMenuCache')
        .then(function(res) {
          if (res.data.status === 0) {
            vm.$message({
              showClose: true,
              message: '刷新成功！',
              type: 'success',
              duration: 1500
            })
          }
        })
        .catch(function(err) {
          console.log(err)
        })
    }
  }
}
</script>
<style scoped>
.el-main{
  padding: 0 0 0 20px;
}
.menuConfig{
  margin-top:20px;
}
/deep/ .menuConfig .remark1 .el-input--medium{
  width:712px;
}
/deep/ .menuConfig .remark1 .el-textarea__inner{
  width:712px;
}
/deep/ .menuConfig .el-form-item__label{
  text-align:right;
}
/deep/ .menuConfig .el-input--medium{
  width:230px;
}
/deep/ .menuConfig .el-textarea__inner{
  height:200px;
}
.btnTwo{
  text-align:right;
  padding-right:163px;
}
/deep/ .newMenu .el-dialog__body{
  padding-top:20px;
}
/deep/ .newMenu .el-textarea__inner{
  width:625px;
}
/deep/ .newMenu .el-textarea__inner{
  height:200px;
}
.newMenu .btnTwo{
  padding-right:104px;
}
/deep/ .newUrlConfig .el-dialog__body{
  padding-top:20px;
}
</style>
