<template>
  <div class="app-container" @click="settingBtn=false">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <div slot="header" class="clearfix">
            <span>用户管理</span>
          </div>
          <el-form :inline="true" v-model="userSearch" class="demo-form-inline">
            <el-form-item label="用户名">
              <el-input v-model.trim="userSearch.userName" clearable />
            </el-form-item>
            <el-form-item label="昵称">
              <el-input v-model.trim="userSearch.nickName" clearable />
            </el-form-item>
            <el-form-item label="性别">
              <el-select v-model="userSearch.gender" placeholder="请选择">
                <el-option label="全部" value="" />
                <el-option label="男" value="1" />
                <el-option label="女" value="2" />
                <el-option label="未知" value="-1" />
              </el-select>
            </el-form-item>
            <el-form-item label="邮箱">
              <el-input v-model.trim="userSearch.email" clearable />
            </el-form-item>
            <el-form-item label="手机号码">
              <el-input v-model.trim="userSearch.phoneNo" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="userSearchSubmit(1)">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="success" @click="newlyAdd">新增</el-button>
            </el-form-item>
            <el-form-item style="float:right;position:relative">
              <el-button class="setBtn" type="warning" style="padding:10px 18px" @click.stop="settings"><i class="el-icon-setting" style="padding-right:2px"/>设置</el-button>
              <div v-show="settingBtn" class="filter-container" @click.stop>
                <el-checkbox-group v-model="checkboxVal">
                  <template v-for="item in formTheadOptions">
                    <el-checkbox :label="item.en" :key="item.en">{{ item.cn }}</el-checkbox>
                  </template>
                </el-checkbox-group>
              </div>
            </el-form-item>
          </el-form>
          <el-table v-loading="contentLoading" :key="key" :data="userInfo.records" border fit highlight-current-row style="width: 100%;margin-bottom: 20px">
            <el-table-column v-for="fruit in formThead" :show-overflow-tooltip="true" :key="fruit.en" :prop="fruit.en" :label="fruit.cn">
              <template slot-scope="scope">
                <span v-if="fruit.en==='gender'">
                  {{ scope.row.gender===1?'男':(scope.row.gender===2?'女':'未知') }}
                </span>
                <span v-else-if="fruit.en==='createTime'||fruit.en==='validBeginDate'||fruit.en==='validEndDate'||fruit.en==='modifyTime'">
                  {{ getNowFormatDate(scope.row[fruit.en]) }}
                </span>
                <span v-else>
                  {{ scope.row[fruit.en] }}
                </span>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              align="center"
              width="120px">
              <template slot-scope="scope">
                <!-- <el-tooltip class="item" effect="dark" content="查看权限" placement="top">
                  <el-button type="primary" icon="el-icon-info" circle size="mini" @click="permission(scope.row)"/>
                </el-tooltip> -->
                <el-button type="primary" title="查看权限" icon="el-icon-info" circle size="mini" @click="permission(scope.row)"/>
                <!-- <el-tooltip class="item" effect="dark" content="编辑" placement="top">
                  <el-button type="primary" icon="el-icon-edit" circle size="mini" @click="editTable(scope.row)"/>
                </el-tooltip> -->
                <el-button type="primary" title="编辑" icon="el-icon-edit" circle size="mini" @click="editTable(scope.row)"/>
                <el-popover
                  :ref="`record-${scope.$index}`"
                  v-model="scope.deleteVisible"
                  trigger="click"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click.stop="deleteTable(scope.row,scope);">确定</el-button>
                    <el-button type="primary" size="mini" @click.stop="scope._self.$refs[`record-${scope.$index}`].doClose()">取消</el-button>
                  </div>
                  <el-button slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete" @click.stop="scope.deleteVisible=!scope.deleteVisible" />
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="userInfo.records&&userInfo.records.length"
            :total="userInfo.total"
            :current-page.sync="userInfo.currentPage"
            :page-size.sync="userInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="userSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>

    <!-- 新增/修改用户的弹窗 -->
    <!-- <el-dialog :visible.sync="showNew" :before-close="handleClose" width="1000px" @close="closeNewDialog"> -->
    <el-dialog :visible.sync="showNew" width="1010px" @close="closeNewDialog">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="用户配置" name="first" class="userConfig">
          <el-container style="height: 600px">
            <el-card class="box-card sqqd" style="border:none;width:100%">
              <el-row class="changeAvatar">
                <el-button type="primary" @click="toggleShow">
                  Upload
                  <i class="el-icon-upload el-icon-right"/>
                </el-button>

                <my-upload
                  v-model="show"
                  :width="300"
                  :height="300"
                  :headers="headers"
                  :url="BASE_API+'/privilege/user/uploadImg'"
                  @crop-success="cropSuccess"
                  @crop-upload-success="cropUploadSuccess"
                  @crop-upload-fail="cropUploadFail"
                  @src-file-set="srcFileSet"
                />
                <img :src="imgDataUrl" style="max-width:100px;max-height:100px;">
              </el-row>
              <el-form ref="userConfig" :inline="true" :rules="userRules" :model="userConfig" class="demo-ruleForm">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="用户名" prop="userName">
                      <el-input v-model="userConfig.userName" :disabled="addOrEdit==='add'&&newUserId===''?false:true" clearable />
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="出生年月" prop="birthday">
                      <el-date-picker
                        :editable="false"
                        v-model="userConfig.birthday"
                        type="date"
                        placeholder="选择日期"/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="昵称" prop="nickName">
                      <el-input v-model="userConfig.nickName" clearable/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="性别" prop="gender">
                      <el-select v-model="userConfig.gender" placeholder="请选择">
                        <el-option :value="-1" label="未知"/>
                        <el-option :value="1" label="男"/>
                        <el-option :value="2" label="女"/>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="有效开始日期" prop="validBeginDate">
                      <el-date-picker
                        :editable="false"
                        v-model="userConfig.validBeginDate"
                        :picker-options="pickerOptions"
                        type="datetime"
                        placeholder="选择日期时间"
                        align="right"/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="有效结束日期" prop="validEndDate">
                      <el-date-picker
                        :editable="false"
                        v-model="userConfig.validEndDate"
                        :picker-options="pickerOptions"
                        type="datetime"
                        placeholder="选择日期时间"
                        align="right"/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="邮箱" prop="email">
                      <el-input v-model="userConfig.email" clearable/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="手机号码" prop="phoneNo">
                      <el-input v-model="userConfig.phoneNo" clearable/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="地址" prop="address">
                      <el-input v-model="userConfig.address" clearable/>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="邮编" prop="postcode">
                      <el-input v-model="userConfig.postcode" clearable/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12" class="remarks">
                    <el-form-item label="备注" prop="remark">
                      <el-input v-model="userConfig.remark" type="textarea" clearable/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row class="btnTwo">
                  <el-button type="primary" @click="onSubmit1('userConfig')">保存</el-button>
                  <!-- <el-button @click="resetForm('userConfig')">重置</el-button> -->
                </el-row>
              </el-form>
            </el-card>
          </el-container>
        </el-tab-pane>
        <el-tab-pane :disabled="roleBool" label="角色分配" name="second">
          <el-container style="height: 600px">
            <el-card class="box-card sqqd" style="border:none;width:100%">
              <el-transfer :titles="['未授权','已授权']" :data="roleData" v-model="roleValue"/>
              <el-row class="sumitRow"><el-button type="primary" @click="submitRoles">提交</el-button></el-row>
            </el-card>
          </el-container>
        </el-tab-pane>
        <el-tab-pane :disabled="roleBool" label="密码修改" name="fourth">
          <el-container style="height: 600px">
            <el-card class="box-card sqqd" style="border:none;width:100%">
              <div class="modifyPassword">
                <el-form ref="rulePassForm" :model="rulePassForm" :rules="rulesPass" status-icon label-width="100px" class="demo-ruleForm">
                  <el-form-item label="密码" prop="pass">
                    <el-input v-model="rulePassForm.pass" type="password" auto-complete="off"/>
                  </el-form-item>
                  <el-form-item label="确认密码" prop="checkPass">
                    <el-input v-model="rulePassForm.checkPass" type="password" auto-complete="off"/>
                  </el-form-item>
                  <el-form-item>
                    <el-button type="primary" @click="submitPassForm('rulePassForm')">提交</el-button>
                    <el-button @click="resetPassForm('rulePassForm')">重置</el-button>
                  </el-form-item>
                </el-form>
              </div>
            </el-card>
          </el-container>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>

    <!-- 查看权限的弹窗 -->
    <el-dialog :visible.sync="showViewPermission" width="1010px" @close="closePermission">
      <el-tabs v-model="activePermissionName" @tab-click="permissionClick">
        <el-tab-pane label="菜单权限" name="p1">
          <el-container style="height: 600px">
            <el-aside width="240px">
              <el-card>
                <tree
                  ref="dataTree"
                  :data="treeData"
                  :check-on-click-node="false"
                  :expand-on-click-node="false"
                  :highlight-current="true"
                  node-key="id"
                  default-expand-all
                  @node-click="treeClick">
                  <span slot-scope="{node}" class="custom-tree-node">
                    {{ node.label }}
                  </span>
                </tree>
              </el-card>
            </el-aside>
            <el-container>
              <el-main v-loading="contentLoading1" v-show="showRight">
                <el-form :inline="true" v-model="pathSearch" class="demo-form-inline" style="margin-left:20px">
                  <el-form-item label="URL地址">
                    <el-input v-model.trim="pathSearch.urlPath" clearable />
                  </el-form-item>
                  <el-form-item>
                    <el-button type="primary" @click="urlSearch">查询</el-button>
                  </el-form-item>
                </el-form>
                <el-table
                  :data="perTableData"
                  height="512"
                  border
                  style="width:99%">
                  <el-table-column
                    prop="id"
                    width="50px"
                    label="id"/>
                  <el-table-column
                    prop="urlPath"
                    label="URL地址"/>
                  <el-table-column
                    prop="method"
                    width="80px"
                    label="方法类型"/>
                  <el-table-column
                    prop="createTime"
                    width="170px"
                    label="创建时间">
                    <template slot-scope="scope">
                      <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
                    </template>
                  </el-table-column>
                </el-table>
              </el-main>
            </el-container>
          </el-container>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </div>
</template>

<script>
import { getToken } from '@/utils/auth'
import tree from '../../components/tree'
import request from '@/utils/request'
import myUpload from 'vue-image-crop-upload'
import md5 from 'js-md5'
const defaultFormThead = [
  { en: 'id', cn: '用户ID' },
  { en: 'userName', cn: '用户名' },
  { en: 'nickName', cn: '昵称' },
  { en: 'gender', cn: '性别' },
  { en: 'email', cn: '邮箱' },
  { en: 'createUser', cn: '创建人' },
  { en: 'createTime', cn: '创建时间' },
  { en: 'validBeginDate', cn: '有效开始日期' },
  { en: 'validEndDate', cn: '有效结束日期' }
]
const defaultFormThead1 = [
  'id',
  'userName',
  'nickName',
  'gender',
  'email',
  'createUser',
  'createTime',
  'validBeginDate',
  'validEndDate'
]
export default{
  name: 'UserManage',
  components: { 'my-upload': myUpload, tree },
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.rulePassForm.checkPass !== '') {
          this.$refs.rulePassForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.rulePassForm.pass) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      BASE_API: process.env.BASE_API,
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      contentLoading: false,
      contentLoading1: false,
      settingBtn: false, // 点击“设置”按钮
      addOrEdit: '', // 用于判断，点击了“新增”还是“编辑”按钮
      userSearch: {
        userName: '',
        nickName: '',
        gender: '',
        email: '',
        phoneNo: ''
      },
      userInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      key: 1, // table key
      formTheadOptions: [
        { en: 'id', cn: '用户ID' },
        { en: 'userName', cn: '用户名' },
        { en: 'nickName', cn: '昵称' },
        { en: 'gender', cn: '性别' },
        { en: 'email', cn: '邮箱' },
        { en: 'createUser', cn: '创建人' },
        { en: 'createTime', cn: '创建时间' },
        { en: 'validBeginDate', cn: '有效开始日期' },
        { en: 'validEndDate', cn: '有效结束日期' },
        { en: 'phoneNo', cn: '手机号码' },
        { en: 'address', cn: '地址' },
        { en: 'postcode', cn: '邮编' },
        { en: 'remark', cn: '备注' },
        { en: 'photoPath', cn: '用户头像照片路径' },
        { en: 'birthday', cn: '出生年月' },
        { en: 'modifyUser', cn: '修改人' },
        { en: 'modifyTime', cn: '修改时间' }
      ],
      checkboxVal: defaultFormThead1, // checkboxVal
      formThead: defaultFormThead, // 默认表头 Default header,
      showNew: false, // 点击“新增”按钮的弹窗
      activeName: 'first',
      userConfig: {
        userName: '',
        nickName: '',
        gender: '',
        email: '',
        phoneNo: '',
        address: '',
        postcode: '',
        validBeginDate: '',
        validEndDate: '',
        birthday: '',
        remark: '',
        photoPath: '',
        md5Info: ''
      },
      userRules: {
        userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        nickName: [{ required: true, message: '请输入昵称', trigger: 'blur' }],
        gender: [{ required: true, message: '请选择性别', trigger: 'change' }],
        validBeginDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }],
        validEndDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }]
      },
      show: false,
      headers: {
        adoptToken: getToken()
      },
      imgDataUrl: '',

      // 点击“查看权限”操作-弹窗
      showViewPermission: false,
      activePermissionName: 'p1',

      newUserId: '', // 用户配置保存成功之后获得的新用户的userId
      roleBool: true, // "角色分配"、"授权设置"、"密码修改"，是否可以点击

      // "角色分配"穿梭框
      roleData: [],
      roleValue: [],

      // 密码修改
      rulePassForm: {
        pass: '',
        checkPass: ''
      },
      rulesPass: {
        pass: [{ validator: validatePass, trigger: 'blur' }],
        checkPass: [{ validator: validatePass2, trigger: 'blur' }]
      },

      // “查看权限”弹窗的树
      treeData: [],
      // 点击左侧树，右侧内容是否显示
      showRight: false,
      // 点击左侧树，右侧的表格
      perTableData: [],
      pathSearch: {
        urlPath: ''
      },
      menuId: ''
    }
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i.en) >= 0)
      this.key = this.key + 1// 为了保证table 每次都会重渲
    }
  },
  async created() {
    const vm = this
    vm.contentLoading = true
    const params = {
      adoptToken: localStorage.adoptToken,
      currentPage: 1,
      pageSize: 10,
      userName: '',
      nickName: '',
      gender: '',
      email: '',
      phoneNo: ''
    }
    const ret = await request.post('/privilege/user/selectUsers', params)
    if (ret.data.status === 0) { // 执行成功
      vm.userInfo.records = ret.data.result.result
      vm.userInfo.total = ret.data.result.totalCount
      vm.userInfo.currentPage = ret.data.result.currentPage
    }
    vm.contentLoading = false
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      if (!date) { return '' }
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    async userSearchSubmit(page) {
      const vm = this
      vm.contentLoading = true
      vm.userInfo.currentPage = page
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: page,
        pageSize: vm.userInfo.pageSize,
        userName: vm.userSearch.userName,
        nickName: vm.userSearch.nickName,
        gender: vm.userSearch.gender,
        email: vm.userSearch.email,
        phoneNo: vm.userSearch.phoneNo
      }
      const ret = await request.post('/privilege/user/selectUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.userInfo.records = ret.data.result.result
        vm.userInfo.total = ret.data.result.totalCount
        vm.userInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.contentLoading = true
      vm.userInfo.currentPage = 1
      vm.userInfo.pageSize = pageSize
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: 1,
        pageSize: pageSize,
        userName: vm.userSearch.userName,
        nickName: vm.userSearch.nickName,
        gender: vm.userSearch.gender,
        email: vm.userSearch.email,
        phoneNo: vm.userSearch.phoneNo
      }
      const ret = await request.post('/privilege/user/selectUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.userInfo.records = ret.data.result.result
        vm.userInfo.total = ret.data.result.totalCount
        vm.userInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    // 点击“设置”按钮
    settings() {
      this.settingBtn = !this.settingBtn
    },
    // 点击“新增”按钮
    async newlyAdd() {
      const vm = this
      vm.newUserId = ''
      vm.addOrEdit = 'add'
      vm.roleBool = true
      vm.activeName = 'first'
      vm.showNew = true
    },
    async handleClick(tab, event) {
      const vm = this

      // 点击“角色分配”
      if (tab.name === 'second' && vm.newUserId) {
        const ret = await request.post('/privilege/user/getRoleByUserId', { userId: vm.newUserId })
        if (ret.data.status === 0) {
          if (ret.data.result.rolesList && ret.data.result.rolesList.length > 0) {
            vm.roleData = ret.data.result.rolesList.map(function(item) {
              const obj = {}
              obj.key = item.id
              obj.label = item.roleName
              return obj
            })
          } else {
            vm.roleData = []
          }
          if (ret.data.result.authList && ret.data.result.authList.length > 0) {
            vm.roleValue = ret.data.result.authList.map((item) => { return item.id })
          } else {
            vm.roleValue = []
          }
        }
      }
    },

    toggleShow() {
      this.show = !this.show
    },
    srcFileSet(fileName, fileType, fileSize) {
      // if (fileSize / 1024 / 1024 > 1) {
      //   this.$message({
      //     showClose: true,
      //     message: '头像大小不能超过1M',
      //     type: 'warning'
      //   })
      // }
    },
    cropSuccess(imgDataUrl, field) {
      this.imgDataUrl = imgDataUrl
    },
    cropUploadSuccess(jsonData, field) {
      if (jsonData.status === 0) {
        this.userConfig.md5Info = jsonData.result.md5Info
        this.userConfig.photoPath = jsonData.result.photoPath
      }
    },
    cropUploadFail(status, field) {
      console.log('-------- upload fail --------')
      console.log(status)
      console.log('field: ' + field)
    },
    onSubmit1(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) { // 必填项全部填完
          const validBeginDate = vm.getNowFormatDate(vm.userConfig.validBeginDate)
          const validEndDate = vm.getNowFormatDate(vm.userConfig.validEndDate)
          let birthday = ''
          if (vm.userConfig.birthday) {
            birthday = vm.getNowFormatDate(vm.userConfig.birthday)
            const birArr = birthday.split(' ')
            birthday = birArr[0]
          }
          const params = {
            photoPath: vm.userConfig.photoPath,
            md5Info: vm.userConfig.md5Info,
            userName: vm.userConfig.userName,
            nickName: vm.userConfig.nickName,
            gender: vm.userConfig.gender,
            email: vm.userConfig.email,
            phoneNo: vm.userConfig.phoneNo,
            address: vm.userConfig.address,
            postcode: vm.userConfig.postcode,
            validBeginDate: validBeginDate,
            validEndDate: validEndDate,
            birthday: birthday,
            remark: vm.userConfig.remark
          }
          let api = ''
          if (vm.addOrEdit === 'add') { // 新增用户
            api = '/privilege/user/createUser'
          } else { // 编辑用户
            api = '/privilege/user/modifyUser'
            params.userId = vm.newUserId
            if (vm.userConfig.photoPath) {
              const pArr = vm.userConfig.photoPath.split('md5Info=')
              params.md5Info = pArr[1]
            } else {
              params.md5Info = ''
            }
          }
          request.post(api, params).then(function(res) {
            if (res.data.status === 0) {
              if (vm.addOrEdit === 'add') {
                vm.roleBool = false
                vm.newUserId = res.data.result.id
                vm.$message({
                  showClose: true,
                  message: '新增用户成功！',
                  type: 'success'
                })
                vm.userSearchSubmit(1)
              } else {
                vm.$message({
                  showClose: true,
                  message: '编辑用户成功！',
                  type: 'success'
                })
                vm.userSearchSubmit(1)
              }
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 点击“重置”按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.imgDataUrl = ''
      this.userConfig.photoPath = ''
      this.userConfig.md5Info = ''
    },

    permissionClick(tab, event) {

    },
    // 查看权限
    async permission(data) {
      const vm = this
      vm.newUserId = data.id
      vm.activePermissionName = 'p1'
      const ret = await request.post('/privilege/user/getAuthMenuTree', { userId: data.id })
      if (ret.data.status === 0) {
        if (!ret.data.result) {
          vm.treeData = []
        } else {
          vm.treeData = Object.assign([], ret.data.result.children)
        }
        vm.showViewPermission = true
      }
    },
    // 编辑
    editTable(data) {
      const vm = this
      vm.showNew = true
      vm.addOrEdit = 'edit'
      vm.roleBool = false
      // 获取用户配置里的用户信息
      request.post('/privilege/user/getUserById', { userId: data.id }).then(function(res) {
        if (res.data.status === 0) {
          vm.newUserId = res.data.result.id
          vm.userConfig.userName = res.data.result.userName
          vm.userConfig.nickName = res.data.result.nickName
          vm.userConfig.gender = res.data.result.gender
          vm.userConfig.email = res.data.result.email
          vm.userConfig.phoneNo = res.data.result.phoneNo
          vm.userConfig.address = res.data.result.address
          vm.userConfig.postcode = res.data.result.postcode
          vm.userConfig.validBeginDate = res.data.result.validBeginDate
          vm.userConfig.validEndDate = res.data.result.validEndDate
          vm.userConfig.birthday = res.data.result.birthday
          vm.userConfig.remark = res.data.result.remark
          vm.userConfig.photoPath = res.data.result.photoPath
          vm.userConfig.md5Info = res.data.result.md5Info
          if (res.data.result.photoPath) {
            vm.imgDataUrl = vm.BASE_API + res.data.result.photoPath
          } else {
            vm.imgDataUrl = ''
          }
        }
      })
    },
    // 点击“确定”按钮删除
    deleteTable(data, scope) {
      const vm = this
      request.post('/privilege/user/deleteUser', { userId: data.id }).then(function(res) {
        if (res.data.status === 0) { // 删除成功
          vm.$message({
            showClose: true,
            message: '该用户成功删除！',
            type: 'success'
          })
          scope._self.$refs[`record-${scope.$index}`].doClose()
          vm.userSearchSubmit(vm.userInfo.currentPage)
        }
      })
    },
    // 询问是否确定关闭新增用户的弹窗
    // handleClose(done) {
    //   this.$confirm('确认关闭？').then(_ => { done() }).catch(_ => {})
    // },
    // 确定关闭新增用户的弹窗
    closeNewDialog() {
      this.resetForm('userConfig')
      this.newUserId = ''
      this.imgDataUrl = ''
      this.activeName = 'first'
    },
    // “角色分配”，点击“提交”按钮
    submitRoles() {
      const vm = this
      const roleIds = vm.roleValue.join(',')
      request.post('/privilege/user/modifyUserRole', { userId: vm.newUserId, roleIds: roleIds })
        .then(function(res) {
          if (res.data.status === 0) {
            vm.$message({
              showClose: true,
              message: '授权成功！',
              type: 'success'
            })
          }
        })
    },

    submitPassForm(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) {
          request.post('/privilege/user/passWordSuperAdmin',
            {
              userId: vm.newUserId,
              newPassWord: md5(vm.rulePassForm.checkPass)
            }).then(function(res) {
            if (res.data.status === 0) {
              vm.$message({
                showClose: true,
                message: '密码修改成功！',
                type: 'success'
              })
            } else {
              vm.$message({
                showClose: true,
                message: '密码修改失败！',
                type: 'error'
              })
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetPassForm(formName) {
      this.$refs[formName].resetFields()
    },

    // 点击：“查看权限”-树
    async treeClick(data, node, e) {
      const vm = this
      vm.contentLoading1 = true
      vm.showRight = true
      vm.menuId = data.id
      vm.pathSearch.urlPath = ''
      const ret = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: data.id })
      if (ret.data.status === 0) {
        vm.perTableData = Object.assign([], ret.data.result)
      } else {
        vm.perTableData = []
      }
      vm.contentLoading1 = false
    },
    async urlSearch() {
      const vm = this
      vm.contentLoading1 = true
      const ret = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: vm.menuId, url: vm.pathSearch.urlPath })
      if (ret.data.status === 0) {
        vm.perTableData = Object.assign([], ret.data.result)
      } else {
        vm.perTableData = []
      }
      vm.contentLoading1 = false
    },
    closePermission() {
      this.menuId = ''
      this.perTableData = []
      this.showRight = false
      this.activePermissionName = 'p1'
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
.filter-container{
  position: absolute;
  width:300px;
  z-index:100;
  background-color: #fff;
  border:1px solid #dcdfe6;
  right:0;
  padding-left:10px;
  padding-top:3px;
  border-radius:4px;
}
.filter-container .el-checkbox{
  margin:0;
  width:50%;
}
/deep/ .el-dialog__headerbtn{
  z-index:1000;
}
.el-tabs--top{
  position: relative;
  top:-45px;
}
.avatar{
  width: 200px;
  height: 200px;
  border-radius: 50%;
}
/deep/ .userConfig .el-form-item__label{
  width:150px;
  text-align: right;
}
/deep/ .userConfig .el-input--medium{
  width:210px;
}
.btnTwo{
  text-align:right;
  padding-right:122px;
}
.changeAvatar{
  padding-left:38px;
  margin-bottom:20px;
}
.changeAvatar>img{
  max-width:100px;
  max-height:100px;
  position:relative;
  top:13px;
  left:10px;
}
/deep/ .el-dialog__body{
  padding:30px 20px 0;
  /* height:600px; */
}
/deep/ .sqqd>.el-card__body{
  padding:0;
}
.el-button+.el-button{
  margin-left:0;
}
/deep/ .el-transfer-panel{
  width:410px;
}
/deep/ .el-transfer-panel__body{
  height:470px;
}
/deep/ .el-transfer-panel__list{
  height:470px;
}
.sumitRow{
  float:right;
  margin-top:20px;
}
.libraryType1{
  width:180px;
}
.powerBool .el-input{
  width:180px;
}
.modifyPassword{
  margin-top:30px;
  width:50%;
}
/deep/ .remarks .el-textarea__inner{
  width:696px;
  height:80px;
}
/deep/ .remarks .el-form-item--medium{
  margin-bottom:10px;
}
</style>
