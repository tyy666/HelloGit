<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <div slot="header" class="clearfix">
            <span>角色管理</span>
          </div>
          <el-form :inline="true" v-model="roleSearch" class="demo-form-inline">
            <el-form-item label="角色名称">
              <el-input v-model.trim="roleSearch.roleName" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="roleSearchSubmit(1)">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="success" @click="newlyAdd">新增</el-button>
            </el-form-item>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="roleInfo.records"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              prop="id"
              label="角色ID"
              align="center"
              width="80px"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="roleName"
              label="角色名称"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="remark"
              label="角色描述"
              align="center"
            />
            <el-table-column
              prop="sortIndex"
              label="排序索引"
              align="center"
              width="80px"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="validBeginDate"
              label="有效开始时间"
              align="center">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.validBeginDate) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="validEndDate"
              label="有效结束时间"
              align="center">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.validEndDate) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="createUser"
              label="创建人"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="createTime"
              label="创建时间"
              align="center">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="modifyUser"
              label="修改人"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="modifyTime"
              label="修改时间"
              align="center">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.modifyTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              align="center"
              width="90px">
              <template slot-scope="scope">
                <el-button type="primary" title="编辑" icon="el-icon-edit" circle size="mini" @click="editTable(scope.row)"/>
                <el-popover
                  :ref="`record-${scope.$index}`"
                  v-model="scope.deleteVisible"
                  trigger="click"
                  placement="top"
                  width="160">
                  <p>确定要删除吗？</p>
                  <div style="text-align: right; margin: 0">
                    <el-button type="primary" size="mini" @click.stop="deleteTable(scope.row,scope);">确定</el-button>
                    <el-button type="primary" size="mini" @click.stop="scope._self.$refs[`record-${scope.$index}`].doClose()">取消</el-button>
                  </div>
                  <el-button v-show="scope.row.id===-1?false:true" slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete" @click.stop="scope.deleteVisible=!scope.deleteVisible" />
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="roleInfo.records&&roleInfo.records.length"
            :total="roleInfo.total"
            :current-page.sync="roleInfo.currentPage"
            :page-size.sync="roleInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="roleSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>

    <el-dialog :visible.sync="showNew" width="1010px" @close="closeNewDialog">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="角色配置" name="first" class="roleConfig">
          <el-container style="height: 550px;padding-top:30px">
            <el-form ref="roleConfig" :inline="true" :rules="roleRules" :model="roleConfig" class="demo-ruleForm">
              <el-row>
                <el-col :span="12">
                  <el-form-item label="角色名称" prop="roleName">
                    <el-input v-model="roleConfig.roleName" clearable/>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="排序索引" prop="sortIndex">
                    <el-input v-enter-number v-model.number="roleConfig.sortIndex" type="text" />
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="12">
                  <el-form-item label="有效开始日期" prop="validBeginDate">
                    <el-date-picker
                      :editable="false"
                      v-model="roleConfig.validBeginDate"
                      :picker-options="pickerOptions"
                      type="datetime"
                      placeholder="选择日期时间"
                      align="right"/>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="有效结束日期" prop="validEndDate">
                    <el-date-picker
                      :editable="false"
                      v-model="roleConfig.validEndDate"
                      :picker-options="pickerOptions"
                      type="datetime"
                      placeholder="选择日期时间"
                      align="right"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="24">
                  <el-form-item label="角色描述" prop="remark" class="remark1">
                    <el-input v-model="roleConfig.remark" type="textarea"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="btnTwo">
                <el-button type="primary" @click="onSubmit('roleConfig')">保存</el-button>
                <el-button @click="resetForm('roleConfig')">重置</el-button>
              </el-row>
            </el-form>
          </el-container>
        </el-tab-pane>
        <el-tab-pane :disabled="roleBool" label="资源分配" name="second">
          <el-container style="height: 550px">
            <el-aside width="240px">
              <el-card>
                <el-tree
                  ref="tree"
                  :data="treeData"
                  :default-expand-all="true"
                  :default-checked-keys="treeCheckArr"
                  :props="defaultProps"
                  show-checkbox
                  node-key="id"
                  @check-change="handleCheckChange"
                  @node-click="treeClick"/>
              </el-card>
            </el-aside>
            <el-container>
              <el-main style="height: 530px">
                <div v-loading="contentLoading1" v-show="showRight">
                  <el-form :inline="true" v-model="pathSearch" class="demo-form-inline" style="margin-left:20px">
                    <el-form-item label="URL地址">
                      <el-input v-model.trim="pathSearch.urlPath" clearable />
                    </el-form-item>
                    <el-form-item>
                      <el-button type="primary" @click="urlSearch">查询</el-button>
                    </el-form-item>
                  </el-form>
                  <el-table
                    :data="perTableData"
                    border
                    height="442px"
                    style="width:99%">
                    <el-table-column
                      prop="id"
                      width="50px"
                      label="id"/>
                    <el-table-column
                      prop="urlPath"
                      label="URL地址"/>
                    <el-table-column
                      prop="method"
                      width="80px"
                      label="方法类型"/>
                    <el-table-column
                      prop="createTime"
                      width="170px"
                      label="创建时间">
                      <template slot-scope="scope">
                        <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </el-main>
              <el-footer style="height:36px"><el-button class="suBtn" type="primary" @click="submitMenuIds">提交</el-button></el-footer>
            </el-container>
          </el-container>
        </el-tab-pane>
        <el-tab-pane :disabled="roleBool" label="人员分配" name="third">
          <el-container style="height:550px;">
            <el-card class="box-card" style="border:none;width:100%">
              <el-form :inline="true" v-model="personnelSearch" class="demo-form-inline" style="margin-left:20px">
                <el-form-item label="用户名">
                  <el-input v-model.trim="personnelSearch.userName" clearable />
                </el-form-item>
                <el-form-item label="昵称">
                  <el-input v-model.trim="personnelSearch.nickName" clearable />
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="personnelSubmit(1)">查询</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button type="success" @click="addPerson">新增</el-button>
                </el-form-item>
              </el-form>
              <el-table
                ref="multipleTable"
                :data="personInfo.records"
                highlight-current-row
                border
                height="400"
                style="width: 100%;margin-bottom: 20px">
                <el-table-column
                  :show-overflow-tooltip="true"
                  prop="userName"
                  label="用户名"/>
                <el-table-column
                  :show-overflow-tooltip="true"
                  prop="nickName"
                  label="昵称"/>
                <el-table-column
                  prop="gender"
                  label="性别">
                  <template slot-scope="scope">
                    {{ scope.row.gender===1?'男':(scope.row.gender===2?'女':'未知') }}
                  </template>
                </el-table-column>
                <el-table-column
                  :show-overflow-tooltip="true"
                  prop="email"
                  label="邮箱"/>
                <el-table-column
                  :show-overflow-tooltip="true"
                  prop="validBeginDate"
                  label="有效开始日期">
                  <template slot-scope="scope">
                    <span>{{ getNowFormatDate(scope.row.validBeginDate) }}</span>
                  </template>
                </el-table-column>
                <el-table-column
                  :show-overflow-tooltip="true"
                  prop="validEndDate"
                  label="有效结束日期">
                  <template slot-scope="scope">
                    <span>{{ getNowFormatDate(scope.row.validEndDate) }}</span>
                  </template>
                </el-table-column>
                <el-table-column
                  fixed="right"
                  label="操作"
                  align="center"
                  width="70px">
                  <template slot-scope="scope">
                    <el-popover
                      :ref="`record-${scope.$index}`"
                      v-model="scope.deleteVisible"
                      trigger="click"
                      placement="top"
                      width="160">
                      <p>确定要删除吗？</p>
                      <div style="text-align: right; margin: 0">
                        <el-button type="primary" size="mini" @click.stop="deleteT1(scope.row,scope);">确定</el-button>
                        <el-button type="primary" size="mini" @click.stop="scope._self.$refs[`record-${scope.$index}`].doClose()">取消</el-button>
                      </div>
                      <el-button slot="reference" title="删除" circle type="danger" size="mini" icon="el-icon-delete" @click.stop="scope.deleteVisible=!scope.deleteVisible" />
                    </el-popover>
                  </template>
                </el-table-column>
              </el-table>
              <el-pagination
                v-if="personInfo.records&&personInfo.records.length"
                :total="personInfo.total"
                :current-page.sync="personInfo.currentPage"
                :page-size.sync="personInfo.pageSize"
                :page-sizes="[5,10,15,20]"
                background
                layout="jumper,prev, pager, next,total,sizes"
                style="text-align: center"
                @size-change="sizeChangeP"
                @current-change="personnelSubmit"/>
            </el-card>
          </el-container>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>

    <!-- 人员分配-新增的弹窗 -->
    <el-dialog :visible.sync="personShow" width="1010px" title="用户查询" class="newPerson" @close="closePersonDialog">
      <el-container style="height: 540px">
        <el-card class="box-card" style="border:none;width:100%">
          <el-form :inline="true" v-model="personAssign" class="demo-form-inline">
            <el-form-item label="用户名">
              <el-input v-model.trim="personAssign.userName" clearable />
            </el-form-item>
            <el-form-item label="昵称">
              <el-input v-model.trim="personAssign.nickName" clearable />
            </el-form-item>
            <el-form-item label="性别">
              <el-select v-model="personAssign.gender" placeholder="请选择">
                <el-option label="全部" value="" />
                <el-option label="男" value="1" />
                <el-option label="女" value="2" />
                <el-option label="未知" value="-1" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submit2D(1)">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="success" @click="personSave">保存</el-button>
            </el-form-item>
          </el-form>
          <el-table
            ref="multipleTable"
            :data="personTableInfo.records"
            border
            style="width: 100%"
            height="400"
            @selection-change="handleSelectionChange">
            <el-table-column
              type="selection"
              width="55"/>
            <el-table-column
              show-overflow-tooltip
              prop="userName"
              label="用户名"/>
            <el-table-column
              show-overflow-tooltip
              prop="nickName"
              label="昵称"/>
            <el-table-column
              show-overflow-tooltip
              prop="gender"
              label="性别">
              <template slot-scope="scope">
                {{ scope.row.gender===1?'男':(scope.row.gender===2?'女':'未知') }}
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="email"
              label="邮箱"/>
            <el-table-column
              show-overflow-tooltip
              prop="createUser"
              label="创建人"/>
            <el-table-column
              show-overflow-tooltip
              prop="createTime"
              label="创建时间">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.createTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="validBeginDate"
              label="有效开始日期">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.validBeginDate) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="validEndDate"
              label="有效结束日期">
              <template slot-scope="scope">
                <span>{{ getNowFormatDate(scope.row.validEndDate) }}</span>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="personTableInfo.records&&personTableInfo.records.length"
            :total="personTableInfo.total"
            :current-page.sync="personTableInfo.currentPage"
            :page-size.sync="personTableInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center;margin-top:10px"
            @size-change="sizeChange2D"
            @current-change="submit2D"/>
        </el-card>
      </el-container>
    </el-dialog>
  </div>
</template>
<script>
import request from '@/utils/request'
export default{
  data() {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      contentLoading: false,
      contentLoading1: false,
      roleSearch: {
        roleName: ''
      },
      roleInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      showNew: false, // 点击“新增”按钮的弹窗
      activeName: 'first',
      addOrEdit: '', // 用于判断，点击了“新增”还是“编辑”按钮
      roleConfig: {
        roleName: '',
        sortIndex: '',
        validBeginDate: '',
        validEndDate: '',
        remark: ''
      },
      roleRules: {
        roleName: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
        validBeginDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }],
        validEndDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }],
        sortIndex: [{ type: 'number', required: false, message: '排序索引必须是非负整数', trigger: 'blur' }]
      },
      roleId: '', // 角色配置保存成功之后获得的新角色的roleId
      roleBool: true, // "资源分配"、"人员分配"，是否可以点击

      // 资源分配
      treeData: [],
      treeCheckArr: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      // 点击左侧树，右侧内容是否显示
      showRight: false,
      // 点击左侧树，右侧的表格
      perTableData: [],
      pathSearch: {
        urlPath: ''
      },
      menuId: '',
      personnelSearch: {
        userName: '',
        nickName: ''
      },
      personInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      personShow: false, // 点击人员分配-“新增”按钮的弹窗
      personAssign: {
        userName: '',
        nickName: '',
        gender: ''
      },
      personTableInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      multipleSelection: []
    }
  },
  created() {
    const vm = this
    request.post('/privilege/role/selectRoles',
      {
        currentPage: 1,
        pageSize: 10,
        roleName: ''
      })
      .then(function(res) {
        if (res.data.status === 0) {
          vm.roleInfo.records = res.data.result.result
          vm.roleInfo.total = res.data.result.totalCount
          vm.roleInfo.currentPage = res.data.result.currentPage
        }
      })
      .catch(function(err) {
        console.log(err)
      })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      if (!date) { return '' }
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    // "查询"
    async roleSearchSubmit(page) {
      const vm = this
      vm.contentLoading = true
      vm.roleInfo.currentPage = page
      const params = {
        currentPage: page,
        pageSize: vm.roleInfo.pageSize,
        roleName: vm.roleSearch.roleName
      }
      const ret = await request.post('/privilege/role/selectRoles', params)
      if (ret.data.status === 0) { // 执行成功
        vm.roleInfo.records = ret.data.result.result
        vm.roleInfo.total = ret.data.result.totalCount
        vm.roleInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    // 点击“新增”按钮
    async newlyAdd() {
      const vm = this
      vm.showNew = true
      vm.addOrEdit = 'add'
      vm.roleBool = true
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.contentLoading = true
      vm.roleInfo.currentPage = 1
      vm.roleInfo.pageSize = pageSize
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        roleName: vm.roleSearch.roleName
      }
      const ret = await request.post('/privilege/role/selectRoles', params)
      if (ret.data.status === 0) { // 执行成功
        vm.roleInfo.records = ret.data.result.result
        vm.roleInfo.total = ret.data.result.totalCount
        vm.roleInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async sizeChangeP(pageSize) {
      const vm = this
      vm.personInfo.currentPage = 1
      vm.personInfo.pageSize = pageSize
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        roleId: vm.roleId,
        userName: vm.personnelSearch.userName,
        nickName: vm.personnelSearch.nickName
      }
      const ret = await request.post('/privilege/role/getRoleUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.personInfo.records = ret.data.result.result
        vm.personInfo.total = ret.data.result.totalCount
        vm.personInfo.currentPage = ret.data.result.currentPage
      }
    },
    async sizeChange2D(pageSize) {
      const vm = this
      vm.personTableInfo.currentPage = 1
      vm.personTableInfo.pageSize = pageSize
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        userName: vm.personAssign.userName,
        nickName: vm.personAssign.nickName,
        gender: vm.personAssign.gender
      }
      const ret = await request.post('/privilege/user/selectUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.personTableInfo.records = ret.data.result.result
        vm.personTableInfo.total = ret.data.result.totalCount
        vm.personTableInfo.currentPage = ret.data.result.currentPage
      }
    },
    async submit2D(page) {
      const vm = this
      vm.personTableInfo.currentPage = page
      const params = {
        currentPage: page,
        pageSize: vm.personTableInfo.pageSize,
        userName: vm.personAssign.userName,
        nickName: vm.personAssign.nickName,
        gender: vm.personAssign.gender
      }
      const ret = await request.post('/privilege/user/selectUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.personTableInfo.records = ret.data.result.result
        vm.personTableInfo.total = ret.data.result.totalCount
        vm.personTableInfo.currentPage = ret.data.result.currentPage
      }
    },
    closeNewDialog() {
      this.resetForm('roleConfig')
      this.roleId = ''
      this.activeName = 'first'
      this.treeData = []
      this.treeCheckArr = []
      this.personInfo.records = []
    },
    async handleClick(tab, event) {
      const vm = this
      // 点击“资源分配”
      if (tab.name === 'second' && vm.roleId) {
        if (vm.treeData.length === 0) {
          const ret = await request.post('/privilege/role/getRoleMenuTree', { roleId: vm.roleId })
          if (ret.data.status === 0) {
            vm.treeData = Object.assign([], ret.data.result.vueTree.children)
            vm.treeCheckArr = Object.assign([], ret.data.result.checked)
          } else {
            vm.treeData = []
            vm.treeCheckArr = []
          }
        }
      }
      // 点击“人员分配”
      if (tab.name === 'third' && vm.roleId) {
        if (vm.personInfo.records.length === 0) {
          const res = await request.post('/privilege/role/getRoleUsers',
            {
              currentPage: vm.personInfo.currentPage,
              pageSize: vm.personInfo.pageSize,
              roleId: vm.roleId,
              userName: vm.personnelSearch.userName,
              nickName: vm.personnelSearch.nickName
            })
          if (res.data.status === 0) {
            vm.personInfo.records = res.data.result.result
            vm.personInfo.total = res.data.result.totalCount
          }
        }
      }
    },
    // 编辑
    editTable(data) {
      const vm = this
      vm.showNew = true
      vm.addOrEdit = 'edit'
      vm.roleBool = false
      request.post('/privilege/role/getRoleById', { roleId: data.id }).then(function(res) {
        if (res.data.status === 0) {
          vm.roleId = res.data.result.id
          vm.roleConfig.roleName = res.data.result.roleName
          vm.roleConfig.sortIndex = res.data.result.sortIndex
          vm.roleConfig.validBeginDate = res.data.result.validBeginDate
          vm.roleConfig.validEndDate = res.data.result.validEndDate
          vm.roleConfig.remark = res.data.result.remark
        }
      })
    },
    // 点击“确定”按钮删除
    deleteTable(data, scope) {
      const vm = this
      request.post('/privilege/role/deleteRole', { roleId: data.id }).then(function(res) {
        if (res.data.status === 0) { // 删除成功
          vm.$message({
            showClose: true,
            message: '该角色成功删除！',
            type: 'success'
          })
          scope._self.$refs[`record-${scope.$index}`].doClose()
          vm.roleSearchSubmit(vm.roleInfo.currentPage)
        }
      })
    },
    deleteT1(data, scope) {
      const vm = this
      request.post('/privilege/role/deleteRoleUser', { userIds: data.id, roleId: vm.roleId }).then(function(res) {
        if (res.data.status === 0) { // 删除成功
          vm.$message({
            showClose: true,
            message: '该用户成功删除！',
            type: 'success'
          })
          scope._self.$refs[`record-${scope.$index}`].doClose()
          vm.personnelSubmit(vm.personInfo.currentPage)
        }
      })
    },
    // 点击“重置”按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    onSubmit(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) { // 必填项全部填完
          const validBeginDate = vm.getNowFormatDate(vm.roleConfig.validBeginDate)
          const validEndDate = vm.getNowFormatDate(vm.roleConfig.validEndDate)
          const params = {
            roleName: vm.roleConfig.roleName,
            sortIndex: vm.roleConfig.sortIndex,
            validBeginDate: validBeginDate,
            validEndDate: validEndDate,
            remark: vm.roleConfig.remark
          }
          let api = ''
          if (vm.addOrEdit === 'add') { // 新增角色
            api = '/privilege/role/createRole'
          } else { // 编辑角色
            api = '/privilege/role/modifyRole'
            params.roleId = vm.roleId
          }
          request.post(api, params).then(function(res) {
            if (res.data.status === 0) {
              if (vm.addOrEdit === 'add') {
                vm.roleBool = false
                vm.roleId = res.data.result.id
                vm.$message({
                  showClose: true,
                  message: '新增角色成功！',
                  type: 'success'
                })
                vm.roleSearchSubmit(1)
              } else {
                vm.$message({
                  showClose: true,
                  message: '编辑角色成功！',
                  type: 'success'
                })
                vm.roleSearchSubmit(1)
              }
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 点击：“查看权限”-树
    async treeClick(data, node, e) {
      const vm = this
      vm.contentLoading1 = true
      vm.showRight = true
      vm.menuId = data.id
      vm.pathSearch.urlPath = ''
      const ret = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: data.id })
      if (ret.data.status === 0) {
        vm.perTableData = Object.assign([], ret.data.result)
      } else {
        vm.perTableData = []
      }
      vm.contentLoading1 = false
    },
    async urlSearch() {
      const vm = this
      vm.contentLoading1 = true
      const ret = await request.post('/privilege/menu/getMenuVisitUrl', { menuId: vm.menuId, url: vm.pathSearch.urlPath })
      if (ret.data.status === 0) {
        vm.perTableData = Object.assign([], ret.data.result)
      } else {
        vm.perTableData = []
      }
      vm.contentLoading1 = false
    },
    handleCheckChange(data, checked, indeterminate) {
      if (checked) {
        this.treeCheckArr.push(data.id)
      } else {
        const index = this.treeCheckArr.findIndex(item => item === data.id)
        this.treeCheckArr.splice(index, 1)
      }
    },
    // 点击“资源分配”，提交按钮
    async submitMenuIds() {
      const vm = this
      const menuIds = vm.treeCheckArr.join(',')
      const ret = await request.post('/privilege/role/modifyRoleMenu', { roleId: vm.roleId, menuIds: menuIds })
      if (ret.data.status === 0) {
        this.$message({
          showClose: true,
          message: '成功修改权限！',
          type: 'success'
        })
      } else {
        this.$message({
          showClose: true,
          message: '修改权限失败！',
          type: 'error'
        })
      }
    },
    async personnelSubmit(page) {
      const vm = this
      vm.contentLoading = true
      vm.personInfo.currentPage = page
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: page,
        pageSize: vm.personInfo.pageSize,
        roleId: vm.roleId,
        userName: vm.personnelSearch.userName,
        nickName: vm.personnelSearch.nickName
      }
      const ret = await request.post('/privilege/role/getRoleUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.personInfo.records = ret.data.result.result
        vm.personInfo.total = ret.data.result.totalCount
        vm.personInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async addPerson() {
      const vm = this
      vm.personShow = true
      const params = {
        currentPage: 1,
        pageSize: 10,
        userName: '',
        nickName: '',
        gender: ''
      }
      const ret = await request.post('/privilege/user/selectUsers', params)
      if (ret.data.status === 0) { // 执行成功
        vm.personTableInfo.records = ret.data.result.result
        vm.personTableInfo.total = ret.data.result.totalCount
        vm.personTableInfo.currentPage = ret.data.result.currentPage
      }
    },
    closePersonDialog() {
      this.personAssign.userName = ''
      this.personAssign.nickName = ''
      this.personAssign.gender = ''
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    personSave() {
      const vm = this
      const arr = vm.multipleSelection.map(item => item.id)
      const userIds = arr.join(',')
      request.post('/privilege/role/createRoleUser', { userIds: userIds, roleId: vm.roleId })
        .then(function(res) {
          console.dir(res)
          if (res.data.status === 0) {
            vm.$message({
              showClose: true,
              message: '保存成功！',
              type: 'success'
            })
            vm.personShow = false
            vm.personnelSubmit(1)
          }
        })
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
/deep/ .el-dialog__headerbtn{
  z-index:1000;
}
.el-tabs--top{
  position: relative;
  top:-45px;
}
/deep/ .roleConfig .el-form-item__label{
  width:150px;
  text-align: right;
}
/deep/ .roleConfig .el-input--medium{
  width:210px;
}
/deep/ .roleConfig .remark1 .el-input--medium{
  width:690px;
}
/deep/ .roleConfig .el-textarea__inner{
  height:200px;
}
.btnTwo{
  text-align:right;
  padding-right:122px;
}
.demo-ruleForm{
  width:100%;
}
.el-tree{
  width:100%;
}
.el-footer{
  margin-top:0;
  padding:0;
}
.suBtn{
  float:right;
}
/deep/ .el-dialog__body{
  padding:30px 20px 0;
}
/deep/ .newPerson .el-dialog__body{
  padding:0 20px;
}
.newPerson .el-card.is-always-shadow,
.newPerson .el-card.is-hover-shadow:focus, .el-card.is-hover-shadow:hover{
  box-shadow: none;
  -webkit-box-shadow:none;
}
</style>

