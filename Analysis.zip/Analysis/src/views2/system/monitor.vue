<template>
  <div class="dashboard-editor-container">
    <!--日志折线图-->
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <el-row style="height:70px">
        <div style="width:160px;float:left">
          <el-switch
            v-model="operateTimeDayLevel"
            style="display: block"
            active-color="#13ce66"
            inactive-color="#409EFF"
            active-text="天粒度"
            inactive-text="小时粒度"
            @change="changeOperateTimeLevel(operateTimeDayLevel)"/>
        </div>
        <div v-show="!operateTimeDayLevel" class="block" style="float:left;margin: -5px 0px 7px 49px;">
          <span class="demonstration">时间</span>
          <el-date-picker
            v-model="operateHourTime"
            :picker-options="pickerOptions"
            type="date"
            placeholder="选择日期时间"
            align="right"/>
        </div>
        <div v-show="operateTimeDayLevel" class="block" style="float:left;margin: -5px 0px 7px 49px;">
          <span class="demonstration">时间</span>
          <el-date-picker
            v-model="operateDayRangeTime"
            :picker-options="pickerOptionsDay"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"/>
        </div>
        <el-button type="primary" style="float:left;margin: -5px 0px 7px 49px;" @click="searchOperateLine()">查询</el-button>
      </el-row>
      <line-chart :chart-data="operateLineChartData"/>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <el-row style="height:70px">
        <div style="width:160px;float:left">
          <el-switch
            v-model="loginTimeDayLevel"
            style="display: block"
            active-color="#13ce66"
            inactive-color="#409EFF"
            active-text="天粒度"
            inactive-text="小时粒度"
            @change="changeLoginTimeLevel(loginTimeDayLevel)"/>
        </div>
        <div v-show="!loginTimeDayLevel" class="block" style="float:left;margin: -5px 0px 7px 49px;">
          <span class="demonstration">时间</span>
          <el-date-picker
            v-model="loginHourTime"
            :picker-options="pickerOptions"
            type="date"
            placeholder="选择日期时间"
            align="right"/>
        </div>
        <div v-show="loginTimeDayLevel" class="block" style="float:left;margin: -5px 0px 7px 49px;">
          <span class="demonstration">时间</span>
          <el-date-picker
            v-model="loginDayRangeTime"
            :picker-options="pickerOptionsDay"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"/>
        </div>
        <el-button type="primary" style="float:left;margin: -5px 0px 7px 49px;" @click="searchLoginLine()">查询</el-button>
      </el-row>
      <line-chart :chart-data="loginLineChartData"/>
    </el-row>

    <!--服务信息-->
    <el-card class="box-card" style="min-height:230px">
      <el-table :key="key" :data="confInfoBeat.records" border fit highlight-current-row style="width: 100%;height:100%">
        <el-table-column v-for="fruit in formThead" :show-overflow-tooltip="true" :key="fruit.en" :prop="fruit.en" :label="fruit.cn" :width="(fruit.en==='serverIp' || fruit.en==='os' || fruit.en==='network') ? '343' : ((fruit.en==='serverStatus')?'100':'200')">
          <template slot-scope="scope">
            <span v-if="fruit.en==='serverStatus'">
              {{ getServerStatus(scope.row) }}
            </span>
            <span v-else-if="fruit.en==='memory'">
              <span :title="getMemoryProgressTitle(scope.row[fruit.en])">
                <el-progress :text-inside="true" :stroke-width="20" :percentage="getMemoryProgress(scope.row[fruit.en])"/>
              </span>
            </span>
            <span v-else-if="fruit.en==='cpu'">
              <span>
                <el-progress :text-inside="true" :stroke-width="20" :percentage="Math.ceil(100*(scope.row[fruit.en]))"/>
              </span>
            </span>
            <span v-else-if="fruit.en==='disk'">
              <span :title="getDiskProgressTitle(scope.row[fruit.en])">
                <el-progress :text-inside="true" :stroke-width="20" :percentage="getDiskProgress(scope.row[fruit.en])"/>
              </span>
            </span>
            <span v-else>
              {{ scope.row[fruit.en] }}
            </span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="confInfoBeat.records&&confInfoBeat.records.length"
        :total="confInfoBeat.total"
        :current-page.sync="confInfoBeat.currentPage"
        :page-size.sync="confInfoBeat.pageSize"
        :page-sizes="[5,10,15,20]"
        background
        layout="jumper,prev, pager, next,total,sizes"
        style="text-align: center"
        @size-change="sizeChange"
        @current-change="getConfInfoBeatPage"/>
    </el-card>
  </div>
</template>

<script>
import LineChart from '../survey/LineChart'
import request from '@/utils/request'
const defaultFormThead = [
  { en: 'serverIp', cn: '服务端地址' },
  { en: 'serverStatus', cn: '服务器状态' },
  { en: 'host', cn: 'host名称' },
  { en: 'os', cn: '操作系统' },
  { en: 'cpu', cn: 'CPU' },
  { en: 'memory', cn: '内存' },
  { en: 'disk', cn: '磁盘' }
]
export default {
  name: 'DashboardAdmin',
  components: {
    LineChart
  },
  data() {
    return {
      // 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      pickerOptionsDay: {
        shortcuts: [{
          text: '最近一周',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      confInfoBeat: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      key: 1, // table key
      formThead: defaultFormThead,
      loginLineChartData: {
        title: {
          text: '登录日志'
        },
        xAxis: {
          data: [],
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: []
        },
        series: []
      }, // 登录折线图
      operateLineChartData: {
        title: {
          text: '操作日志'
        },
        xAxis: {
          data: [],
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: []
        },
        series: []
      }, // 操作折线图
      
      operateTimeDayLevel: false, // 操作天粒度标识
      loginTimeDayLevel: false, // 登录天粒度标识
      operateHourTime: new Date(), // 操作小时粒度时间
      operateDayRangeTime: [], // 操作天粒度时间范围
      loginHourTime: new Date(), // 操作小时粒度时间
      loginDayRangeTime: [], // 操作天粒度时间范围
    }
  },
  created() {
    const vm = this
    vm.getConfInfoBeatPage(1)
    vm.getLineChartData('/monitor/getLoginReportWithHour', { reportDay: new Date() }, 'login')
    vm.getLineChartData('/monitor/getOperateReportWithHour', { reportDay: new Date() }, 'operate')
  },
  methods: {
    // 查询服务详细信息
    getConfInfoBeatPage(currentPage) {
      const vm = this
      const params = {
        currentPage: currentPage,
        pageSize: vm.confInfoBeat.pageSize
      }
      request.post('/configure/confInfoBeat/getConfInfoBeatPage', params)
        .then((res) => {
          if (res.data.status === 0) {
            vm.confInfoBeat.records = res.data.result.result
            vm.confInfoBeat.total = res.data.result.totalCount
            vm.confInfoBeat.currentPage = currentPage
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 切换当前页条数
    sizeChange(pageSize) {
      const vm = this
      vm.confInfoBeat.pageSize = pageSize
      vm.getConfInfoBeatPage(1)
    },
    // 获取服务状态（服务器时钟不同步会导致状态监测异常）
    getServerStatus(row) {
      const nowDate = new Date()
      const beatTime = new Date(row.beatTime)
      const diff = (nowDate.getTime() - beatTime.getTime()) / 1000
      if (diff > 6 * row.beatCycle) {
        return 'DEAD'
      } else {
        return 'LIVE'
      }
    },
    // 格式化内存
    getMemoryProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4))
    },
    // 格式化内存title
    getMemoryProgressTitle(memory) {
      memory = JSON.parse(memory)
      return memory.used + '/' + memory.total + '  ' + Math.round(100 * memory.used.substr(0, memory.used.length - 4) / memory.total.substr(0, memory.total.length - 4)) + '%  used'
    },
    // 格式化磁盘
    getDiskProgress(memory) {
      memory = JSON.parse(memory)
      return Math.round(100 * memory.used / memory.total)
    },
    // 格式化磁盘title
    getDiskProgressTitle(memory) {
      memory = JSON.parse(memory)
      return Math.round(memory.used / (1024 * 1024 * 1024)) + 'GiB/' + Math.round(memory.total / (1024 * 1024 * 1024)) + 'GiB  ' + Math.round(100 * memory.used / memory.total) + '%  used'
    },
    getLineChartData(url, chartParams, flag) {
      const vm = this
      request.post(url, chartParams)
        .then((res) => {
          if (res.data.status === 0) {
            if (flag === 'login') {
              vm.loginLineChartData = res.data.result
            } else if (flag === 'operate') {
              vm.operateLineChartData = res.data.result
            }
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    changeOperateTimeLevel(newValue) {
      const vm = this
      const nowTime = new Date()
      const monday = new Date(nowTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      if (newValue) {
        vm.operateDayRangeTime = []
        vm.operateDayRangeTime.push(monday)
        vm.operateDayRangeTime.push(new Date())
        vm.getLineChartData('/monitor/getOperateReportWithDay', { startDay: vm.formatTime(monday), endDay: vm.formatTime(new Date()) }, 'operate')
      } else {
        vm.operateHourTime = new Date()
        vm.getLineChartData('/monitor/getOperateReportWithHour', { reportDay: vm.formatTime(new Date()) }, 'operate')
      }
    },
    searchOperateLine() {
      const vm = this
      if (vm.operateTimeDayLevel) {
        if (vm.operateDayRangeTime === null || vm.operateDayRangeTime.length === 0) {
          vm.operateDayRangeTime = []
          vm.operateDayRangeTime.push(new Date(new Date().getTime() - 30 * 24 * 60 * 60 * 1000))
          vm.operateDayRangeTime.push(new Date())
        }
        vm.getLineChartData('/monitor/getOperateReportWithDay', { startDay: vm.formatTime(vm.operateDayRangeTime[0]), endDay: vm.formatTime(vm.operateDayRangeTime[1]) }, 'operate')
      } else {
        if (vm.operateHourTime === null || vm.operateHourTime === '') {
          vm.operateHourTime = new Date()
        }
        vm.getLineChartData('/monitor/getOperateReportWithHour', { reportDay: vm.formatTime(vm.operateHourTime) }, 'operate')
      }
    },
    formatTime(date) {
      const seperator1 = '-'
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      const currentdate = year + seperator1 + month + seperator1 + strDate
      return currentdate
    },
    changeLoginTimeLevel(newValue) {
      const vm = this
      const nowTime = new Date()
      const monday = new Date(nowTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      if (newValue) {
        vm.loginDayRangeTime = []
        vm.loginDayRangeTime.push(monday)
        vm.loginDayRangeTime.push(nowTime)
        vm.getLineChartData('/monitor/getLoginReportWithDay', { startDay: vm.formatTime(monday), endDay: vm.formatTime(new Date()) }, 'login')
      } else {
        vm.loginHourTime = new Date()
        vm.getLineChartData('/monitor/getLoginReportWithHour', { reportDay: vm.formatTime(new Date()) }, 'login')
      }
    },
    searchLoginLine() {
      const vm = this
      if (vm.loginTimeDayLevel) {
        if (vm.loginDayRangeTime === null || vm.loginDayRangeTime.length === 0) {
          vm.loginDayRangeTime = []
          vm.loginDayRangeTime.push(new Date(new Date().getTime() - 30 * 24 * 60 * 60 * 1000))
          vm.loginDayRangeTime.push(new Date())
        }
        vm.getLineChartData('/monitor/getLoginReportWithDay', { startDay: vm.formatTime(vm.loginDayRangeTime[0]), endDay: vm.formatTime(vm.loginDayRangeTime[1]) }, 'login')
      } else {
        if (vm.loginHourTime === null || vm.loginHourTime === '') {
          vm.loginHourTime = new Date()
        }
        vm.getLineChartData('/monitor/getLoginReportWithHour', { reportDay: vm.formatTime(vm.loginHourTime) }, 'login')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }
  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}
@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}

.panel-group {
  margin-top: 18px;
  .card-panel-col {
    margin-bottom: 32px;
  }
  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    border-color: rgba(0, 0, 0, .05);
    .icon-people {
      color: #40c9c6;
    }
    .icon-message {
      color: #36a3f7;
    }
    .icon-money {
      color: #f4516c;
    }
    .icon-shopping {
      color: #34bfa3
    }
    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }
    .card-panel-icon {
      float: left;
      font-size: 48px;
    }
  }
}
@media (max-width:550px) {
  .card-panel-description {
    display: none;
  }
  .card-panel-icon-wrapper {
    float: none !important;
    width: 100%;
    height: 100%;
    margin: 0 !important;
    .svg-icon {
      display: block;
      margin: 14px auto !important;
      float: none !important;
    }
  }
}
</style>

