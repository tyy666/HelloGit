<template>
  <div v-loading="contentLoading" class="dashboard-editor-container">
    <el-row style="height:70px;background:#fff;padding:16px 16px 0;">
      <div class="block" style="float:left;margin: -5px 0px 7px 49px;">
        <span class="demonstration">时间</span>
        <el-date-picker
          v-model="friendTime"
          :picker-options="pickerOptions"
          type="date"
          placeholder="选择日期时间"
          align="right"/>
      </div>
      <el-button type="primary" style="float:left;margin: -5px 0px 7px 49px;" @click="searchFriendBarChart()">查询</el-button>
      <el-button type="warning" style="float:right;margin: -5px 0px 7px 49px;" @click="showHelp=true">说明帮助</el-button>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">一、不同人数朋友圈数量、占比分布情况</p>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[0]"/>
      </el-col>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[1]"/>
      </el-col>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">二、不同人数朋友圈出借金额、占比分布情况</p>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[2]"/>
      </el-col>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[3]"/>
      </el-col>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">三、不同范围出借金额朋友圈数量、占比分布情况</p>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[4]"/>
      </el-col>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[5]"/>
      </el-col>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">四、不同邀请层次朋友圈数量、占比分布情况</p>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[6]"/>
      </el-col>
      <el-col :span="12">
        <bar-chart :chart-data="friendChartData[7]"/>
      </el-col>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">五、邀请人、被邀请人出借情况</p>
      <el-col :span="12">
        <pie-chart :chart-data="friendChartData[8]"/>
        <p style="font-size: 10px;color: gray;">说明：A代表邀请人（包括原始邀请人和中间邀请人），B代表被邀请人（最终被邀请人）</p>
      </el-col>
    </el-row>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <p class="ptitle">六、朋友圈排名</p>
      <el-col :span="8" >
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈人数TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[0]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="人数"/>
        </el-table>
      </el-col>
      <el-col :span="8">
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈出借人数TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[1]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="出借人数"/>
        </el-table>
      </el-col>
      <el-col :span="8">
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈出借金额TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[2]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="出借金额">
            <template slot-scope="scope">
              {{ Math.round(scope.row.rankItemValue) }}
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <el-col :span="8" >
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈人均出借金额TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[3]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="人均出借金额">
            <template slot-scope="scope">
              {{ Math.round(scope.row.rankItemValue) }}
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <el-col :span="8">
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈邀请层次TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[4]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="邀请层次"/>
        </el-table>
      </el-col>
      <el-col :span="8">
        <p style="font-size:15px;font-weight:700" align = "center">朋友圈资金ROI TOP10</p>
        <el-table ref="multipleTable" :data="friendCycleRank[5]" border style="width: 100%">
          <el-table-column show-overflow-tooltip prop="inviterId" width="265" label="朋友圈编号"/>
          <el-table-column show-overflow-tooltip prop="rankItemValue" width="266" label="资金ROI">
            <template slot-scope="scope">
              {{ Math.round(scope.row.rankItemValue) }}
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-dialog :visible.sync="showHelp" title="指标帮助说明">
      <div>
        <p class="pline">1. 原始邀请人指本身是邀请人，且未被其他人邀请过；</p>
        <p class="pline">2. 中间邀请人指本身是被邀请人，且邀请过其他人；</p>
        <p class="pline">3. 最终被邀请人指本身是被邀请人，且未邀请过其他人；</p>
        <span class="pline">4. 朋友圈指从原始邀请人开始，通过逐层邀请关系到达最终被邀请人，其中所涉及的所有人构成的群体，例如A为原始邀请人，A邀请了 B和C，B邀请了D和E，C邀请了F和G，则A、B、C、D、E、F和G便构成了一个朋友圈；</span>
        <p class="pline">5. 邀请链条：从原始邀请人到最终被邀请人一系列邀请关系称为一条邀请链条，例如A邀请了B，B邀请了C，C邀请了D，则A￫B￫C￫D为一条邀请链条；</p>
        <p class="pline">6. 邀请层次：指一条邀请链条中从原始邀请人到最终被邀请人所涉及的人数，例如A邀请了B，B邀请了C，C邀请了D，则A￫B￫C￫D的邀请层次为4 ；</p>
        <p class="pline">7. 不同人数朋友圈数量占比=不同人数朋友圈个数/朋友圈总个数；</p>
        <p class="pline">8. 不同人数朋友圈出借金额占平台累计出借金额比例=不同人数朋友圈出借金额/截止XXXX年XX月XX日平台累计出借金额；</p>
        <p class="pline">9. 不同范围出借金额朋友圈数量占比=不同范围出借金额朋友圈数量/朋友圈总个数；</p>
        <p class="pline">10. 不同邀请层次朋友圈数量占比=不同邀请层次朋友圈数量/朋友圈总个数；</p>
        <p class="pline">11. 朋友圈人均出借金额=朋友圈出借金额/朋友圈人数；</p>
        <p class="pline">12. 朋友圈编号为原始邀请人的用户ID；</p>
        <p class="pline">13. 朋友圈资金ROI为截止XXXX年XX月XX日24时朋友圈出借金额/朋友圈内所有邀请人获得邀请好友奖励</p>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import barChart from '../eCharts/barChart'
import pieChart from '../eCharts/pieChart'
import request from '@/utils/request'
export default {
  name: 'DashboardAdmin',
  components: {
    barChart,
    pieChart
  },
  data() {
    return {
      contentLoading: false,
      showHelp: false,
      // 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }],
        disabledDate(time) {
          return time.getTime() > Date.now() - (24 * 60 * 60 * 1000)
        }
      },
      friendChartData: [], // 操作折线图
      friendTime: '', // 选择的时间
      friendCycleRank: []// 朋友圈排名
    }
  },
  created() {
    const vm = this
    vm.friendTime = new Date(Date.now() - (24 * 60 * 60 * 1000))
    vm.getFriendChart()
    vm.getFriendRank()
  },
  methods: {
    // 获取朋友圈柱状图和饼图
    getFriendChart() {
      const vm = this
      request.post('/report/loan/friendCycle/adsInviteChannelFriendcycleGather/getFriendChart', { friendTime: vm.formatTime(vm.friendTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.friendChartData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    searchFriendBarChart() {
      const vm = this
      vm.getFriendChart()
      vm.getFriendRank()
    },
    getFriendRank() {
      const vm = this
      request.post('/report/loan/friendCycle/adsInviteChannelFriendcycleRank/getFriendRank', { friendTime: vm.formatTime(vm.friendTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.friendCycleRank = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 格式化时间为字符串
    formatTime(date) {
      const seperator1 = '-'
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      const currentdate = year + seperator1 + month + seperator1 + strDate
      return currentdate
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }
  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}
.pline{
    height: 15px;
    font-size: 13px;
    margin-left: 40px;
}
.ptitle{
    font-weight: bolder;
    font-size: 21px;
}
@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}

.panel-group {
  margin-top: 18px;
  .card-panel-col {
    margin-bottom: 32px;
  }
  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    border-color: rgba(0, 0, 0, .05);
    .icon-people {
      color: #40c9c6;
    }
    .icon-message {
      color: #36a3f7;
    }
    .icon-money {
      color: #f4516c;
    }
    .icon-shopping {
      color: #34bfa3
    }
    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }
    .card-panel-icon {
      float: left;
      font-size: 48px;
    }
  }
}
@media (max-width:550px) {
  .card-panel-description {
    display: none;
  }
  .card-panel-icon-wrapper {
    float: none !important;
    width: 100%;
    height: 100%;
    margin: 0 !important;
    .svg-icon {
      display: block;
      margin: 14px auto !important;
      float: none !important;
    }
  }
}
</style>

