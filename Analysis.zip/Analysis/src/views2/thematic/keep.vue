<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <quarter />
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
// import request from '@/utils/request'
import Quarter from '@/components/Quarter'
export default{
  components: { Quarter },
  props: {

  },
  data() {
    return {

    }
  },
  beforeDestroy() {

  },
  async created() {

  },
  methods: {

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.app-container{
  padding:0;
}
.el-main{
  padding:0;
}
</style>
