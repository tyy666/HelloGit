<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <el-form v-model="lossSearch" class="demo-form-inline" label-width="110px">
            <el-form-item label="查询日期：">
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="lossSearch.date"
                :picker-options="pickerOptions"
                type="date"
                placeholder="查询日期"
                @change="changeTime"/>
              <el-button type="primary" style="margin-left:40px" @click="lossSearchSubmit">查询</el-button>
            </el-form-item>
          </el-form>

          <div v-loading="contentLoading">
            <!-- 一、业绩 -->
            <el-table
              :data="achievement1"
              :border="true"
              style="width: 100%">
              <el-table-column label="一、业绩" header-align="center">
                <el-table-column :formatter="formatComma" prop="number" label="当月目标召回用户（人）" header-align="center" align="right"/>
                <el-table-column
                  :label="'当月截止到'+lossSearch.date+'实际召回用户（人）'"
                  :formatter="formatComma"
                  prop="monthEnd"
                  header-align="center"
                  align="right"/>
                <el-table-column prop="percent" label="月度目标达成率" header-align="center" align="center">
                  <template slot-scope="scope">
                    <span>
                      {{
                        scope.row.monthEnd&&scope.row.number ?
                          Number((scope.row.monthEnd/scope.row.number)*100).toFixed(2)+'%' :'0.00%'
                      }}
                    </span>
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
            <el-table
              :data="achievement2"
              :border="true"
              class="achievement2"
              style="width: 100%">
              <el-table-column :formatter="formatComma" prop="number" label="当月目标召回出借额（元）" header-align="center" align="right"/>
              <el-table-column
                :label="'当月截止到'+lossSearch.date+'实际召回出借额（元）'"
                :formatter="formatComma"
                prop="monthEnd"
                header-align="center"
                align="right"/>
              <el-table-column prop="percent" label="月度目标达成率" header-align="center" align="center">
                <template slot-scope="scope">
                  <span>
                    {{
                      scope.row.monthEnd&&scope.row.number ?
                        Number((scope.row.monthEnd/scope.row.number)*100).toFixed(2)+'%' :'0.00%'
                    }}
                  </span>
                </template>
              </el-table-column>
            </el-table>

            <!-- 二、召回总体情况 -->
            <el-table
              :data="recall_total"
              :border="true"
              style="width: 100%;margin-top:30px">
              <el-table-column label="二、召回总体情况" header-align="center">
                <el-table-column prop="category" label="总表" header-align="center" min-width="150px" align="center" />
                <el-table-column :formatter="formatComma" prop="today" label="当日" header-align="center" align="right" />
                <el-table-column :formatter="formatComma" prop="lastDay" label="上一日" header-align="center" align="right"/>
                <el-table-column prop="todayRatio" label="环比上一日" header-align="center" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.todayRatio&&scope.row.today>=scope.row.lastDay" style="color:#d72c1a">
                      ↑{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else-if="scope.row.todayRatio&&scope.row.today<scope.row.lastDay" style="color:#0214f0">
                      ↓{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column :formatter="formatComma" prop="monthAvg" label="当月日均" header-align="center" align="right"/>
                <el-table-column :formatter="formatComma" prop="lastMonthAvg" label="上月日均" header-align="center" align="right"/>
                <el-table-column prop="monthRatio" label="环比上月日均" header-align="center" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.monthRatio&&scope.row.monthAvg>=scope.row.lastMonthAvg" style="color:#d72c1a">
                      ↑{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else-if="scope.row.monthRatio&&scope.row.monthAvg<scope.row.lastMonthAvg" style="color:#0214f0">
                      ↓{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column
                  :label="'当月截止到'+lossSearch.date+'累计'"
                  :formatter="formatComma"
                  align="right"
                  prop="monthEnd"
                  header-align="center"
                  min-width="100px" />
                <el-table-column :formatter="formatComma" prop="lastMonthEnd" label="上月累计" header-align="center" align="right"/>
              </el-table-column>
            </el-table>

            <!-- 三、召回出借资金构成情况 -->
            <el-table
              :data="recall_funds"
              :border="true"
              :span-method="objectSpanMethod"
              style="width: 100%;margin-top:30px">
              <el-table-column label="三、召回出借资金构成情况" header-align="center">
                <el-table-column prop="dimension" label="维度" header-align="center" min-width="180px" align="center" />
                <el-table-column prop="category" label="类别" header-align="center" min-width="180px" align="center" />
                <el-table-column :formatter="formatComma" prop="today" label="当日" header-align="center" align="right"/>
                <el-table-column :formatter="formatComma" prop="lastDay" label="上一日" header-align="center" align="right"/>
                <el-table-column prop="todayRatio" label="环比上一日" header-align="center" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.todayRatio&&scope.row.today>=scope.row.lastDay" style="color:#d72c1a">
                      ↑{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else-if="scope.row.todayRatio&&scope.row.today<scope.row.lastDay" style="color:#0214f0">
                      ↓{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column :formatter="formatComma" prop="monthAvg" label="当月日均" header-align="center" align="right"/>
                <el-table-column :formatter="formatComma" prop="lastMonthAvg" label="上月日均" header-align="center" align="right"/>
                <el-table-column prop="monthRatio" label="环比上月日均" header-align="center" min-width="100px" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.monthRatio&&scope.row.monthAvg>=scope.row.lastMonthAvg" style="color:#d72c1a">
                      ↑{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else-if="scope.row.monthRatio&&scope.row.monthAvg<scope.row.lastMonthAvg" style="color:#0214f0">
                      ↓{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column
                  :label="'当月截止到'+lossSearch.date+'累计'"
                  :formatter="formatComma"
                  prop="monthEnd"
                  header-align="center"
                  min-width="140px"
                  align="right"/>
                <el-table-column :formatter="formatComma" prop="lastMonthEnd" label="上月累计" header-align="center" align="right"/>
              </el-table-column>
            </el-table>

            <!-- 四、召回用户人数构成情况 -->
            <el-table
              :data="recall_numbers"
              :border="true"
              :span-method="objectSpanMethod"
              style="width: 100%;margin-top:30px">
              <el-table-column label="四、召回用户人数构成情况" header-align="center">
                <el-table-column prop="dimension" label="维度" header-align="center" min-width="180px" align="center"/>
                <el-table-column prop="category" label="类别" header-align="center" min-width="180px" align="center"/>
                <el-table-column :formatter="formatComma" prop="today" label="当日" header-align="center" align="right"/>
                <el-table-column :formatter="formatComma" prop="lastDay" label="上一日" header-align="center" align="right"/>
                <el-table-column prop="todayRatio" label="环比上一日" header-align="center" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.todayRatio&&scope.row.today>=scope.row.lastDay" style="color:#d72c1a">
                      ↑{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else-if="scope.row.todayRatio&&scope.row.today<scope.row.lastDay" style="color:#0214f0">
                      ↓{{ scope.row.todayRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column :formatter="formatComma" prop="monthAvg" label="当月日均" header-align="center" align="right"/>
                <el-table-column :formatter="formatComma" prop="lastMonthAvg" label="上月日均" header-align="center" align="right"/>
                <el-table-column prop="monthRatio" label="环比上月日均" header-align="center" min-width="100px" align="center">
                  <template slot-scope="scope">
                    <span v-if="scope.row.monthRatio&&scope.row.monthAvg>=scope.row.lastMonthAvg" style="color:#d72c1a">
                      ↑{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else-if="scope.row.monthRatio&&scope.row.monthAvg<scope.row.lastMonthAvg" style="color:#0214f0">
                      ↓{{ scope.row.monthRatio }}%
                    </span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column
                  :label="'当月截止到'+lossSearch.date+'累计'"
                  :formatter="formatComma"
                  prop="monthEnd"
                  header-align="center"
                  min-width="140px"
                  align="right"/>
                <el-table-column :formatter="formatComma" prop="lastMonthEnd" label="上月累计" header-align="center" align="right"/>
              </el-table-column>
            </el-table>

            <el-table
              :data="[]"
              :border="true"
              class="t5"
              style="width: 100%;margin-top:30px">
              <el-table-column label="五、每日数据概览" align="center"/>
            </el-table>
            <!-- 折线图 -->
            <div
              :class="className"
              :id="id"
              :style="{height:height,width:width}"/>
          </div>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
import echarts from 'echarts'
import resize from '../../../components/Charts/mixins/resize'
export default{
  name: 'LossUser',
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '500px'
    }
  },
  data() {
    return {
      lossSearch: {
        date: ''
      },
      contentLoading: false,
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now() - (24 * 60 * 60 * 1000)
        }
      },

      // 一、业绩
      achievement1: [
        {
          number: '',
          monthEnd: '',
          percent: ''
        }
      ],
      achievement2: [
        {
          number: '',
          monthEnd: '',
          percent: ''
        }
      ],

      // 二、召回总体情况
      recall_total: [
        {
          category: '流失召回用户（人）'
        },
        {
          category: '出借额（元）'
        },
        {
          category: '出借笔数'
        }
      ],

      // 三、召回出借资金构成情况
      recall_funds: [

      ],

      // 四、召回用户人数构成情况
      recall_numbers: [

      ],

      // 五、每日数据概览
      chart: null
    }
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  async created() {
    const vm = this
    const startDay = vm.getNowFormatDate(new Date())
    const startOne = startDay + ' ' + '00:00:00'
    const e1 = new Date(startOne).getTime() - 3600 * 1000 * 24
    vm.lossSearch.date = vm.getNowFormatDate(e1)

    vm.contentLoading = true

    // 一、业绩    二、召回总体情况
    const res = await request.post(
      '/report/loan/callback/adsFundsCallbackUserDayReport/getCallbackReport',
      { callbackTime: vm.lossSearch.date }
    )
    vm.contentLoading = false
    if (res.data.status === 0) {
      vm.recall_total = res.data.result
      vm.achievement1[0].monthEnd = res.data.result[0].monthEnd
      vm.achievement2[0].monthEnd = res.data.result[1].monthEnd
    }

    // 当月目标召回用户（人），当月目标召回出借额（元）
    const timeArr = vm.lossSearch.date.split('-')
    const month = timeArr[0] + '-' + timeArr[1]
    const res2 = await request.post(
      '/report/loan/callback/adsFundsCallbackGoal/getCallbackGoal',
      { callbackTime: month }
    )
    if (res2.data.status === 0) {
      vm.achievement1[0].number = res2.data.result[1][0].callbackUserCnt
      vm.achievement2[0].number = res2.data.result[1][0].callbackUserAmt
    }

    // 三、召回出借资金构成情况   四、召回用户人数构成情况
    const ret = await request.post(
      '/report/loan/callback/adsFundsCallbackUserDayReportType/getCallbackReportType',
      { callbackTime: vm.lossSearch.date }
    )
    if (ret.data.status === 0) {
      vm.recall_funds = ret.data.result[0]
      vm.recall_numbers = ret.data.result[1]
    }

    // 五、每日数据概览

    vm.chart = echarts.init(document.getElementById(this.id))
    vm.chart.setOption({
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          lineStyle: {
            color: '#ccc'
          }
        }
      },
      legend: {
        top: 20,
        icon: 'rect',
        itemWidth: 14,
        itemHeight: 5,
        itemGap: 13,
        data: ['截至' + vm.lossSearch.date + '出借金额', '截至' + vm.lossSearch.date + '出借人数'],
        right: '4%',
        textStyle: {
          fontSize: 12,
          color: '#333'
        }
      },
      grid: {
        top: 50,
        left: '5%',
        right: '6%',
        bottom: '2%',
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        name: '时间(天)',
        boundaryGap: true,
        axisLine: {
          lineStyle: {
            color: '#666666'
          }
        },
        data: []
      }],
      yAxis: [
        {
          type: 'value',
          name: '出借金额(元)',
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#666666'
            }
          },
          axisLabel: {
            margin: 10,
            textStyle: {
              fontSize: 14
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: 'rgb(137,189,27,0.3)'
            }
          }
        },
        {
          type: 'value',
          name: '出借人数(人)',
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#666666'
            }
          },
          axisLabel: {
            margin: 10,
            textStyle: {
              fontSize: 14
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: 'rgba(0, 136, 212, 0.3)'
            }
          }
        }
      ],
      series: [
        {
          name: '出借金额(元)',
          type: 'bar',
          smooth: true,
          symbol: 'circle',
          showSymbol: false,
          barWidth: 20,
          itemStyle: {
            normal: {
              color: 'rgb(137,189,27)'
            }
          },
          data: []
        },
        {
          name: '出借人数(人)',
          yAxisIndex: 1,
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 1
            }
          },
          areaStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(0, 136, 212, 0.3)'
              }, {
                offset: 0.8,
                color: 'rgba(0, 136, 212, 0)'
              }], false),
              shadowColor: 'rgba(0, 0, 0, 0.1)',
              shadowBlur: 10
            }
          },
          itemStyle: {
            normal: {
              color: 'rgb(0,136,212)',
              borderColor: 'rgba(0,136,212,0.2)',
              borderWidth: 12

            }
          },
          data: []
        }
      ]
    })

    const response = await request.post(
      '/report/loan/callback/adsFundsCallbackUserDayReport/getCallbackReportLine',
      { callbackTime: vm.lossSearch.date }
    )
    if (response.data.status === 0 && response.data.result) {
      const days = []
      const nowT = vm.lossSearch.date + ' ' + '00:00:00'
      for (let i = 0, len = response.data.result.length; i < len; i++) {
        if (len - i - 1 >= 0) {
          const e1 = new Date(nowT).getTime() - 3600 * 1000 * 24 * (len - i - 1)
          const n1 = vm.getNowFormatDate(e1)
          days.push(n1)
        }
      }

      const callbackUserAmt_arr = response.data.result.map(item => item.callbackUserAmt)
      const callbackUserCnt_arr = response.data.result.map(item => item.callbackUserCnt)

      vm.chart.setOption({
        xAxis: [{
          data: days
        }],
        series: [
          { data: callbackUserAmt_arr },
          { data: callbackUserCnt_arr }
        ]
      })
    }
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    changeTime() {
      const date = this.getNowFormatDate(this.lossSearch.date)
      this.lossSearch.date = date
    },
    async lossSearchSubmit() {
      const vm = this
      vm.contentLoading = true

      // 一、业绩    二、召回总体情况
      const res = await request.post(
        '/report/loan/callback/adsFundsCallbackUserDayReport/getCallbackReport',
        { callbackTime: vm.lossSearch.date }
      )
      vm.contentLoading = false
      if (res.data.status === 0) {
        vm.recall_total = res.data.result
        vm.achievement1[0].monthEnd = res.data.result[0].monthEnd
        vm.achievement2[0].monthEnd = res.data.result[1].monthEnd
      }
      // 当月目标召回用户（人），当月目标召回出借额（元）
      const timeArr = vm.lossSearch.date.split('-')
      const month = timeArr[0] + '-' + timeArr[1]
      const res2 = await request.post(
        '/report/loan/callback/adsFundsCallbackGoal/getCallbackGoal',
        { callbackTime: month }
      )
      if (res2.data.status === 0) {
        vm.achievement1[0].number = res2.data.result[1][0].callbackUserCnt
        vm.achievement2[0].number = res2.data.result[1][0].callbackUserAmt
      }

      // 三、召回出借资金构成情况   四、召回用户人数构成情况
      const ret = await request.post(
        '/report/loan/callback/adsFundsCallbackUserDayReportType/getCallbackReportType',
        { callbackTime: vm.lossSearch.date }
      )
      if (ret.data.status === 0) {
        vm.recall_funds = ret.data.result[0]
        vm.recall_numbers = ret.data.result[1]
      }

      const response = await request.post(
        '/report/loan/callback/adsFundsCallbackUserDayReport/getCallbackReportLine',
        { callbackTime: vm.lossSearch.date }
      )
      if (response.data.status === 0 && response.data.result) {
        const days = []
        const nowT = vm.lossSearch.date + ' ' + '00:00:00'
        for (let i = 0, len = response.data.result.length; i < len; i++) {
          if (len - i - 1 >= 0) {
            const e1 = new Date(nowT).getTime() - 3600 * 1000 * 24 * (len - i - 1)
            const n1 = vm.getNowFormatDate(e1)
            days.push(n1)
          }
        }

        const callbackUserAmt_arr = response.data.result.map(item => item.callbackUserAmt)
        const callbackUserCnt_arr = response.data.result.map(item => item.callbackUserCnt)

        vm.chart.setOption({
          xAxis: [{
            data: days
          }],
          series: [
            { data: callbackUserAmt_arr },
            { data: callbackUserCnt_arr }
          ]
        })
      }
    },
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0) {
          return {
            rowspan: 2,
            colspan: 1
          }
        } else if (rowIndex === 2) {
          return {
            rowspan: 6,
            colspan: 1
          }
        } else if (rowIndex === 8) {
          return {
            rowspan: 5,
            colspan: 1
          }
        } else if (rowIndex === 13) {
          return {
            rowspan: 6,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    formatNumber(s, n) {
      return (s + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
    },
    formatComma(row, column, cellValue, index) {
      const vm = this
      if (cellValue) {
        return vm.formatNumber(cellValue)
      } else {
        return cellValue
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.app-container{
  padding:0;
}
.el-main{
  padding:0;
}
.achievement2{
  border-top:none;
}
/deep/ .t5 .el-table__body-wrapper{
  display: none;
}
/deep/ .el-table th.is-leaf{
  background-color: #f5f7fa;
}
</style>
