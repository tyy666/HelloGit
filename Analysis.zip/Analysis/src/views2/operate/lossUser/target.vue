<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <el-form v-model="targetSearch" class="demo-form-inline" label-width="110px">
            <el-form-item label="查询月份：">
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="targetSearch.month"
                type="month"
                placeholder="查询月份"
                @change="changeTime"/>
              <el-button type="primary" style="margin-left:40px" @click="targetSearchSubmit">查询</el-button>
              <el-button :disabled="saveBool" type="success" style="margin-left:20px" @click="targetSave">保存</el-button>
            </el-form-item>
          </el-form>
          <div v-loading="contentLoading">
            <el-table
              :data="target1"
              :border="true"
              style="width: 100%">
              <el-table-column label="一、年度目标" header-align="center">
                <el-table-column prop="callbackDate" label="年" header-align="center" align="center" />
                <el-table-column
                  label="目标召回用户(人)"
                  prop="callbackUserCnt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number v-model="scope.row.callbackUserCnt" placeholder="请输入" clearable @keyup.native="changeNum1" />
                  </template>
                </el-table-column>
                <el-table-column
                  label="目标召回出借额(元)"
                  prop="callbackUserAmt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number2 v-model="scope.row.callbackUserAmt" placeholder="请输入" clearable @keyup.native="changeNum2" />
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
            <el-table
              :data="target2"
              :border="true"
              style="width: 100%;margin-top:30px">
              <el-table-column label="二、月度目标" header-align="center">
                <el-table-column prop="callbackDate" label="年月" header-align="center" align="center" />
                <el-table-column
                  label="目标召回用户(人)"
                  prop="callbackUserCnt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number v-model="scope.row.callbackUserCnt" placeholder="请输入" clearable @keyup.native="changeNum3" />
                  </template>
                </el-table-column>
                <el-table-column
                  label="目标召回出借额(元)"
                  prop="callbackUserAmt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number2 v-model="scope.row.callbackUserAmt" placeholder="请输入" clearable @keyup.native="changeNum4" />
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
            <el-table
              :data="target3"
              :border="true"
              style="width: 100%;margin-top:30px">
              <el-table-column label="三、日度目标" header-align="center">
                <el-table-column prop="callbackDate" label="年月日" header-align="center" align="center" />
                <el-table-column
                  label="目标召回用户(人)"
                  prop="callbackUserCnt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number v-model="scope.row.callbackUserCnt" placeholder="请输入" clearable @keyup.native="changeNum5" />
                  </template>
                </el-table-column>
                <el-table-column
                  label="目标召回出借额(元)"
                  prop="callbackUserAmt"
                  header-align="center"
                  align="right">
                  <template slot-scope="scope">
                    <el-input v-enter-number2 v-model="scope.row.callbackUserAmt" placeholder="请输入" clearable @keyup.native="changeNum6" />
                  </template>
                </el-table-column>
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
export default{
  data() {
    return {
      contentLoading: false,
      targetSearch: {
        month: ''
      },
      target1: [], // 年度目标
      target2: [], // 月度目标
      target3: [], // 日度目标
      saveBool1: true,
      saveBool2: true,
      saveBool3: true,
      saveBool4: true,
      saveBool5: true,
      saveBool6: true,
      saveBool: false
    }
  },
  beforeDestroy() {
  },
  async created() {
    const vm = this
    const date = new Date()
    const year = date.getFullYear()
    let month = date.getMonth() + 1
    if (month >= 1 && month <= 9) { month = '0' + month }
    vm.targetSearch.month = year + '-' + month

    vm.contentLoading = true
    const res = await request.post(
      '/report/loan/callback/adsFundsCallbackGoal/getCallbackGoal',
      { callbackTime: vm.targetSearch.month }
    )
    vm.contentLoading = false
    if (res.data.status === 0) {
      vm.target1 = res.data.result[0]
      vm.target2 = res.data.result[1]
      vm.target3 = res.data.result[2]
    }
  },
  methods: {
    changeTime() {
      const date = this.targetSearch.month
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month >= 1 && month <= 9) { month = '0' + month }
      this.targetSearch.month = year + '-' + month
    },
    async targetSearchSubmit() {
      const vm = this
      vm.contentLoading = true
      const res = await request.post(
        '/report/loan/callback/adsFundsCallbackGoal/getCallbackGoal',
        { callbackTime: vm.targetSearch.month }
      )
      vm.contentLoading = false
      if (res.data.status === 0) {
        vm.target1 = res.data.result[0]
        vm.target2 = res.data.result[1]
        vm.target3 = res.data.result[2]
      }
    },
    async targetSave() {
      const vm = this
      vm.contentLoading = true
      const callbackGoal = JSON.stringify(vm.target1.concat(vm.target2).concat(vm.target3))
      const res = await request.post(
        '/report/loan/callback/adsFundsCallbackGoal/modifyCallbackGoal',
        { callbackGoal: callbackGoal }
      )
      vm.contentLoading = false
      if (res.data.status === 0) {
        vm.$message({
          showClose: true,
          message: '保存成功！',
          type: 'success'
        })
      }
    },
    changeNum1(event) {
      const vm = this
      const bool = /^[1-9]\d*|0$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负整数！',
          type: 'warning'
        })
        vm.saveBool1 = false
      } else {
        vm.saveBool1 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    },
    changeNum2() {
      const vm = this
      const bool = /^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负数！',
          type: 'warning'
        })
        vm.saveBool2 = false
      } else {
        vm.saveBool2 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    },
    changeNum3(event) {
      const vm = this
      const bool = /^[1-9]\d*|0$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负整数！',
          type: 'warning'
        })
        vm.saveBool3 = false
      } else {
        vm.saveBool3 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    },
    changeNum4() {
      const vm = this
      const bool = /^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负数！',
          type: 'warning'
        })
        vm.saveBool4 = false
      } else {
        vm.saveBool4 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    },
    changeNum5(event) {
      const vm = this
      const bool = /^[1-9]\d*|0$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负整数！',
          type: 'warning'
        })
        vm.saveBool5 = false
      } else {
        vm.saveBool5 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    },
    changeNum6() {
      const vm = this
      const bool = /^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/.test(event.target.value)
      if (!bool) {
        vm.$message({
          showClose: true,
          message: '请输入非负数！',
          type: 'warning'
        })
        vm.saveBool6 = false
      } else {
        vm.saveBool6 = true
      }
      vm.saveBool = !(vm.saveBool1 && vm.saveBool2 && vm.saveBool3 && vm.saveBool4 && vm.saveBool5 && vm.saveBool6)
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.app-container{
  padding:0;
}
.el-main{
  padding:0;
}
</style>
