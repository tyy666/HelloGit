<template>
  <div class="app-container" style="padding: 0;">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <el-card class="box-card">
            <el-row style="background:#fff;padding:16px 16px 0;">
              <div class="block" style="float:left;margin: -5px 0px 7px 49px;width:300px">
                <span>运营时间：</span>
                <el-date-picker v-model="operateTime" :picker-options="pickerOptions" type="date" placeholder="选择日期时间" align="right"/>
              </div>
              <el-button type="primary" style="float:left;margin: -5px 0px 7px 49px;" @click="getAllOperateData()">查询</el-button>
              <el-button type="primary" style="float:left;margin: -5px 0px 7px 15px;" @click="exportAllOperateData()">导出</el-button>
            </el-row>
          </el-card>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">一、平台整体情况</p>
            <el-table ref="multipleTable" :data="summaryData" border style="width: 100%">
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="totalRegisterNum" width="168px" label="总注册用户" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="totalOpenNum" width="170px" label="总开户用户" align="right" header-align="center"/>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="totalInvestNum" width="170px" label="总投资用户" align="right" header-align="center"/>
              <el-table-column show-overflow-tooltip prop="totalInvestAmt" width="170px" label="总成交额" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.totalInvestAmt) }}</span></template></el-table-column>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="dayReceivableNum" width="170px" label="待收用户" align="right" header-align="center"/>
              <el-table-column show-overflow-tooltip prop="dayRemainPrincipal" width="170px" label="待还本金" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayRemainPrincipal) }}</span></template></el-table-column>
              <el-table-column :formatter="formatComma" show-overflow-tooltip prop="dayUnforwardNum" width="170px" label="待转投用户" align="right" header-align="center"/>
              <el-table-column show-overflow-tooltip prop="dayUnforwardPrincipal" width="170px" label="待转投本金" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayUnforwardPrincipal) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayAccountAvailableAmt" width="170px" label="站岗资金" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayAccountAvailableAmt) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">二、运营数据回顾</p>
            <el-table ref="multipleTable" :data="overviewData" :span-method="twoTableRowMerge" border style="width: 100%">
              <el-table-column show-overflow-tooltip prop="classification" width="155px" label="分类" align="center"/>
              <el-table-column show-overflow-tooltip prop="category" width="165px" label="类别" align="center"/>
              <el-table-column show-overflow-tooltip prop="dayData" width="150px" label="当日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastDayData" width="155px" label="上一日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastDayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayDataEarlier" width="153px" label="环比上一日" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.dayData == null || scope.row.lastDayData == null || scope.row.lastDayData == ''">-</span>
                  <span v-else-if="scope.row.dayData >= scope.row.lastDayData" style="color:red">↑{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.dayData < scope.row.lastDayData" style="color:blue">↓{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthData" width="150px" label="当月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgLastMonthData" width="150px" label="上月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgLastMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthDataEarlier" width="150px" label="环比上月日均" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.avgMonthData == null || scope.row.avgLastMonthData == null || scope.row.avgLastMonthData == ''">-</span>
                  <span v-else-if="scope.row.avgMonthData >= scope.row.avgLastMonthData" style="color:red">↑{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.avgMonthData < scope.row.avgLastMonthData" style="color:blue">↓{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="monthData" width="150px" label="当月截至目前累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.monthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastMonthData" width="150px" label="上月累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastMonthData,scope.row.category) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">三、成交分布</p>
            <el-table ref="multipleTable" :data="distributeData" :span-method="threeTableRowMerge" border style="width: 100%">
              <el-table-column show-overflow-tooltip prop="classification" width="155px" label="分类" align="center"/>
              <el-table-column show-overflow-tooltip prop="category" width="163px" label="成交金额区间" align="center"/>
              <el-table-column show-overflow-tooltip prop="dayData" width="155px" label="当日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastDayData" width="155px" label="上一日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastDayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayDataEarlier" width="150px" label="环比上一日" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.dayData == null || scope.row.lastDayData == null || scope.row.lastDayData == ''">-</span>
                  <span v-else-if="scope.row.dayData >= scope.row.lastDayData" style="color:red">↑{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.dayData < scope.row.lastDayData" style="color:blue">↓{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthData" width="150px" label="当月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgLastMonthData" width="150px" label="上月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgLastMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthDataEarlier" width="150px" label="环比上月日均" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.avgMonthData == null || scope.row.avgLastMonthData == null || scope.row.avgLastMonthData == ''">-</span>
                  <span v-else-if="scope.row.avgMonthData >= scope.row.avgLastMonthData" style="color:red">↑{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.avgMonthData < scope.row.avgLastMonthData" style="color:blue">↓{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="monthData" width="150px" label="当月截至目前累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.monthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastMonthData" width="150px" label="上月累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastMonthData,scope.row.category) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">四、产品期限分布</p>
            <el-table ref="multipleTable" :data="periodData" :span-method="fourTableRowMerge" border style="width: 100%">
              <el-table-column show-overflow-tooltip prop="classification" width="155px" label="分类" align="center"/>
              <el-table-column show-overflow-tooltip prop="category" width="163px" label="产品期限分布" align="center"/>
              <el-table-column show-overflow-tooltip prop="dayData" width="155px" label="当日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastDayData" width="155px" label="上一日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastDayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayDataEarlier" width="150px" label="环比上一日" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.dayData == null || scope.row.lastDayData == null || scope.row.lastDayData == ''">-</span>
                  <span v-else-if="scope.row.dayData >= scope.row.lastDayData" style="color:red">↑{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.dayData < scope.row.lastDayData" style="color:blue">↓{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthData" width="150px" label="当月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgLastMonthData" width="150px" label="上月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgLastMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthDataEarlier" width="150px" label="环比上月日均" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.avgMonthData == null || scope.row.avgLastMonthData == null || scope.row.avgLastMonthData == ''">-</span>
                  <span v-else-if="scope.row.avgMonthData >= scope.row.avgLastMonthData" style="color:red">↑{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.avgMonthData < scope.row.avgLastMonthData" style="color:blue">↓{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="monthData" width="150px" label="当月截至目前累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.monthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastMonthData" width="150px" label="上月累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastMonthData,scope.row.category) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">五、出借构成情况</p>
            <el-table ref="multipleTable" :data="constituteData" :span-method="fiveTableRowMerge" border style="width: 100%">
              <el-table-column show-overflow-tooltip prop="classification" width="155px" label="分类" align="center"/>
              <el-table-column show-overflow-tooltip prop="category" width="163px" label="类别" align="center"/>
              <el-table-column show-overflow-tooltip prop="dayData" width="155px" label="当日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastDayData" width="155px" label="上一日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastDayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayDataEarlier" width="150px" label="环比上一日" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.dayData == null || scope.row.lastDayData == null || scope.row.lastDayData == ''">-</span>
                  <span v-else-if="scope.row.dayData >= scope.row.lastDayData" style="color:red">↑{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.dayData < scope.row.lastDayData" style="color:blue">↓{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthData" width="150px" label="当月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgLastMonthData" width="150px" label="上月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgLastMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthDataEarlier" width="150px" label="环比上月日均" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.avgMonthData == null || scope.row.avgLastMonthData == null || scope.row.avgLastMonthData == ''">-</span>
                  <span v-else-if="scope.row.avgMonthData >= scope.row.avgLastMonthData" style="color:red">↑{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.avgMonthData < scope.row.avgLastMonthData" style="color:blue">↓{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="monthData" width="150px" label="当月截至目前累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.monthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastMonthData" width="150px" label="上月累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastMonthData,scope.row.category) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">六、债权使用情况</p>
            <el-table ref="multipleTable" :data="debtData" :span-method="sixTableRowMerge" border style="width: 100%">
              <el-table-column show-overflow-tooltip prop="classification" width="155px" label="分类" align="center"/>
              <el-table-column show-overflow-tooltip prop="category" width="163px" label="类别" align="center"/>
              <el-table-column show-overflow-tooltip prop="dayData" width="155px" label="当日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.dayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastDayData" width="155px" label="上一日" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastDayData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="dayDataEarlier" width="150px" label="环比上一日" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.dayData == null || scope.row.lastDayData == null || scope.row.lastDayData == ''">-</span>
                  <span v-else-if="scope.row.dayData >= scope.row.lastDayData" style="color:red">↑{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.dayData < scope.row.lastDayData" style="color:blue">↓{{ formateToFix(scope.row.dayDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthData" width="150px" label="当月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgLastMonthData" width="150px" label="上月日均" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.avgLastMonthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="avgMonthDataEarlier" width="150px" label="环比上月日均" align="center">
                <template slot-scope="scope">
                  <span v-if="scope.row.avgMonthData == null || scope.row.avgLastMonthData == null || scope.row.avgLastMonthData == ''">-</span>
                  <span v-else-if="scope.row.avgMonthData >= scope.row.avgLastMonthData" style="color:red">↑{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                  <span v-else-if="scope.row.avgMonthData < scope.row.avgLastMonthData" style="color:blue">↓{{ formateToFix(scope.row.avgMonthDataEarlier,scope.row.category,100) }}%</span>
                </template>
              </el-table-column>
              <el-table-column show-overflow-tooltip prop="monthData" width="150px" label="当月截至目前累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.monthData,scope.row.category) }}</span></template></el-table-column>
              <el-table-column show-overflow-tooltip prop="lastMonthData" width="150px" label="上月累计" align="right" header-align="center"><template slot-scope="scope"><span>{{ formateToFix(scope.row.lastMonthData,scope.row.category) }}</span></template></el-table-column>
            </el-table>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">七、用户情况</p>
            <el-col :span="12">
              <chart :chart-data="userNew"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="userEveryInvest"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <el-col :span="12">
              <chart :chart-data="userRegisteChange"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="userRegisteChangeRate"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <el-col :span="12">
              <chart :chart-data="userReceivableUserChangeNum"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="userLoginUserNum"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">八、成交情况</p>
            <chart :chart-data="investData"/>
          </el-row>
          <el-row style="background:#fff;padding:16px">
            <el-col :span="12">
              <chart :chart-data="investForward"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="investRenew"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px;">
            <el-col :span="12">
              <chart :chart-data="investQuit"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="investCancel"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px ;">
            <el-col :span="12">
              <chart :chart-data="investRate"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="investCoupon"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px ;">
            <chart :chart-data="investNewOld"/>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">九、财务情况</p>
            <chart :chart-data="financeFunds"/>
          </el-row>
          <el-row style="background:#fff;padding:16px;">
            <el-col :span="12">
              <chart :chart-data="financeRecharge"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="financeWithdraw"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <chart :chart-data="financeIncome"/>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">十、回款待兑付情况</p>
            <chart :chart-data="financeContinuationRate"/>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <chart :chart-data="income"/>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <p class="ptitle">十一、流量情况</p>
            <el-col :span="12">
              <chart :chart-data="pCH5PV"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="pCH5UV"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <el-col :span="12">
              <chart :chart-data="androidUV"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="iOSUV"/>
            </el-col>
          </el-row>
          <el-row style="background:#fff;padding:16px 16px 0;">
            <el-col :span="12">
              <chart :chart-data="pCH5OldNew"/>
            </el-col>
            <el-col :span="12">
              <chart :chart-data="appOldNew"/>
            </el-col>
          </el-row>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import request from '@/utils/request'
import chart from '../operateView/chart'
import urlKey from '../../../assets/scripts/UrlKey'
import fileDownload from 'js-file-download'
import { getToken } from '@/utils/auth'
import axios from 'axios'
export default{
  components: {
    chart,
    urlKey
  },
  data() {
    return {
      operateTime: '', // 运营选择的时间
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now() - (24 * 60 * 60 * 1000)
        }
      },
      summaryData: [], // 平台整体情况
      overviewData: [], // 运营数据回顾
      distributeData: [], // 成交分布
      periodData: [], // 产品期限分布
      constituteData: [], // 出借构成情况
      debtData: [], // 债权使用情况
      userNew: {
        title: {
          text: '新增用户趋势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        color: ['#2EC7C9', '#ED7544'],
        legend: {
          top: true,
          data: ['新增注册用户', '新增投标用户']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          type: 'bar',
          name: '新增注册用户',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        }, {
          type: 'line',
          name: '新增投标用户',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        }],
        grid: {
          containLabel: true
        }
      }, // 新增用户趋势图
      userEveryInvest: {
        title: {
          text: '各渠道注册用户分布情况'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          left: '30%',
          data: ['自然来源用户', '营销用户', '机构用户', '被邀请用户']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          type: 'bar',
          name: '自然来源用户',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '营销用户',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '机构用户',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '被邀请用户',
          stack: '总量',
          data: []
        }],
        grid: {
          containLabel: true
        }
      }, // 各渠道注册用户分布
      userRegisteChange: {
        title: {
          text: '注册用户转化趋势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['开户用户', '充值用户', '投资用户']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          type: 'line',
          name: '开户用户',
          data: []
        }, {
          type: 'line',
          name: '充值用户',
          data: []
        }, {
          type: 'line',
          name: '投资用户',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      userRegisteChangeRate: {
        title: {
          text: '注册用户整体转化率'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['开户转化率', '充值转化率', '投资转化率']
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: function(value, index) {
              return 100 * value + '%'
            }
          }
        },
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            // x轴名称
            var name = params[0].name
            // 图表title名称
            var seriesName = params[0].seriesName
            // 值
            var value = params[0].value
            return name + '<br />' +
             seriesName + ':' + (100 * value).toFixed(2) + '%' + '<br />' +
             params[1].seriesName + ':' + (100 * params[1].value).toFixed(2) + '%' + '<br />' +
             params[2].seriesName + ':' + (100 * params[2].value).toFixed(2) + '%'
          }
        },
        series: [{
          type: 'line',
          name: '开户转化率',
          data: []
        }, {
          type: 'line',
          name: '充值转化率',
          data: []
        }, {
          type: 'line',
          name: '投资转化率',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      userReceivableUserChangeNum: {
        title: {
          text: '待收用户增减变化趋势图（相对上一日）'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['待收用户']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          type: 'bar',
          name: '待收用户',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      userLoginUserNum: {
        title: {
          text: '登录用户走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['登录用户']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          type: 'bar',
          name: '登录用户',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investData: {
        title: {
          text: '每日成交数据走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['投资金额(万元)', '投资人']
        },
        yAxis: [{
          type: 'value',
          name: '投资金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '投资人',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '投资金额(万元)',
          yAxisIndex: 0,
          data: [],
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          }
        }, {
          type: 'line',
          name: '投资人',
          yAxisIndex: 1,
          data: [],
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          }
        }],
        grid: {
          containLabel: true
        }
      },
      investForward: {
        title: {
          text: '每日转投数据走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['转投金额(万元)', '转投人数', '转投笔数']
        },
        yAxis: [{
          type: 'value',
          name: '转投金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '转投人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '转投金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '转投人数',
          yAxisIndex: 1,
          data: []
        }, {
          type: 'line',
          name: '转投笔数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investRenew: {
        title: {
          text: '每日续期成功数据走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['续期成功金额(万元)', '续期成功人数']
        },
        yAxis: [{
          type: 'value',
          name: '续期成功金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '续期成功人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '续期成功金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '续期成功人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investQuit: {
        title: {
          text: '每日申请正常退出走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['申请退出金额(万元)', '申请退出人数']
        },
        yAxis: [{
          type: 'value',
          name: '申请退出金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '申请退出人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '申请退出金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '申请退出人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investCancel: {
        title: {
          text: '每日撤销退出走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['撤销金额(万元)', '撤销人数']
        },
        yAxis: [{
          type: 'value',
          name: '撤销金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '撤销人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '撤销金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '撤销人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investRate: {
        title: {
          text: '各渠道来源客户贡献金额占比走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['其他', '机构渠道', '营销渠道', '品牌渠道', '邀请渠道', '自然渠道'],
          left: '40%'
        },
        yAxis: {
          type: 'value',
          max: 1,
          axisLabel: {
            formatter: function(value, index) {
              return 100 * value + '%'
            }
          }
        },
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            // x轴名称
            var name = params[0].name
            // 图表title名称
            var seriesName = params[0].seriesName
            // 值
            var value = params[0].value
            return name + '<br />' +
             seriesName + ':' + (100 * value).toFixed(2) + '%' + '<br />' +
             params[1].seriesName + ':' + (100 * params[1].value).toFixed(2) + '%' + '<br />' +
             params[2].seriesName + ':' + (100 * params[2].value).toFixed(2) + '%' + '<br />' +
             params[3].seriesName + ':' + (100 * params[3].value).toFixed(2) + '%' + '<br />' +
             params[4].seriesName + ':' + (100 * params[4].value).toFixed(2) + '%' + '<br />' +
             params[5].seriesName + ':' + (100 * params[5].value).toFixed(2) + '%'
          }
        },
        series: [{
          type: 'bar',
          name: '其他',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '机构渠道',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '营销渠道',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '品牌渠道',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '邀请渠道',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '自然渠道',
          stack: '总量',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investCoupon: {
        title: {
          text: '券使用占比走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['成交金额', '券使用金额']
        },
        yAxis: [{
          type: 'value',
          name: '金额(万元)',
          min: 0,
          position: 'left'
        }],
        series: [{
          type: 'bar',
          name: '成交金额',
          stack: '总量',
          data: []
        }, {
          type: 'bar',
          name: '券使用金额',
          stack: '总量',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      investNewOld: {
        title: {
          text: '每日新老客出借走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['新客投资额', '老客投资额', '新客人数', '老客人数']
        },
        yAxis: [{
          type: 'value',
          name: '投资额(万元)',
          min: 0,
          position: 'left'
        }, {
          type: 'value',
          name: '人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '新客投资额',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'bar',
          name: '老客投资额',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '新客人数',
          yAxisIndex: 1,
          data: []
        }, {
          type: 'line',
          name: '老客人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      financeFunds: {
        title: {
          text: '每日资金净流入趋势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['每日资金净流入(万元)']
        },
        yAxis: [{
          type: 'value',
          name: '每日资金净流入(万元)',
          position: 'left'
        }],
        series: [{
          type: 'bar',
          name: '每日资金净流入(万元)',
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      financeRecharge: {
        title: {
          text: '充值情况走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['充值金额(万元)', '充值人数']
        },
        yAxis: [{
          type: 'value',
          name: '充值金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '充值人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '充值金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '充值人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      financeWithdraw: {
        title: {
          text: '提现情况走势图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['提现金额(万元)', '提现人数']
        },
        yAxis: [{
          type: 'value',
          name: '提现金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '提现人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '提现金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '提现人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      financeIncome: {
        title: {
          text: '回款与提现数据对比图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['回款本息金额(万元)', '提现金额(万元)', '回款本息人数', '提现人数']
        },
        yAxis: [{
          type: 'value',
          name: '金额(万元)',
          min: 0,
          position: 'left'
        },
        {
          type: 'value',
          name: '人数',
          min: 0,
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '回款本息金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'bar',
          name: '提现金额(万元)',
          yAxisIndex: 0,
          data: []
        }, {
          type: 'line',
          name: '回款本息人数',
          yAxisIndex: 1,
          data: []
        }, {
          type: 'line',
          name: '提现人数',
          yAxisIndex: 1,
          data: []
        }],
        grid: {
          containLabel: true
        }
      },
      financeContinuationRate: {
        title: {
          text: '每日回款续投人数/金额占比'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['回款续投金额占比', '回款续投人数占比'],
          left: '40%'
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: function(value, index) {
              return 100 * value + '%'
            }
          }
        },
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            // x轴名称
            var name = params[0].name
            // 图表title名称
            var seriesName = params[0].seriesName
            // 值
            var value = params[0].value
            return name + '<br />' +
             seriesName + ':' + (100 * value).toFixed(2) + '%' + '<br />' +
             params[1].seriesName + ':' + (100 * params[1].value).toFixed(2) + '%' + '<br />'
          }
        },
        series: [{
          type: 'line',
          name: '回款续投金额占比',
          data: [],
          label: {
            show: true,
            position: 'top',
            formatter: function(value, index) {
              return (100 * value.data).toFixed(2) + '%'
            }
          }
        }, {
          type: 'line',
          name: '回款续投人数占比',
          data: [],
          label: {
            show: true,
            position: 'top',
            formatter: function(value, index) {
              return (100 * value.data).toFixed(2) + '%'
            }
          }
        }],
        grid: {
          containLabel: true
        }
      },
      income: {
        title: {
          text: '本月待兑付走势图（老产品到期退出+智选产品退出数据）'
        },
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            // x轴名称
            var name = params[0].name
            // 图表title名称
            var seriesName = params[0].seriesName
            // 值
            var value = params[0].data.value
            var operateTime = params[0].data.operateTime
            return name + '<br />' +
             (new Date(name) < new Date(operateTime) ? ('已兑付金额') : seriesName) + ':' + value + '<br />' +
             (new Date(name) < new Date(operateTime) ? ('已兑付用户') : params[1].seriesName) + ':' + params[1].value + '<br />'
          }
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['待兑付金额', '待兑付用户'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          name: '待兑付金额(万元)',
          position: 'left'
        }, {
          type: 'value',
          name: '用户数',
          position: 'right'
        }],
        series: [{
          type: 'bar',
          name: '待兑付金额',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: '待兑付用户',
          data: [],
          yAxisIndex: '1'
        }],
        grid: {
          containLabel: true
        }
      },
      pCH5PV: {
        title: {
          text: '（PC+H5）PV与访问次数对比图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['PV', '访问次数'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: 'PV',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: '访问次数',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      },
      pCH5UV: {
        title: {
          text: '（PC+H5）访问次数与UV对比图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['UV', '访问次数'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: 'UV',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: '访问次数',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      },
      pCH5OldNew: {
        title: {
          text: '（PC+H5）新老访客对比'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['老访客', '新访客'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: '老访客',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: '新访客',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      },
      androidUV: {
        title: {
          text: 'Android启动次数与UV对比图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['启动次数', 'UV'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: '启动次数',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: 'UV',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      },
      iOSUV: {
        title: {
          text: 'IOS启动次数与UV对比图'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['启动次数', 'UV'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: '启动次数',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: 'UV',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      },
      appOldNew: {
        title: {
          text: 'APP新老访客对比'
        },
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['老访客', '新访客'],
          left: '40%'
        },
        yAxis: [{
          type: 'value',
          position: 'left'
        }],
        series: [{
          type: 'line',
          name: '老访客',
          data: [],
          yAxisIndex: '0'
        }, {
          type: 'line',
          name: '新访客',
          data: [],
          yAxisIndex: '0'
        }],
        grid: {
          containLabel: true
        }
      }
    }
  },
  beforeCreate() {

  },
  async created() {
    const vm = this
    vm.operateTime = new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
    const setOperateTime = urlKey.getUrlKey('operateTime')
    if (setOperateTime) {
      vm.operateTime = new Date(setOperateTime - 24 * 60 * 60 * 1000)
    }
    vm.getAllOperateData()
  },
  methods: {
    getAllOperateData() {
      const vm = this
      vm.getSummaryData()
      vm.getOverviewData()
      vm.getDistributeData()
      vm.getPeriodData()
      vm.getConstituteData()
      vm.getDebtData()
      vm.getAdsFundsOperateDayUserInfoByTime()
      vm.getInvestData()
      vm.getFinanceData()
      vm.getIncomeData()
      vm.getPCH5Data()
      vm.getIOSAndAndroidData()
    },
    getSummaryData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDaySummary/getSummaryData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.summaryData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getOverviewData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDayOverview/getOverviewData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.overviewData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    twoTableRowMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0) {
          return {
            rowspan: 4,
            colspan: 1
          }
        } else if (rowIndex === 6) {
          return {
            rowspan: 5,
            colspan: 1
          }
        } else if (rowIndex === 4 || rowIndex === 17 || rowIndex === 19) {
          return {
            rowspan: 2,
            colspan: 1
          }
        } else if (rowIndex === 11 || rowIndex === 14) {
          return {
            rowspan: 3,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getDistributeData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDayInvestDistribute/getDistributeData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.distributeData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    threeTableRowMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 5) {
          return {
            rowspan: 5,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getPeriodData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDayProductPeriodsDistribute/getPeriodData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.periodData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    fourTableRowMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 11) {
          return {
            rowspan: 11,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getConstituteData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDayConstitute/getConstituteData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.constituteData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    fiveTableRowMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 7) {
          return {
            rowspan: 7,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getDebtData() {
      const vm = this
      request.post('/report/loan/operate/adsFundsOperateDayDebtUse/getDebtData', { operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            vm.debtData = res.data.result
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    sixTableRowMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 2) {
          return {
            rowspan: 2,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getAdsFundsOperateDayUserInfoByTime() {
      const vm = this
      const startTime = vm.getNowFormatDate(vm.operateTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      request.post('/report/loan/operate/adsFundsOperateDayUserInfo/getAdsFundsOperateDayUserInfoByTime', { startTime: startTime, endTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // 新增用户趋势图
            vm.userNew.xAxis.data = []
            vm.userNew.series[0].data = []
            vm.userNew.series[1].data = []
            // 各渠道注册用户分布情况
            vm.userEveryInvest.xAxis.data = []
            vm.userEveryInvest.series[0].data = []
            vm.userEveryInvest.series[1].data = []
            vm.userEveryInvest.series[2].data = []
            vm.userEveryInvest.series[3].data = []
            // 注册用户转化趋势图
            vm.userRegisteChange.xAxis.data = []
            vm.userRegisteChange.series[0].data = []
            vm.userRegisteChange.series[1].data = []
            vm.userRegisteChange.series[2].data = []
            // 注册用户转化率
            vm.userRegisteChangeRate.xAxis.data = []
            vm.userRegisteChangeRate.series[0].data = []
            vm.userRegisteChangeRate.series[1].data = []
            vm.userRegisteChangeRate.series[2].data = []
            // 待收用户增减变化趋势图（相对上一日）
            vm.userReceivableUserChangeNum.xAxis.data = []
            vm.userReceivableUserChangeNum.series[0].data = []
            // 登录用户走势图
            vm.userLoginUserNum.xAxis.data = []
            vm.userLoginUserNum.series[0].data = []
            res.data.result.forEach(ele => {
              // 新增用户趋势图
              vm.userNew.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userNew.series[0].data.push(ele.registerNum)
              vm.userNew.series[1].data.push(ele.firstInvestNum)
              // 各渠道注册用户分布情况
              vm.userEveryInvest.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userEveryInvest.series[0].data.push(ele.naturalRegisterNum)
              vm.userEveryInvest.series[1].data.push(ele.marketingRegisterNum)
              vm.userEveryInvest.series[2].data.push(ele.organizationRegisterNum)
              vm.userEveryInvest.series[3].data.push(ele.invitedRegisterNum)
              // 注册用户转化趋势图
              vm.userRegisteChange.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userRegisteChange.series[0].data.push(ele.openNum)
              vm.userRegisteChange.series[1].data.push(ele.rechargeNum)
              vm.userRegisteChange.series[2].data.push(ele.investNum)
              // 注册用户转化率
              vm.userRegisteChangeRate.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userRegisteChangeRate.series[0].data.push(ele.openConversionRate)
              vm.userRegisteChangeRate.series[1].data.push(ele.rechargeConversionRate)
              vm.userRegisteChangeRate.series[2].data.push(ele.investConversionRate)
              // 待收用户增减变化趋势图（相对上一日）
              vm.userReceivableUserChangeNum.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userReceivableUserChangeNum.series[0].data.push(ele.receivableUserChangeNum)
              // 登录用户走势图
              vm.userLoginUserNum.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.userLoginUserNum.series[0].data.push(ele.loginUserNum)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getInvestData() {
      const vm = this
      const startTime = vm.getNowFormatDate(vm.operateTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      request.post('/report/loan/operate/adsFundsOperateDayInvestInfo/getInvestData', { startTime: startTime, endTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // 每日成交数据走势图
            vm.investData.xAxis.data = []
            vm.investData.series[0].data = []
            vm.investData.series[1].data = []
            // 每日转投数据走势图
            vm.investForward.xAxis.data = []
            vm.investForward.series[0].data = []
            vm.investForward.series[1].data = []
            vm.investForward.series[2].data = []
            // 每日续期成功数据走势图
            vm.investRenew.xAxis.data = []
            vm.investRenew.series[0].data = []
            vm.investRenew.series[1].data = []
            // 每日申请正常退出走势图
            vm.investQuit.xAxis.data = []
            vm.investQuit.series[0].data = []
            vm.investQuit.series[1].data = []
            // 每日撤销退出走势图
            vm.investCancel.xAxis.data = []
            vm.investCancel.series[0].data = []
            vm.investCancel.series[1].data = []
            // 各渠道来源客户贡献金额占比走势图
            vm.investRate.xAxis.data = []
            vm.investRate.series[0].data = []
            vm.investRate.series[1].data = []
            vm.investRate.series[2].data = []
            vm.investRate.series[3].data = []
            vm.investRate.series[4].data = []
            vm.investRate.series[5].data = []
            // 券使用占比走势图
            vm.investCoupon.xAxis.data = []
            vm.investCoupon.series[0].data = []
            vm.investCoupon.series[1].data = []
            // 每日新老客出借走势图
            vm.investNewOld.xAxis.data = []
            vm.investNewOld.series[0].data = []
            vm.investNewOld.series[1].data = []
            vm.investNewOld.series[2].data = []
            vm.investNewOld.series[3].data = []
            res.data.result.forEach(ele => {
              // 每日成交数据走势图
              vm.investData.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investData.series[0].data.push((ele.investAmt / 10000).toFixed(2))
              vm.investData.series[1].data.push(ele.investNum)
              // 每日转投数据走势图
              vm.investForward.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investForward.series[0].data.push((ele.investForwardAmt / 10000).toFixed(2))
              vm.investForward.series[1].data.push(ele.investForwardNum)
              vm.investForward.series[2].data.push(ele.investForwardCnt)
              // 每日续期成功数据走势图
              vm.investRenew.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investRenew.series[0].data.push((ele.renewInvestAmt / 10000).toFixed(2))
              vm.investRenew.series[1].data.push(ele.renewInvestNum)
              // 每日申请正常退出走势图
              vm.investQuit.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investQuit.series[0].data.push((ele.normalQuitAmt / 10000).toFixed(2))
              vm.investQuit.series[1].data.push(ele.normalQuitNum)
              // 每日撤销退出走势图
              vm.investCancel.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investCancel.series[0].data.push((ele.cancelQuitAmt / 10000).toFixed(2))
              vm.investCancel.series[1].data.push(ele.cancelQuitNum)
              // 各渠道来源客户贡献金额占比走势图
              vm.investRate.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investRate.series[0].data.push(ele.otherInvestRate)
              vm.investRate.series[1].data.push(ele.organizationInvestRate)
              vm.investRate.series[2].data.push(ele.marketingInvestRate)
              vm.investRate.series[3].data.push(ele.brandInvestRate)
              vm.investRate.series[4].data.push(ele.invitedInvestRate)
              vm.investRate.series[5].data.push(ele.naturalInvestRate)
              // 券使用占比走势图
              vm.investCoupon.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investCoupon.series[0].data.push((ele.investDealAmt / 10000).toFixed(2))
              vm.investCoupon.series[1].data.push((ele.couponUseAmt / 10000).toFixed(2))
              // 每日新老客出借走势图
              vm.investNewOld.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.investNewOld.series[0].data.push((ele.newInvestAmt / 10000).toFixed(2))
              vm.investNewOld.series[1].data.push((ele.oldInvestAmt / 10000).toFixed(2))
              vm.investNewOld.series[2].data.push(ele.newInvestNum)
              vm.investNewOld.series[3].data.push(ele.oldInvestNum)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getFinanceData() {
      const vm = this
      const startTime = vm.getNowFormatDate(vm.operateTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      request.post('/report/loan/operate/adsFundsOperateDayFinance/getFinanceData', { startTime: startTime, endTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // 每日成交数据走势图
            vm.financeFunds.xAxis.data = []
            vm.financeFunds.series[0].data = []
            // 充值情况走势图
            vm.financeRecharge.xAxis.data = []
            vm.financeRecharge.series[0].data = []
            vm.financeRecharge.series[1].data = []
            // 提现情况走势图
            vm.financeWithdraw.xAxis.data = []
            vm.financeWithdraw.series[0].data = []
            vm.financeWithdraw.series[1].data = []
            // 回款与提现数据对比图
            vm.financeIncome.xAxis.data = []
            vm.financeIncome.series[0].data = []
            vm.financeIncome.series[1].data = []
            vm.financeIncome.series[2].data = []
            vm.financeIncome.series[3].data = []
            // 每日回款续投人数/金额占比
            vm.financeContinuationRate.xAxis.data = []
            vm.financeContinuationRate.series[0].data = []
            vm.financeContinuationRate.series[1].data = []
            res.data.result.forEach(ele => {
              // 每日成交数据走势图
              vm.financeFunds.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.financeFunds.series[0].data.push((ele.netFundsInAmt / 10000).toFixed(2))
              // 充值情况走势图
              vm.financeRecharge.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.financeRecharge.series[0].data.push((ele.rechargeAmt / 10000).toFixed(2))
              vm.financeRecharge.series[1].data.push(ele.rechargeNum)
              // 提现情况走势图
              vm.financeWithdraw.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.financeWithdraw.series[0].data.push((ele.withdrawAmt / 10000).toFixed(2))
              vm.financeWithdraw.series[1].data.push(ele.withdrawNum)
              // 回款与提现数据对比图
              vm.financeIncome.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.financeIncome.series[0].data.push((ele.incomeAmt / 10000).toFixed(2))
              vm.financeIncome.series[1].data.push((ele.withdrawAmt / 10000).toFixed(2))
              vm.financeIncome.series[2].data.push(ele.incomeNum)
              vm.financeIncome.series[3].data.push(ele.withdrawNum)
              // 每日回款续投人数/金额占比
              vm.financeContinuationRate.xAxis.data.push(vm.getNowFormatDate(ele.statisticsDate))
              vm.financeContinuationRate.series[0].data.push(ele.incomeContinuationAmtRate)
              vm.financeContinuationRate.series[1].data.push(ele.incomeContinuationNumRate)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getIncomeData() {
      const vm = this
      var now = vm.operateTime // 当前日期
      var nowMonth = now.getMonth() // 当前月
      var nowYear = now.getFullYear() // 当前年
      // 本月的开始时间
      var startTime = vm.getNowFormatDate(new Date(nowYear, nowMonth, 1))
      // 本月的结束时间
      var endTime = vm.getNowFormatDate(new Date(nowYear, nowMonth + 1, 0))

      request.post('/report/loan/operate/adsFundsOperateDayShouldIncome/getIncomeData', { startTime: startTime, endTime: endTime, operateTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // 本月待兑付走势图（老产品到期退出+智选产品退出数据）
            vm.income.xAxis.data = []
            vm.income.series[0].data = []
            vm.income.series[1].data = []
            res.data.result.forEach(ele => {
              // 本月待兑付走势图（老产品到期退出+智选产品退出数据）
              vm.income.xAxis.data.push(vm.getNowFormatDate(ele.dealDate))
              var datamap = {
                value: (ele.shouldIncomeAmt / 10000).toFixed(2),
                operateTime: vm.getNowFormatDate(vm.operateTime)
              }
              vm.income.series[0].data.push(datamap)
              vm.income.series[1].data.push(ele.shouldIncomeNum)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getPCH5Data() {
      const vm = this
      const startTime = vm.getNowFormatDate(vm.operateTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      request.post('/report/loan/operate/baiDuTongJiItem0115/getPCH5Data', { startTime: startTime, endTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // （PC+H5）PV与访问次数对比图
            vm.pCH5PV.xAxis.data = []
            vm.pCH5PV.series[0].data = []
            vm.pCH5PV.series[1].data = []
            // （PV+H5）访问次数与UV对比图
            vm.pCH5UV.xAxis.data = []
            vm.pCH5UV.series[0].data = []
            vm.pCH5UV.series[1].data = []
            // （PC+H5）新老访客对比
            vm.pCH5OldNew.xAxis.data = []
            vm.pCH5OldNew.series[0].data = []
            vm.pCH5OldNew.series[1].data = []
            res.data.result.forEach(ele => {
              // （PC+H5）PV与访问次数对比图
              vm.pCH5PV.xAxis.data.push(ele.selectday.replace(RegExp('/', 'g'), '-'))
              vm.pCH5PV.series[0].data.push(ele.pvCount)
              vm.pCH5PV.series[1].data.push(ele.visitCount)
              // （PV+H5）访问次数与UV对比图
              vm.pCH5UV.xAxis.data.push(ele.selectday.replace(RegExp('/', 'g'), '-'))
              vm.pCH5UV.series[0].data.push(ele.visitorCount)
              vm.pCH5UV.series[1].data.push(ele.visitCount)
              // （PC+H5）新老访客对比
              vm.pCH5OldNew.xAxis.data.push(ele.selectday.replace(RegExp('/', 'g'), '-'))
              vm.pCH5OldNew.series[0].data.push(ele.visitorCount - ele.newVisitorCount)
              vm.pCH5OldNew.series[1].data.push(ele.newVisitorCount)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getIOSAndAndroidData() {
      const vm = this
      const startTime = vm.getNowFormatDate(vm.operateTime.getTime() - 30 * 24 * 60 * 60 * 1000)
      request.post('/report/loan/operate/youMengItem/getIOSAndAndroidData', { startTime: startTime, endTime: vm.getNowFormatDate(vm.operateTime) })
        .then((res) => {
          if (res.data.status === 0) {
            // Android启动次数与UV对比图
            vm.androidUV.xAxis.data = []
            vm.androidUV.series[0].data = []
            vm.androidUV.series[1].data = []
            res.data.result[1].forEach(ele => {
              // Android启动次数与UV对比图
              vm.androidUV.xAxis.data.push(ele.date)
              vm.androidUV.series[0].data.push(ele.launchcount)
              vm.androidUV.series[1].data.push(ele.activeUsercount)
            })
            // IOS启动次数与UV对比图
            vm.iOSUV.xAxis.data = []
            vm.iOSUV.series[0].data = []
            vm.iOSUV.series[1].data = []
            // APP新老访客对比
            vm.appOldNew.xAxis.data = []
            vm.appOldNew.series[0].data = []
            vm.appOldNew.series[1].data = []
            res.data.result[0].forEach((ele, index) => {
              // IOS启动次数与UV对比图
              vm.iOSUV.xAxis.data.push(ele.date)
              vm.iOSUV.series[0].data.push(ele.launchcount)
              vm.iOSUV.series[1].data.push(ele.activeUsercount)
              // APP新老访客对比
              vm.appOldNew.xAxis.data.push(ele.date)
              vm.appOldNew.series[0].data.push((ele.activeUsercount - 0 + (res.data.result[1][index].activeUsercount - 0)) - (ele.newUsercount - 0 + (res.data.result[1][index].newUsercount - 0)))
              vm.appOldNew.series[1].data.push(ele.newUsercount - 0 + (res.data.result[1][index].newUsercount - 0))
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 导出
    exportAllOperateData() {
      const vm = this
      const param = new URLSearchParams()
      param.append('operateTime', vm.getNowFormatDate(vm.operateTime))
      const url = process.env.BASE_API + '/report/loan/operate/exportAllOperateData/downLoadOperateDayXlsx'
      axios({
        method: 'post',
        url: url,
        data: param,
        headers: {
          'adoptToken': getToken()
        },
        responseType: 'blob'
      }).then((res) => {
        fileDownload(res.data, vm.getNowFormatDate(vm.operateTime) + '运营日报.xlsx')
      }).catch(function(error) {
        console.log(error)
      })
    },
    formateToFix(value, category, multiple) {
      const vm = this
      if (value !== null && value !== '') {
        if (multiple !== undefined) {
          return vm.formatNumber((value * 100).toFixed(2))
        } else {
          if (category === '回款续投率') {
            return (value * 100).toFixed(2) + '%'
          } else {
            if ((value + '').indexOf('.') > 0) {
              return vm.formatNumber(value.toFixed(2))
            } else {
              return vm.formatNumber(value)
            }
          }
        }
      } else {
        return '-'
      }
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    formatNumber(s, n) {
      return (s + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,')
    },
    formatComma(row, column, cellValue, index) {
      const vm = this
      return vm.formatNumber(cellValue)
    }
  }
}
</script>
<style scoped lang="scss">
.el-main{
  padding:0;
}
/deep/ .funds .el-form-item__label{
  width:110px;
}
/deep/ .el-dialog__body{
  padding-top:10px;
  padding-bottom: 0;
}
/deep/ .el-select--medium{
  width:350px;
}
/deep/ .el-date-editor{
  width:168px;
}
.btnTwo{
  float: right;
}
/deep/ .el-table .cell{
  height:auto;
}
.times{
  overflow: hidden;
  padding-bottom:10px;
}
.times>span{
  float: left;
  width:25%;
  text-align: center;
  height:24px;
}
.funds .el-icon-setting{
  font-size:18px;
  position: relative;
  top:2px;
  cursor: pointer;
}
/deep/ .amtBalance span{
  padding-right:5px;
}
/deep/ .amtBalance i{
  cursor: pointer;
}
.earlyWarning{
  margin-bottom: 15px;
}
.earlyWarning i{
  font-style: normal;
  color:#f11b1b;
}
.earlyWarning>b{
  display: inline-block;
  width:110px;
  font-size:14px;
  color:#606266;
  text-align: right;
  font-weight:700;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
.ptitle{
    font-weight: bolder;
    font-size: 18px;
}
</style>
