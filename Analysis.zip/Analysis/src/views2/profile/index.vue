<template>
  <div class="app-container">
    <div>
      <el-row :gutter="20">
        <el-col :span="24" :xs="24">
          <el-card>
            <el-tabs v-model="activeName">
              <el-tab-pane label="基本信息" name="info" class="userConfig">
                <el-container style="height: 600px">
                  <el-card class="box-card sqqd" style="border:none;width:100%">
                    <el-row class="changeAvatar">
                      <el-button type="primary" @click="toggleShow">
                        Upload
                        <i class="el-icon-upload el-icon-right"/>
                      </el-button>
                      <my-upload
                        v-model="show"
                        :width="300"
                        :height="300"
                        :headers="headers"
                        :url="BASE_API+'/privilege/user/uploadImg'"
                        @crop-success="cropSuccess"
                        @crop-upload-success="cropUploadSuccess"
                        @crop-upload-fail="cropUploadFail"
                        @src-file-set="srcFileSet"
                      />
                      <img :src="imgDataUrl" style="max-width:100px;max-height:100px;">
                    </el-row>
                    <el-form ref="userConfig" :inline="true" :rules="userRules" :model="userConfig" class="demo-ruleForm">
                      <el-row>
                        <el-col :span="12">
                          <el-form-item label="用户名" prop="userName">
                            <el-input v-model="userConfig.userName" :disabled="true" clearable />
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item label="出生年月" prop="birthday">
                            <el-date-picker
                              :editable="false"
                              v-model="userConfig.birthday"
                              type="date"
                              placeholder="选择日期"/>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="12">
                          <el-form-item label="昵称" prop="nickName">
                            <el-input v-model="userConfig.nickName" clearable/>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item label="性别" prop="gender">
                            <el-select v-model="userConfig.gender" placeholder="请选择">
                              <el-option :value="-1" label="未知"/>
                              <el-option :value="1" label="男"/>
                              <el-option :value="2" label="女"/>
                            </el-select>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="12">
                          <el-form-item label="有效开始日期" prop="validBeginDate">
                            <el-date-picker
                              :editable="false"
                              :disabled="true"
                              v-model="userConfig.validBeginDate"
                              :picker-options="pickerOptions"
                              type="datetime"
                              placeholder="选择日期时间"
                              align="right"/>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item label="有效结束日期" prop="validEndDate">
                            <el-date-picker
                              :editable="false"
                              :disabled="true"
                              v-model="userConfig.validEndDate"
                              :picker-options="pickerOptions"
                              type="datetime"
                              placeholder="选择日期时间"
                              align="right"/>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="12">
                          <el-form-item label="邮箱" prop="email">
                            <el-input v-model="userConfig.email" clearable/>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item label="手机号码" prop="phoneNo">
                            <el-input v-model="userConfig.phoneNo" clearable/>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="12">
                          <el-form-item label="地址" prop="address">
                            <el-input v-model="userConfig.address" clearable/>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                          <el-form-item label="邮编" prop="postcode">
                            <el-input v-model="userConfig.postcode" clearable/>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="12" class="remarks">
                          <el-form-item label="备注" prop="remark">
                            <el-input v-model="userConfig.remark" type="textarea" clearable/>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row class="btnTwo">
                        <el-button type="primary" @click="onSubmit1('userConfig')">保存</el-button>
                        <!-- <el-button @click="resetForm('userConfig')">重置</el-button> -->
                      </el-row>
                    </el-form>
                  </el-card>
                </el-container>
              </el-tab-pane>
              <el-tab-pane label="修改密码" name="timeline">
                <el-container style="height: 600px">
                  <el-card class="box-card sqqd" style="border:none;width:100%">
                    <div class="modifyPassword">
                      <el-form ref="rulePassForm" :model="rulePassForm" :rules="rulesPass" status-icon label-width="100px" class="demo-ruleForm">
                        <el-form-item label="旧密码" prop="oldPass">
                          <el-input v-model="rulePassForm.oldPass" type="password" auto-complete="off"/>
                        </el-form-item>
                        <el-form-item label="新密码" prop="pass">
                          <el-input v-model="rulePassForm.pass" type="password" auto-complete="off"/>
                        </el-form-item>
                        <el-form-item label="确认新密码" prop="checkPass">
                          <el-input v-model="rulePassForm.checkPass" type="password" auto-complete="off"/>
                        </el-form-item>
                        <el-form-item>
                          <el-button type="primary" @click="submitPassForm('rulePassForm')">提交</el-button>
                          <el-button @click="resetPassForm('rulePassForm')">重置</el-button>
                        </el-form-item>
                      </el-form>
                    </div>
                  </el-card>
                </el-container>
              </el-tab-pane>
            </el-tabs>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import store from '../../store'
import { getToken } from '@/utils/auth'
import request from '@/utils/request'
import myUpload from 'vue-image-crop-upload'
import md5 from 'js-md5'

export default {
  name: 'Profile',
  components: { 'my-upload': myUpload },
  data() {
    var validatePass1 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入旧密码'))
      } else {
        if (this.rulePassForm.oldPass !== '') {
          this.$refs.rulePassForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入新密码'))
      } else {
        if (this.rulePassForm.checkPass !== '') {
          this.$refs.rulePassForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入新密码'))
      } else if (value !== this.rulePassForm.pass) {
        callback(new Error('两次输入的新密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      BASE_API: process.env.BASE_API,
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      activeName: 'info',
      userConfig: {
        userName: '',
        nickName: '',
        gender: '',
        email: '',
        phoneNo: '',
        address: '',
        postcode: '',
        validBeginDate: '',
        validEndDate: '',
        birthday: '',
        remark: '',
        photoPath: '',
        md5Info: ''
      },
      userRules: {
        userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        nickName: [{ required: true, message: '请输入昵称', trigger: 'blur' }],
        gender: [{ required: true, message: '请选择性别', trigger: 'change' }],
        validBeginDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }],
        validEndDate: [{ type: 'date', required: true, message: '请选择日期时间', trigger: 'change' }]
      },
      show: false,
      headers: {
        adoptToken: getToken()
      },
      imgDataUrl: '',
      // 密码修改
      rulePassForm: {
        pass: '',
        checkPass: '',
        oldPass: ''
      },
      rulesPass: {
        oldPass: [{ validator: validatePass1, trigger: 'blur' }],
        pass: [{ validator: validatePass, trigger: 'blur' }],
        checkPass: [{ validator: validatePass2, trigger: 'blur' }]
      }
    }
  },
  created() {
    const vm = this
    // 获取用户配置里的用户信息
    request.post('/privilege/user/getUserById', { userId: store.getters.userId }).then(function(res) {
      if (res.data.status === 0) {
        vm.userConfig.userName = res.data.result.userName
        vm.userConfig.nickName = res.data.result.nickName
        vm.userConfig.gender = res.data.result.gender
        vm.userConfig.email = res.data.result.email
        vm.userConfig.phoneNo = res.data.result.phoneNo
        vm.userConfig.address = res.data.result.address
        vm.userConfig.postcode = res.data.result.postcode
        vm.userConfig.validBeginDate = res.data.result.validBeginDate
        vm.userConfig.validEndDate = res.data.result.validEndDate
        vm.userConfig.birthday = res.data.result.birthday
        vm.userConfig.remark = res.data.result.remark
        vm.userConfig.photoPath = res.data.result.photoPath
        vm.userConfig.md5Info = res.data.result.md5Info
        if (res.data.result.photoPath) {
          vm.imgDataUrl = vm.BASE_API + res.data.result.photoPath
        } else {
          vm.imgDataUrl = ''
        }
      }
    })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      if (!date) { return '' }
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    toggleShow() {
      this.show = !this.show
    },
    srcFileSet(fileName, fileType, fileSize) {
    },
    cropSuccess(imgDataUrl, field) {
      this.imgDataUrl = imgDataUrl
    },
    cropUploadSuccess(jsonData, field) {
      if (jsonData.status === 0) {
        this.userConfig.md5Info = jsonData.result.md5Info
        this.userConfig.photoPath = jsonData.result.photoPath
      }
    },
    cropUploadFail(status, field) {
      console.log('-------- upload fail --------')
      console.log(status)
      console.log('field: ' + field)
    },
    onSubmit1(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) { // 必填项全部填完
          const validBeginDate = vm.getNowFormatDate(vm.userConfig.validBeginDate)
          const validEndDate = vm.getNowFormatDate(vm.userConfig.validEndDate)
          let birthday = ''
          if (vm.userConfig.birthday) {
            birthday = vm.getNowFormatDate(vm.userConfig.birthday)
            const birArr = birthday.split(' ')
            birthday = birArr[0]
          }
          const params = {
            userId: store.getters.userId,
            photoPath: vm.userConfig.photoPath,
            md5Info: vm.userConfig.md5Info,
            userName: vm.userConfig.userName,
            nickName: vm.userConfig.nickName,
            gender: vm.userConfig.gender,
            email: vm.userConfig.email,
            phoneNo: vm.userConfig.phoneNo,
            address: vm.userConfig.address,
            postcode: vm.userConfig.postcode,
            validBeginDate: validBeginDate,
            validEndDate: validEndDate,
            birthday: birthday,
            remark: vm.userConfig.remark
          }
          const api = '/privilege/user/modifyUser'
          if (vm.userConfig.photoPath) {
            const pArr = vm.userConfig.photoPath.split('md5Info=')
            params.md5Info = pArr[1]
          } else {
            params.md5Info = ''
          }

          request.post(api, params).then(function(res) {
            if (res.data.status === 0) {
              vm.$message({
                showClose: true,
                message: '编辑用户成功！',
                type: 'success'
              })
              vm.userSearchSubmit(1)
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    submitPassForm(formName) {
      const vm = this
      vm.$refs[formName].validate((valid) => {
        if (valid) {
          request.post('/privilege/user/modifyPassWord',
            {
              userId: store.getters.userId,
              newPassWord: md5(vm.rulePassForm.checkPass),
              oldPassWord: md5(vm.rulePassForm.oldPass)
            }).then(function(res) {
            if (res.data.status === 0) {
              vm.$message({
                showClose: true,
                message: '密码修改成功！',
                type: 'success'
              })
              vm.resetPassForm('rulePassForm')
            } else {
              // vm.$message({
              //   showClose: true,
              //   message: '密码修改失败！',
              //   type: 'error'
              // })
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetPassForm(formName) {
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style scoped>
.avatar{
  width: 200px;
  height: 200px;
  border-radius: 50%;
}
/deep/ .userConfig .el-form-item__label{
  width:150px;
  text-align: right;
}
/deep/ .userConfig .el-input--medium{
  width:210px;
}
.btnTwo{
  text-align:right;
  padding-right:122px;
}
.changeAvatar{
  padding-left:38px;
  margin-bottom:20px;
}
.changeAvatar>img{
  max-width:100px;
  max-height:100px;
  position:relative;
  top:13px;
  left:10px;
}
/deep/ .el-dialog__body{
  padding:30px 20px 0;
  /* height:600px; */
}
/deep/ .remarks .el-textarea__inner{
  width:696px;
  height:80px;
}
/deep/ .remarks .el-form-item--medium{
  margin-bottom:10px;
}
</style>
