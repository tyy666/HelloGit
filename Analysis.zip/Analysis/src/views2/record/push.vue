<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>推送日志</span>
          </div>
          <el-form :inline="true" v-model="pushSearch" class="demo-form-inline">
            <el-form-item label="推送时间">
              <el-date-picker
                :editable="false"
                v-model="pushSearch.time"
                :picker-options="pickerOptions"
                type="datetimerange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"/>
            </el-form-item>
            <el-form-item label="发送人">
              <el-input v-model.trim="pushSearch.sender" clearable />
            </el-form-item>
            <el-form-item label="接收人">
              <el-input v-model.trim="pushSearch.receiver" clearable />
            </el-form-item>
            <el-form-item label="标题">
              <el-input v-model.trim="pushSearch.msgTitle" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="pushSearchSubmit(1)">查询</el-button>
            </el-form-item>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="pushInfo.records"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              prop="id"
              label="日志ID"
              align="center"
              width="80px"/>
            <el-table-column
              prop="userId"
              label="推送人"
              align="center"
            />
            <el-table-column
              prop="msgType"
              label="消息类型"
              align="center">
              <template slot-scope="scope">
                <template v-if="scope.row.msgType===1">
                  短信(SMS)
                </template>
                <template v-if="scope.row.msgType===2">
                  彩信(MMS)
                </template>
                <template v-if="scope.row.msgType===3">
                  邮件(MAIL)
                </template>

              </template>
            </el-table-column>
            <el-table-column
              prop="sender"
              label="发送人"
              align="center"
            />
            <el-table-column
              prop="receiver"
              label="接收人"
              align="center"
            />
            <el-table-column
              prop="msgTitle"
              label="标题"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="msgCont"
              min-width="200px"
              label="内容"
              align="center"
            />
            <el-table-column
              prop="filePath"
              label="附件路径"
              align="center"
            />
            <el-table-column
              :formatter="dateFormat"
              prop="startTime"
              label="发送开始时间"
              align="center"
            />
            <el-table-column
              :formatter="dateFormat"
              prop="endTime"
              label="发送结束时间"
              align="center"
            />
            <el-table-column
              prop="sendStatus"
              label="发送状态"
              align="center">
              <template slot-scope="scope">{{ scope.row.sendStatus===1?"成功":"失败" }}</template>
            </el-table-column>
          </el-table>
          <el-pagination
            v-if="pushInfo.records&&pushInfo.records.length"
            :total="pushInfo.total"
            :current-page.sync="pushInfo.currentPage"
            :page-sizes="[5,10,15,20]"
            :page-size.sync="pushInfo.pageSize"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="pushSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
export default{
  name: 'PushRecord',
  data() {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '最近一周',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      contentLoading: false,
      pushSearch: {
        time: '',
        startTime: '',
        endTime: '',
        sender: '',
        receiver: '',
        msgTitle: ''
      },
      pushInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      }
    }
  },
  created() {
    const vm = this
    request.post('/logging/selectPushLog',
      {
        adoptToken: localStorage.adoptToken,
        currentPage: 1,
        pageSize: 10,
        startTime: '',
        endTime: '',
        sender: '',
        receiver: '',
        msgTitle: ''
      })
      .then(function(res) {
        if (res.data.status === 0) {
          vm.pushInfo.records = res.data.result.result
          vm.pushInfo.total = res.data.result.totalCount
          vm.pushInfo.currentPage = res.data.result.currentPage
        }
      })
      .catch(function(err) {
        console.log(err)
      })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    dateFormat: function(row, column, cellValue) {
      let date
      if (!cellValue) {
        date = ''
      } else {
        date = this.getNowFormatDate(cellValue)
      }
      return date
    },
    async pushSearchSubmit(page) {
      const vm = this
      vm.contentLoading = true
      vm.pushInfo.currentPage = page
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: page,
        pageSize: vm.pushInfo.pageSize,
        startTime: vm.pushSearch.startTime,
        endTime: vm.pushSearch.endTime,
        sender: vm.pushSearch.sender,
        receiver: vm.pushSearch.receiver,
        msgTitle: vm.pushSearch.msgTitle
      }
      const ret = await request.post('/logging/selectPushLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.pushInfo.records = ret.data.result.result
        vm.pushInfo.total = ret.data.result.totalCount
        vm.pushInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.contentLoading = true
      vm.pushInfo.currentPage = 1
      vm.pushInfo.pageSize = pageSize
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: 1,
        pageSize: pageSize,
        startTime: vm.pushSearch.startTime,
        endTime: vm.pushSearch.endTime,
        sender: vm.pushSearch.sender,
        receiver: vm.pushSearch.receiver,
        msgTitle: vm.pushSearch.msgTitle
      }
      const ret = await request.post('/logging/selectPushLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.pushInfo.records = ret.data.result.result
        vm.pushInfo.total = ret.data.result.totalCount
        vm.pushInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    changeTime() {
      if (this.pushSearch.time) {
        const t1 = this.pushSearch.time[0]
        const t2 = this.pushSearch.time[1]
        const startTime = this.getNowFormatDate(t1)
        const endTime = this.getNowFormatDate(t2)
        this.pushSearch.startTime = startTime
        this.pushSearch.endTime = endTime
      } else {
        this.pushSearch.time = ''
        this.pushSearch.startTime = ''
        this.pushSearch.endTime = ''
      }
    }
  }
}
</script>

<style scoped>
.el-main{
  padding:0;
}
.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
</style>

