<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>登录日志</span>
          </div>
          <el-form :inline="true" v-model="loginSearch" class="demo-form-inline">
            <el-form-item label="登录时间">
              <el-date-picker
                :editable="false"
                v-model="loginSearch.time"
                :picker-options="pickerOptions"
                type="datetimerange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @change="changeTime"/>
            </el-form-item>
            <el-form-item label="登录人">
              <el-input v-model.trim="loginSearch.operator" clearable />
            </el-form-item>
            <el-form-item label="服务器端Ip">
              <el-input v-model.trim="loginSearch.serverIp" clearable />
            </el-form-item>
            <el-form-item label="客户端Ip">
              <el-input v-model.trim="loginSearch.clientIp" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="loginSearchSubmit(1)">查询</el-button>
            </el-form-item>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="loginInfo.records"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              prop="id"
              label="日志ID"
              align="center"
              width="80px"/>
            <el-table-column
              prop="userId"
              label="登录人"
              align="center"
            />
            <el-table-column
              :formatter="dateFormat"
              prop="loginTime"
              label="登录时间"
              align="center"
            />
            <el-table-column
              prop="resultCode"
              label="返回码"
              align="center"
            />
            <el-table-column
              prop="resultMsg"
              label="返回信息"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="serverIp"
              label="服务器端Ip"
              align="center"
            />
            <el-table-column
              prop="clientIp"
              label="客户端Ip"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="userAgent"
              label="客户端UA信息"
              align="center"
            />
            <el-table-column
              prop="browser"
              label="客户端浏览器"
              align="center"
            />
            <el-table-column
              prop="system"
              label="客户端操作系统"
              align="center"
            />
          </el-table>
          <el-pagination
            v-if="loginInfo.records&&loginInfo.records.length"
            :total="loginInfo.total"
            :current-page.sync="loginInfo.currentPage"
            :page-size.sync="loginInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="loginSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
export default{
  name: 'LoginRecord',
  data() {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '最近一周',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      contentLoading: false,
      loginSearch: {
        time: '',
        startTime: '',
        endTime: '',
        operator: '',
        serverIp: '',
        clientIp: ''
      },
      loginInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      }
    }
  },
  created() {
    const vm = this
    request.post('/logging/selectLoginLog',
      {
        adoptToken: localStorage.adoptToken,
        currentPage: 1,
        pageSize: 10,
        startTime: '',
        endTime: '',
        userId: '',
        serverIp: '',
        clientIp: ''
      })
      .then(function(res) {
        if (res.data.status === 0) {
          vm.loginInfo.records = res.data.result.result
          vm.loginInfo.total = res.data.result.totalCount
          vm.loginInfo.currentPage = res.data.result.currentPage
        }
      })
      .catch(function(err) {
        console.log(err)
      })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    dateFormat: function(row, column, cellValue) {
      let date
      if (!cellValue) {
        date = ''
      } else {
        date = this.getNowFormatDate(cellValue)
      }
      return date
    },
    async loginSearchSubmit(page) {
      const vm = this
      vm.contentLoading = true
      vm.loginInfo.currentPage = page
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: page,
        pageSize: vm.loginInfo.pageSize,
        startTime: vm.loginSearch.startTime,
        endTime: vm.loginSearch.endTime,
        userId: vm.loginSearch.operator,
        serverIp: vm.loginSearch.serverIp,
        clientIp: vm.loginSearch.clientIp
      }
      const ret = await request.post('/logging/selectLoginLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.loginInfo.records = ret.data.result.result
        vm.loginInfo.total = ret.data.result.totalCount
        vm.loginInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.contentLoading = true
      vm.loginInfo.currentPage = 1
      vm.loginInfo.pageSize = pageSize
      const params = {
        adoptToken: localStorage.adoptToken,
        currentPage: 1,
        pageSize: pageSize,
        startTime: vm.loginSearch.startTime,
        endTime: vm.loginSearch.endTime,
        userId: vm.loginSearch.operator,
        serverIp: vm.loginSearch.serverIp,
        clientIp: vm.loginSearch.clientIp
      }
      const ret = await request.post('/logging/selectLoginLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.loginInfo.records = ret.data.result.result
        vm.loginInfo.total = ret.data.result.totalCount
        vm.loginInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    changeTime() {
      if (this.loginSearch.time) {
        const t1 = this.loginSearch.time[0]
        const t2 = this.loginSearch.time[1]
        const startTime = this.getNowFormatDate(t1)
        const endTime = this.getNowFormatDate(t2)
        this.loginSearch.startTime = startTime
        this.loginSearch.endTime = endTime
      } else {
        this.loginSearch.time = ''
        this.loginSearch.startTime = ''
        this.loginSearch.endTime = ''
      }
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
</style>

