<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>操作日志</span>
          </div>
          <el-form :inline="true" v-model="operateSearch" class="demo-form-inline">
            <el-form-item label="操作时间">
              <el-date-picker
                :editable="false"
                v-model="operateSearch.time"
                :picker-options="pickerOptions"
                type="datetimerange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @change="changeTime"/>
            </el-form-item>
            <el-form-item label="操作人">
              <el-input v-model.trim="operateSearch.userId" clearable />
            </el-form-item>
            <el-form-item label="操作类型">
              <el-select v-model="operateSearch.oprType" placeholder="请选择">
                <el-option label="全部" value=""/>
                <el-option label="UNKNOW" value="UNKNOW" />
                <el-option label="INSERT" value="INSERT" />
                <el-option label="UPDATE" value="UPDATE" />
                <el-option label="DELETE" value="DELETE" />
                <el-option label="SELECT" value="SELECT" />
                <el-option label="EXPORT" value="EXPORT" />
                <el-option label="UPLOAD" value="UPLOAD" />
                <el-option label="UNZIP" value="UNZIP" />
                <el-option label="SNAPSHOT" value="SNAPSHOT" />

              </el-select>
            </el-form-item>
            <el-form-item label="是否报错">
              <el-select v-model="operateSearch.isError" placeholder="请选择">
                <el-option label="全部" value="" />
                <el-option label="是" value="1" />
                <el-option label="否" value="-1" />
              </el-select>
            </el-form-item>
            <el-form-item label="服务器端Ip">
              <el-input v-model.trim="operateSearch.serverIp" clearable />
            </el-form-item>
            <el-form-item label="客户端Ip">
              <el-input v-model.trim="operateSearch.clientIp" clearable />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="operateSearchSubmit(1)">查询</el-button>
            </el-form-item>
          </el-form>
          <el-table
            v-loading="contentLoading"
            ref="multipleTable"
            :data="operateInfo.records"
            highlight-current-row
            border
            style="width: 100%;margin-bottom: 20px">
            <el-table-column
              prop="id"
              label="日志ID"
              align="center"
              width="80px"/>
            <el-table-column
              prop="oprType"
              label="操作类型"
              align="center"/>
            <el-table-column
              :show-overflow-tooltip="true"
              prop="oprCont"
              min-width="200px"
              label="操作内容"
              align="center"/>
            <el-table-column
              prop="userId"
              label="操作人"
              align="center"
            />
            <el-table-column
              :formatter="dateFormat"
              prop="startTime"
              label="操作开始时间"
              align="center"
            />
            <el-table-column
              :formatter="dateFormat"
              prop="endTime"
              label="操作结束时间"
              align="center"/>
            <el-table-column
              prop="isError"
              label="是否报错"
              align="center">
              <template slot-scope="scope">{{ scope.row.isError===-1?"否":"是" }}</template>
            </el-table-column>
            <el-table-column
              prop="errMsg"
              label="错误信息"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="serverIp"
              label="服务器端Ip"
              align="center"
            />
            <el-table-column
              prop="clientIp"
              label="客户端Ip"
              align="center"
            />
            <el-table-column
              :show-overflow-tooltip="true"
              prop="userAgent"
              label="客户端UA信息"
              align="center"
            />
            <el-table-column
              prop="browser"
              label="客户端浏览器"
              align="center"
            />
            <el-table-column
              prop="system"
              label="客户端操作系统"
              align="center"
            />
          </el-table>
          <el-pagination
            v-if="operateInfo.records&&operateInfo.records.length"
            :total="operateInfo.total"
            :current-page.sync="operateInfo.currentPage"
            :page-size.sync="operateInfo.pageSize"
            :page-sizes="[5,10,15,20]"
            background
            layout="jumper,prev, pager, next,total,sizes"
            style="text-align: center"
            @size-change="sizeChange"
            @current-change="operateSearchSubmit"/>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import request from '@/utils/request'
export default{
  name: 'OperateRecord',
  data() {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '最近一周',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      contentLoading: false,
      operateSearch: {
        time: '',
        startTime: '',
        endTime: '',
        userId: '',
        oprType: '',
        isError: '',
        serverIp: '',
        clientIp: ''
      },
      operateInfo: {
        records: [],
        total: 0,
        currentPage: 1,
        pageSize: 10
      }
    }
  },
  created() {
    const vm = this
    request.post('/logging/selectOperateLog',
      {
        currentPage: 1,
        pageSize: 10,
        startTime: '',
        endTime: '',
        userId: '',
        serverIp: '',
        clientIp: '',
        oprType: '',
        isError: ''
      })
      .then(function(res) {
        if (res.data.status === 0) {
          vm.operateInfo.records = res.data.result.result
          vm.operateInfo.total = res.data.result.totalCount
          vm.operateInfo.currentPage = res.data.result.currentPage
        }
      })
      .catch(function(err) {
        console.log(err)
      })
  },
  methods: {
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      const year = date.getFullYear()
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      let hh = date.getHours()
      let mm = date.getMinutes()
      let ss = date.getSeconds()
      if (month >= 1 && month <= 9) { month = '0' + month }
      if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
      if (hh >= 0 && hh <= 9) { hh = '0' + hh }
      if (mm >= 0 && mm <= 9) { mm = '0' + mm }
      if (ss >= 0 && ss <= 9) { ss = '0' + ss }
      const currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm + ':' + ss
      return currentdate
    },
    dateFormat: function(row, column, cellValue) {
      let date
      if (!cellValue) {
        date = ''
      } else {
        date = this.getNowFormatDate(cellValue)
      }
      return date
    },
    async operateSearchSubmit(page) {
      const vm = this
      vm.operateInfo.currentPage = page
      vm.contentLoading = true
      const params = {
        currentPage: page,
        pageSize: vm.operateInfo.pageSize,
        startTime: vm.operateSearch.startTime,
        endTime: vm.operateSearch.endTime,
        userId: vm.operateSearch.userId,
        serverIp: vm.operateSearch.serverIp,
        clientIp: vm.operateSearch.clientIp,
        oprType: vm.operateSearch.oprType,
        isError: vm.operateSearch.isError
      }
      const ret = await request.post('/logging/selectOperateLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.operateInfo.records = ret.data.result.result
        vm.operateInfo.total = ret.data.result.totalCount
        vm.operateInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    async sizeChange(pageSize) {
      const vm = this
      vm.operateInfo.currentPage = 1
      vm.operateInfo.pageSize = pageSize
      vm.contentLoading = true
      const params = {
        currentPage: 1,
        pageSize: pageSize,
        startTime: vm.operateSearch.startTime,
        endTime: vm.operateSearch.endTime,
        userId: vm.operateSearch.userId,
        serverIp: vm.operateSearch.serverIp,
        clientIp: vm.operateSearch.clientIp,
        oprType: vm.operateSearch.oprType,
        isError: vm.operateSearch.isError
      }
      const ret = await request.post('/logging/selectOperateLog', params)
      if (ret.data.status === 0) { // 执行成功
        vm.operateInfo.records = ret.data.result.result
        vm.operateInfo.total = ret.data.result.totalCount
        vm.operateInfo.currentPage = ret.data.result.currentPage
      }
      vm.contentLoading = false
    },
    changeTime() {
      if (this.operateSearch.time) {
        const t1 = this.operateSearch.time[0]
        const t2 = this.operateSearch.time[1]
        const startTime = this.getNowFormatDate(t1)
        const endTime = this.getNowFormatDate(t2)
        this.operateSearch.startTime = startTime
        this.operateSearch.endTime = endTime
      } else {
        this.operateSearch.time = ''
        this.operateSearch.startTime = ''
        this.operateSearch.endTime = ''
      }
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.box-card .el-col{
  margin-bottom: 10px;
  font-size:13px;
}
.box-card .el-col:last-child{
  margin-bottom:0;
}
</style>
