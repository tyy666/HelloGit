<template>
  <div class="app-container">
    <el-container>
      <el-main>
        <el-card class="box-card" style="min-height:600px">
          <el-tabs v-model="activeName" @tab-click="tabClick">
            <el-tab-pane label="平台监控" name="first">
              <el-form :inline="true" v-model="fundsSearch" class="demo-form-inline funds">
                <el-form-item label="查询时间：">
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="fundsSearch.startTime"
                    type="date"
                    placeholder="开始日期"
                    @change="changeTimeA"/>
                  -
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="fundsSearch.endTime"
                    type="date"
                    placeholder="结束日期"
                    @change="changeTimeB"/>
                </el-form-item>
                <el-form-item label="平台筛选：">
                  <el-select v-model="fundsSearch.firstSelectCompetitions" multiple placeholder="请选择平台" collapse-tags>
                    <el-option v-for="item in firstCompetitions" :key="item.name" :label="item.name" :value="item.name"/>
                  </el-select>
                  <el-button type="primary" style="margin-left:30px" @click="fundSearchSubmit">查询</el-button>
                </el-form-item>
              </el-form>
              <div v-loading="contentLoading" :class="className" :id="id" :style="{height:height,width:width}"/>
            </el-tab-pane>
            <el-tab-pane label="平台产品监控" name="second">
              <el-form :inline="true" v-model="productSearch" class="demo-form-inline funds">
                <el-form-item label="查询时间：">
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="productSearch.startTime"
                    type="date"
                    placeholder="开始日期"
                    @change="changeTimeC"/>
                  -
                  <el-date-picker
                    :editable="false"
                    :clearable="false"
                    v-model="productSearch.endTime"
                    type="date"
                    placeholder="结束日期"
                    @change="changeTimeD"/>
                </el-form-item>
                <el-form-item label="平台筛选：">
                  <el-select v-model="productSearch.secondSelectCompetitions" placeholder="请选择平台" @change="changeCompetition">
                    <el-option v-for="item in secondCompetitions" :key="item.name" :label="item.name" :value="item.name"/>
                  </el-select>
                </el-form-item>
                <el-form-item label="产品筛选：">
                  <el-select v-model="productSearch.secondSelectProduct" placeholder="请选择平台产品" multiple collapse-tags style="width:250px">
                    <el-option v-for="item in secondProduct" :key="item.productTypeName" :label="item.productTypeName" :value="item.productTypeName"/>
                  </el-select>
                  <el-button type="primary" style="margin-left:30px" @click="productSearchSubmit">查询</el-button>
                </el-form-item>
              </el-form>
              <div v-loading="contentLoading2" :class="className" :id="product" :style="{height:height,width:width}"/>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import request from '@/utils/request'
import echarts from 'echarts'
import resize from '../../components/Charts/mixins/resize'
export default{
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    product: {
      type: String,
      default: 'productChart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '500px'
    }
  },
  data() {
    return {
      chart: null,
      contentLoading: false,
      contentLoading2: false,
      fundsSearch: {
        startTime: '',
        endTime: '',
        firstSelectCompetitions: []
      }, // 平台查询条件
      productSearch: {
        startTime: '',
        endTime: '',
        secondSelectCompetitions: '',
        secondSelectProduct: []
      }, // 平台产品条件
      chartOption: {
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            params.sort(function(a, b) {
              return b.value - a.value
            })
            // x轴名称
            var name = params[0].name + '<br />'
            params.forEach(element => {
              name += element.marker + element.seriesName + ':' + element.value + '<br />'
            })
            return name
          }
        },
        legend: {
          top: 20,
          itemGap: 13,
          data: []
        },
        grid: {
          top: 100,
          left: '2%',
          right: '6%',
          bottom: '2%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          name: '时间(天)',
          boundaryGap: false,
          data: []
        }],
        yAxis: [{
          type: 'value',
          name: '额度(万)'
        }],
        series: []
      },
      productOption: {
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis',
          formatter: function(params, ticket, callback) {
            params.sort(function(a, b) {
              return b.value - a.value
            })
            // x轴名称
            var name = params[0].name + '<br />'
            params.forEach(element => {
              name += element.marker + element.seriesName + ':' + element.value + '<br />'
            })
            return name
          }
        },
        legend: {
          top: 20,
          itemGap: 13,
          data: []
        },
        grid: {
          top: 100,
          left: '2%',
          right: '6%',
          bottom: '2%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          name: '时间(天)',
          boundaryGap: false,
          data: []
        }],
        yAxis: [{
          type: 'value',
          name: '额度(万)'
        }],
        series: []
      }, // 平台产品图形
      activeName: 'first', // 控制哪个tab被选中激活
      allCompetitions: [], // 所有已上线的平台
      firstCompetitions: [], // 配置的所有平台名称
      secondCompetitions: [], // 产品监控页面的平台
      secondProduct: [], // 平台产品
      secondSelectTableInfo: {}
    }
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  async created() {
    const vm = this
    // 初始化平台名称
    await vm.initCompetitions()
    // 初始化平台相关的数据
    const nowTime = vm.getNowFormatDate(new Date())
    const startOne = nowTime + ' ' + '00:00:00'
    const s1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 31
    const e1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 1
    const startDay = vm.getNowFormatDate(s1)
    const endDay = vm.getNowFormatDate(e1)
    vm.fundsSearch.startTime = startDay
    vm.fundsSearch.endTime = endDay
    await vm.getCompetitorInvests()
  },
  methods: {
    // 初始化配置的所有平台
    async initCompetitions() {
      const vm = this
      await request.post('/report/loan/competitor/spiderTableItem/getSpiderTableItem')
        .then((res) => {
          if (res.data.status === 0) {
            vm.allCompetitions = res.data.result
            vm.firstCompetitions = vm.allCompetitions
            vm.allCompetitions.forEach(element => {
              vm.fundsSearch.firstSelectCompetitions.push(element.name)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    async getCompetitorInvests() {
      const vm = this
      if (vm.fundsSearch.firstSelectCompetitions.length === 0) {
        this.$message.error('请选择平台！')
        return false
      }
      var platformNameList = []
      for (let i = 0; i < vm.fundsSearch.firstSelectCompetitions.length; i++) {
        const ele = vm.fundsSearch.firstSelectCompetitions[i]
        if (ele === '全部') {
          platformNameList = []
          vm.allCompetitions.forEach(com => {
            platformNameList.push(com.name)
          })
          break
        } else {
          platformNameList.push(ele)
        }
      }
      vm.contentLoading = true
      const res = await request.post('/report/loan/adsSpiderCompetitorDayInvest/getCompetitorInvests', { startTime: vm.fundsSearch.startTime, endTime: vm.fundsSearch.endTime, platformName: platformNameList + '' })
      // 遍历数据进行渲染
      if (res.data.status === 0) {
        vm.chartOption.series = []
        vm.chartOption.xAxis[0].data = []
        vm.chartOption.legend.data = []
        vm.chartOption.xAxis[0].data = res.data.result.days
        vm.chartOption.legend.data = res.data.result.platformName
        var object = res.data.result
        for (const key in object) {
          if (object.hasOwnProperty(key) && key !== 'platformName' && key !== 'days') {
            const element = object[key]
            var seriesEle = {
              name: key,
              type: 'line',
              smooth: true,
              data: element
            }
            vm.chartOption.series.push(seriesEle)
          }
        }
      }
      vm.chart = echarts.init(document.getElementById(vm.id))
      vm.chart.setOption(vm.chartOption, true)
      vm.contentLoading = false
    },
    async fundSearchSubmit() {
      const vm = this
      vm.getCompetitorInvests()
    },
    async tabClick(tab, event) {
      const vm = this
      if (tab.name === 'second') {
        // 初始化平台默认第一个
        if (vm.productSearch.secondSelectCompetitions.length === 0) {
          // 初始化时间
          const nowTime = vm.getNowFormatDate(new Date())
          const startOne = nowTime + ' ' + '00:00:00'
          const s1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 31
          const e1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 1
          const startDay = vm.getNowFormatDate(s1)
          const endDay = vm.getNowFormatDate(e1)
          vm.productSearch.startTime = startDay
          vm.productSearch.endTime = endDay
          // 初始化平台
          vm.secondCompetitions = vm.allCompetitions
          vm.productSearch.secondSelectCompetitions = vm.secondCompetitions[0].name
          // 根据平台初始化产品
          await vm.getProduct(vm.productSearch.secondSelectCompetitions)
          // 根据平台和产品初始化查询
          await vm.getProductInvests()
        }
      }
    },
    // 切换平台
    changeCompetition(platName) {
      const vm = this
      vm.getProduct(platName)
    },
    // 查询产品
    async getProduct(platName) {
      const vm = this
      vm.secondCompetitions.forEach(ele => {
        if (ele.name === platName) {
          vm.secondSelectTableInfo = ele
        }
      })
      await request.post('/report/loan/competitor/spiderTableItem/getSpiderTableItemProduct', { tableName: vm.secondSelectTableInfo.tableName })
        .then((res) => {
          if (res.data.status === 0) {
            vm.secondProduct = res.data.result
            vm.productSearch.secondSelectProduct = []
            vm.secondProduct.forEach(ele => {
              vm.productSearch.secondSelectProduct.push(ele.productTypeName)
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    productSearchSubmit() {
      const vm = this
      vm.getProductInvests()
    },
    async getProductInvests() {
      const vm = this
      // 校验有没有选择平台和产品
      if (vm.productSearch.secondSelectCompetitions.length === 0) {
        this.$message.error('请选择平台！')
        return false
      }
      if (vm.productSearch.secondSelectProduct.length === 0) {
        this.$message.error('请选择平台产品！')
        return false
      }
      // 根据平台和产品查询
      vm.contentLoading2 = true
      var param = {
        startTime: vm.productSearch.startTime,
        endTime: vm.productSearch.endTime,
        selectProduct: vm.productSearch.secondSelectProduct + '',
        tableName: vm.secondSelectTableInfo.tableName,
        tableJoinName: vm.secondSelectTableInfo.tableJoinName
      }
      const res = await request.post('/report/loan/competitor/spiderTableItem/getProductLine', param)
      // 遍历数据进行渲染
      if (res.data.status === 0) {
        vm.productOption.series = []
        vm.productOption.xAxis[0].data = []
        vm.productOption.legend.data = []
        var object = res.data.result
        var legendArray = []
        var timeArray = []
        for (const proudct in object) {
          var ele = object[proudct]
          var valueArray = []
          timeArray = []
          for (const time in ele) {
            const value = ele[time]
            valueArray.push(value)
            timeArray.push(time)
          }
          var seriesEle = {
            name: proudct,
            type: 'line',
            smooth: true,
            data: valueArray
          }
          vm.productOption.series.push(seriesEle)
          legendArray.push(proudct)
        }
        vm.productOption.legend.data = legendArray
        vm.productOption.xAxis[0].data = timeArray
      }
      vm.chart = echarts.init(document.getElementById(vm.product))
      vm.chart.setOption(vm.productOption, true)
      vm.contentLoading2 = false
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    },
    changeTimeA() {
      const startTime = this.getNowFormatDate(this.fundsSearch.startTime)
      this.fundsSearch.startTime = startTime
    },
    changeTimeB() {
      const endTime = this.getNowFormatDate(this.fundsSearch.endTime)
      this.fundsSearch.endTime = endTime
    },
    changeTimeC() {
      const startTime = this.getNowFormatDate(this.productSearch.startTime)
      this.productSearch.startTime = startTime
    },
    changeTimeD() {
      const endTime = this.getNowFormatDate(this.productSearch.endTime)
      this.productSearch.endTime = endTime
    }
  }
}
</script>
<style scoped>
.el-main{
  padding:0;
}
.chart-container{
  position: relative;
  padding:20px;
  width: 100%;
  height:85vh;
}
.list .el-icon-info{
  position: relative;
  color:#999;
  top:8px;
  cursor: pointer;
}
/deep/ .list .el-form-item__label{
  width:110px;
}
/deep/ .list .el-input--medium{
  width:350px;
}
/deep/ .list .el-date-editor{
  width:168px;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}

/deep/ .el-select-dropdown.is-multiple .el-select-dropdown__item.selected::after {
    position: absolute;
    /* right: 20px; */
    font-family: element-icons;
    content: "\E611";
    font-size: 12px;
    font-weight: 700;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
</style>
