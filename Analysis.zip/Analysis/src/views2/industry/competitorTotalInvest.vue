<template>
  <div class="dashboard-editor-container">
    <el-card class="box-card" style="height:135px">
      <div slot="header" class="clearfix">
        <span>{{ chartTitle }}</span>
      </div>
      <el-form :inline="true" v-model="daySearch" class="demo-form-inline funds">
        <el-row>
          <el-col :span="12">
            <el-button v-show="!showTotalFlag" type="warning" icon="el-icon-back" @click="backTotal()">返回</el-button>
            <el-form-item v-if="showTotalFlag" label="查询日期">
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="daySearch.startTime"
                :picker-options="pickerOptions0"
                placeholder="开始日期"
              />
              -
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="daySearch.endTime"
                :picker-options="pickerOptions1"
                placeholder="结束日期"
              />
            </el-form-item>
            <el-form-item v-else label="查询日期">
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="twoSearch.startTime"
                :picker-options="pickerOptions2"
                placeholder="开始日期"
              />
              -
              <el-date-picker
                :editable="false"
                :clearable="false"
                v-model="twoSearch.endTime"
                :picker-options="pickerOptions3"
                placeholder="结束日期"
              />
            </el-form-item>
            <el-button v-show="showTotalFlag" type="success" round size="mini" title="前一天数据" style="margin-top: 5px;" @click="selectDate(1)">日</el-button>
            <el-button v-show="showTotalFlag" type="success" round size="mini" title="上周一至上周日数据" @click="selectDate(2)">周</el-button>
            <el-button v-show="showTotalFlag" type="success" round size="mini" title="上月1号至上月最后一天数据" @click="selectDate(3)">月</el-button>
          </el-col>
          <el-col :span="8" style="padding-left:110px">
            <el-button type="primary" @click="searchSubmit()">查询</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <bar-chart ref="getChart" :chart-data="competitorData"/>
    </el-row>
  </div>
</template>
<script>
import request from '@/utils/request'
import barChart from '../industry/competitorBarChart'
export default{
  components: {
    barChart
  },
  data() {
    return {
      contentLoading: false,
      daySearch: {
        startTime: '',
        endTime: ''
      },
      twoSearch: {
        startTime: '',
        endTime: ''
      },
      pickerOptions0: {
        disabledDate: (time) => {
          if (this.daySearch.endTime !== '') {
            return time.getTime() > Date.now() || time.getTime() > this.daySearch.endTime
          } else {
            return time.getTime() > Date.now()
          }
        }
      },
      pickerOptions1: {
        disabledDate: (time) => {
          return time.getTime() < this.daySearch.startTime || time.getTime() > Date.now()
        }
      },
      pickerOptions2: {
        disabledDate: (time) => {
          if (this.twoSearch.endTime !== '') {
            return time.getTime() > Date.now() || time.getTime() > this.twoSearch.endTime
          } else {
            return time.getTime() > Date.now()
          }
        }
      },
      pickerOptions3: {
        disabledDate: (time) => {
          return time.getTime() < this.twoSearch.startTime || time.getTime() > Date.now()
        }
      },
      competitorData: {
        xAxis: {
          type: 'category',
          data: [],
          triggerEvent: true
        },
        legend: {
          top: true,
          data: ['投资金额(万元)', '投资笔数(笔)']
        },
        yAxis: [],
        series: [],
        toolbox: {},
        grid: {
          containLabel: true
        }
      }, // 存放柱图相关的数据
      competitorLineData: {
        xAxis: {
          type: 'category',
          data: []
        },
        legend: {
          top: true,
          data: ['投资金额(万元)', '投资笔数(笔)']
        },
        yAxis: [],
        series: [],
        toolbox: {},
        grid: {
          containLabel: true
        }
      },
      chartTitle: '平台出借额监控',
      showTotalFlag: true, // 控制显示平台整体数据还是天数据
      dayParams: {}// 天数据折线图参数
    }
  },
  async created() {
    const vm = this
    // 初始化查询时间
    vm.daySearch.startTime = new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
    vm.daySearch.endTime = new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
    // 获取爬虫的数据
    vm.getCompetitorTotalInvests()
  },
  methods: {
    getCompetitorTotalInvests() {
      const vm = this
      const params = {
        startTime: vm.getNowFormatDate(vm.daySearch.startTime),
        endTime: vm.getNowFormatDate(vm.daySearch.endTime)
      }
      request.post('/report/loan/adsSpiderCompetitorDayInvest/getCompetitorTotalInvests', params)
        .then((res) => {
          if (res.data.status === 0) {
            const yAxisIndex0 = {
              type: 'value',
              name: '投资金额(万元)',
              min: 0,
              position: 'left'
            }
            const yAxisIndex1 = {
              type: 'value',
              name: '投资笔数(笔)',
              min: 0,
              position: 'right'
            }
            const series0 = {
              data: [],
              type: 'bar',
              name: '投资金额(万元)',
              yAxisIndex: 0,
              barWidth: 30
            }
            const series1 = {
              data: [],
              type: 'bar',
              name: '投资笔数(笔)',
              yAxisIndex: 1,
              barWidth: 30
            }
            const xAxisLabel = []
            if (res.data.result.length !== 0) {
              res.data.result.forEach(ele => {
                xAxisLabel.push(ele.platform)
                series0.data.push((ele.invest_amt / 10000).toFixed(2))
                series1.data.push(ele.invest_cnt)
              })
            }
            vm.competitorData.yAxis = []
            vm.competitorData.series = []
            vm.competitorData.xAxis.data = []
            vm.competitorData.xAxis.data = xAxisLabel
            vm.competitorData.yAxis.push(yAxisIndex0)
            vm.competitorData.yAxis.push(yAxisIndex1)
            vm.competitorData.series.push(series0)
            vm.competitorData.series.push(series1)
            vm.$refs.getChart.chart.off('click')
            vm.$refs.getChart.chart.on('click', function(params) {
              vm.dayParams = params
              vm.showTotalFlag = false
              const nowTime = vm.getNowFormatDate(new Date())
              const startOne = nowTime + ' ' + '00:00:00'
              const s1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 31
              const e1 = new Date(startOne).getTime() - 3600 * 1000 * 24 * 1
              const startDay = vm.getNowFormatDate(s1)
              const endDay = vm.getNowFormatDate(e1)
              vm.twoSearch.startTime = new Date(startDay)
              vm.twoSearch.endTime = new Date(endDay)
              vm.getCompetitorDayInvests()
            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 查询天折线数据
    getCompetitorDayInvests() {
      const vm = this
      vm.chartTitle = (vm.dayParams.name || vm.dayParams.value) + '平台每日数据'
      const params = {
        startTime: vm.getNowFormatDate(vm.twoSearch.startTime),
        endTime: vm.getNowFormatDate(vm.twoSearch.endTime),
        platform: vm.dayParams.name || vm.dayParams.value
      }
      request.post('/report/loan/adsSpiderCompetitorDayInvest/getCompetitorDayInvests', params)
        .then((res) => {
          if (res.data.status === 0) {
            const yAxisIndex0 = {
              type: 'value',
              name: '投资金额(万元)',
              min: 0,
              position: 'left'
            }
            const yAxisIndex1 = {
              type: 'value',
              name: '投资笔数(笔)',
              min: 0,
              position: 'right'
            }
            const series0 = {
              data: [],
              type: 'line',
              name: '投资金额(万元)',
              yAxisIndex: 0,
              barWidth: 30
            }
            const series1 = {
              data: [],
              type: 'line',
              name: '投资笔数(笔)',
              yAxisIndex: 1,
              barWidth: 30
            }
            const xAxisLabel = []
            if (res.data.result.length !== 0) {
              res.data.result.forEach(ele => {
                xAxisLabel.push(vm.getNowFormatDate(ele.statisticsDate))
                series0.data.push((ele.investAmt / 10000).toFixed(2))
                series1.data.push(ele.investCnt)
              })
            }
            vm.competitorData.yAxis = []
            vm.competitorData.series = []
            vm.competitorData.xAxis.data = []
            vm.competitorData.xAxis.data = xAxisLabel
            vm.competitorData.yAxis.push(yAxisIndex0)
            vm.competitorData.yAxis.push(yAxisIndex1)
            vm.competitorData.series.push(series0)
            vm.competitorData.series.push(series1)
            vm.$refs.getChart.chart.off('click')
            vm.$refs.getChart.chart.on('click', function(params) {

            })
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    backTotal() {
      const vm = this
      vm.showTotalFlag = true
      vm.chartTitle = '平台出借额监控'
      vm.getCompetitorTotalInvests()
    },
    searchSubmit() {
      const vm = this
      if (vm.showTotalFlag === true) {
        vm.getCompetitorTotalInvests()
      } else {
        vm.getCompetitorDayInvests()
      }
    },
    selectDate(index) {
      const vm = this
      if (index === 1) {
        vm.daySearch.startTime = new Date(new Date().getTime() - 24 * 3600 * 1000)
        vm.daySearch.endTime = new Date(new Date().getTime() - 24 * 3600 * 1000)
      } else if (index === 2) {
        const myDate = new Date(new Date().getTime() - 7 * 24 * 3600 * 1000)
        const day = myDate.getDay()
        const time = myDate.getDate() - day + (day === 0 ? -6 : 1)
        const startTime = new Date(myDate.setDate(time))
        vm.daySearch.startTime = new Date(startTime.getFullYear() + '-' + (startTime.getMonth() + 1) + '-' + startTime.getDate())
        const endTime = new Date(myDate.setDate(time + 6))
        vm.daySearch.endTime = new Date(endTime.getFullYear() + '-' + (endTime.getMonth() + 1) + '-' + endTime.getDate())
      } else if (index === 3) {
        const nowdays = new Date()
        let year = nowdays.getFullYear()
        let month = nowdays.getMonth()
        if (month === 0) {
          month = 12
          year = year - 1
        }
        if (month < 10) {
          month = '0' + month
        }
        const yDate = new Date(year, month, 0)
        vm.daySearch.startTime = new Date(year + '-' + month + '-01 00:00:00') // 上个月第一天
        vm.daySearch.endTime = new Date(year + '-' + month + '-' + yDate.getDate() + ' 23:59:59') // 上个月最后一天
      }
      vm.getCompetitorTotalInvests()
    },
    // 时间格式化
    getNowFormatDate(date) {
      const seperator1 = '-'
      if (typeof (date) === 'number') {
        date = new Date(date)
      }
      if (!date) {
        return ''
      } else if (typeof (date) === 'string' && date.length === 6) {
        return date
      } else {
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) { month = '0' + month }
        if (strDate >= 0 && strDate <= 9) { strDate = '0' + strDate }
        const currentdate = year + seperator1 + month + seperator1 + strDate
        return currentdate
      }
    }
  }
}
</script>
<style scoped lang="scss">
.el-main{
  padding:0;
}
/deep/ .funds .el-form-item__label{
  width:110px;
}
/deep/ .el-dialog__body{
  padding-top:10px;
  padding-bottom: 0;
}
/deep/ .el-select--medium{
  width:350px;
}
/deep/ .el-date-editor{
  width:168px;
}
.btnTwo{
  float: right;
}
/deep/ .el-table .cell{
  height:auto;
}
.times{
  overflow: hidden;
  padding-bottom:10px;
}
.times>span{
  float: left;
  width:25%;
  text-align: center;
  height:24px;
}
.funds .el-icon-setting{
  font-size:18px;
  position: relative;
  top:2px;
  cursor: pointer;
}
/deep/ .amtBalance span{
  padding-right:5px;
}
/deep/ .amtBalance i{
  cursor: pointer;
}
.earlyWarning{
  margin-bottom: 15px;
}
.earlyWarning i{
  font-style: normal;
  color:#f11b1b;
}
.earlyWarning>b{
  display: inline-block;
  width:110px;
  font-size:14px;
  color:#606266;
  text-align: right;
  font-weight:700;
}
/deep/ .el-table .warning-row {
  background: rgba(244,144,144,0.5);
}
</style>
