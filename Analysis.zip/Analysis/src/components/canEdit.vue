<template>
  <div
    :contenteditable="canEdit"
    :type="type"
    class="edit-div"
    @focus="cacheRange"
    @click="cacheRange"
    @blur="isLocked = false"
    @input="changeText"
    @keyup="cacheRange"
    @keydown="cacheRange"
    @mouseup="cacheRange"
    v-html="defaultText" />
</template>
<script>
export default{
  name: 'EditDiv',
  props: {
    type: {
      type: [String],
      default: 'string'
    },
    value: {
      type: [String, Boolean],
      default: ''
    },
    canEdit: {
      type: Boolean,
      default: true
    },
    contenteditable: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      innerText: this.value,
      defaultText: this.value && this.value.toString() || '',
      isLocked: false,
      preCaretOffset: 0,
      preLength: (this.value && this.value.length) || 0,
      selectedLength: 0,
      editing: false
    }
  },
  watch: {
    'value'() {
      if (!this.isLocked || !this.innerText) {
        this.innerText = this.value
      }
    }
  },
  created() {
    // this.$emit('input', this.innerText || '')
  },
  methods: {
    changeText() {
      const vm = this
      /* if(vm.editing) {
        return
      }
      vm.editing = true
      let innerHTML = vm.$el.innerHTML
      if (vm.type === 'number') {
        innerHTML = innerHTML.replace(/[^\d]+/, '')
        vm.$el.innerHTML = innerHTML
      }
      window.setTimeout(() => {
        let caretOffset = vm.caretOffset + (innerHTML.length - vm.preLength + vm.selectedLength)
        if (caretOffset < 0) {
          caretOffset = innerHTML.length
        }
        vm.preLength = innerHTML.length
        vm.caretOffset = caretOffset
        let range = document.createRange()
        range.selectNodeContents(vm.$el)
        if(caretOffset, vm.$el.childNodes[0]) {
          range.setStart(vm.$el.childNodes[0], caretOffset)
          range.collapse(true)
        }
        let selection = window.getSelection()
        selection.removeAllRanges()
        selection.addRange(range)
      }, 0)*/
      vm.$emit('input', vm.$el.innerHTML)
      vm.editing = false
    },

    cacheRange() {
      /* this.isLocked = false
      this.$el.focus()
      const range = window.getSelection().getRangeAt(0)
      this.selectedLength = range.toString().length
      this.caretOffset = range.startOffset*/
    }
  }
}
</script>
<style>
.edit-div{
  user-modify: read-write-plaintext-only;
  -webkit-user-modify: read-write-plaintext-only;
}
</style>
