module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  // BASE_API: '"http://172.20.11.183:9966"'
  // BASE_API: '"http://172.16.10.209:9966"'
  // BASE_API: '"http://172.20.11.182:9966"'
  BASE_API: '"http://172.20.8.46:9966"'
}
